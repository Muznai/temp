/* ExamAce — محرّك موحّد (التدرّب + المراجعة · عربي/إنجليزي)
   كل درسٍ يضبط سطرين قبل تحميل هذا الملفّ:
     var EA_COURSE = "ar";   // أو "en"
     var EA_TASK   = "1.1";  // رمز المهمة · أو "REVIEW" · أو "ALL"
   أيّ تحسينٍ لاحقٍ = تعديل هذا الملفّ مرّةً واحدة. */
(function(){
  var EA_COURSE = (typeof window.EA_COURSE!=="undefined" && window.EA_COURSE) ? String(window.EA_COURSE) : "ar";
  var EA_TASK   = (typeof window.EA_TASK!=="undefined"   && window.EA_TASK)   ? String(window.EA_TASK)   : "ALL";
  var MODE = (EA_TASK.toUpperCase()==="REVIEW") ? "review" : "practice";
  var RTL  = (EA_COURSE!=="en");
  var PAIRS = {"<div class=\"ea-case\"><div class=\"case-bar\"><b>📋 دراسة الحالة</b><span style=\"font-size:12px;color:var(--gray)\">تخدم عدة أسئلة</span></div><div style=\"margin-top:8px\">": "<div class=\"ea-case\"><div class=\"case-bar\"><b>📋 Case study</b><span style=\"font-size:12px;color:var(--gray)\">serves several questions</span></div><div style=\"margin-top:8px\">", "<div class=\"ea-case\"><div class=\"case-bar\"><b>📋 دراسة الحالة</b><button class=\"case-toggle\" id=\"case-toggle\">": "<div class=\"ea-case\"><div class=\"case-bar\"><b>📋 Case study</b><button class=\"case-toggle\" id=\"case-toggle\">", "اخفِ ▲": "Hide ▲", "اعرض دراسة الحالة ▼": "Show case study ▼", "✓ تم التعرّف عليك تلقائيا: <span class=\"who\">": "✓ You were identified automatically: <span class=\"who\">", " · معرّف ": " · ID ", "تعذّر التعرّف على الهوية تلقائيا (خارج Teachable؟) — التخزين السحابي يعمل داخل Teachable فقط.": "Could not identify you automatically (outside Teachable?) — cloud storage works inside Teachable only.", "⏳ مزامنة التقدّم...": "⏳ Syncing progress...", "☁️ تقدّمك محفوظ سحابيا": "☁️ Your progress is saved to the cloud", "⚠️ تعذّرت المزامنة — وضع محلي": "⚠️ Sync failed — local mode", "⚠️ تعذّر حفظ آخر تغيير": "⚠️ Could not save the last change", "⚠️ تعذّر حفظ آخر تغيير — تحقّق من الاتصال": "⚠️ Could not save the last change — check your connection", "⚠️ الإجابة المعتمدة خاطئة": "⚠️ The marked answer is wrong", "📝 خطأ لغويّ أو إملائيّ": "📝 Language or spelling error", "❓ السؤال أو الخيارات غير واضحة": "❓ The question or options are unclear", "🔢 مشكلة في الشكل أو الأرقام": "🔢 Problem with the figure or numbers", "➕ أخرى": "➕ Other", "<h3>إبلاغ عن مشكلة</h3>": "<h3>Report a problem</h3>", "<div class=\"sub\">اختر نوع المشكلة في هذا السؤال:</div>": "<div class=\"sub\">Choose the type of problem with this question:</div>", "<textarea id=\"ea-rnote\" placeholder=\"ملاحظة (اختيارية) — صف المشكلة بإيجاز...\"></textarea>": "<textarea id=\"ea-rnote\" placeholder=\"Note (optional) — briefly describe the problem...\"></textarea>", "<div class=\"req\" id=\"ea-rreq\">يُرجى كتابة ملاحظة عند اختيار «أخرى».</div>": "<div class=\"req\" id=\"ea-rreq\">Please add a note when you select “Other”.</div>", "<div class=\"row\"><button class=\"cancel\" id=\"ea-rcancel\">إلغاء</button>": "<div class=\"row\"><button class=\"cancel\" id=\"ea-rcancel\">Cancel</button>", "<button class=\"send\" id=\"ea-rsend\" disabled>إرسال</button></div>": "<button class=\"send\" id=\"ea-rsend\" disabled>Send</button></div>", "جارٍ الإرسال...": "Sending...", "<div class=\"ok-msg\">✅ شكرًا — وصل بلاغك.</div>": "<div class=\"ok-msg\">✅ Thanks — your report was received.</div>", "إرسال": "Send", "تعذّر الإرسال — تحقّق من الاتصال وحاول ثانيةً.": "Could not send — check your connection and try again.", "حدث خطأ": "An error occurred", "حدث خطأ غير متوقّع": "An unexpected error occurred", "<div class=\"ee-sub\">إذا تكرّر، راسلنا بهذا الرمز:</div>": "<div class=\"ee-sub\">If it recurs, contact us with this code:</div>", " صحيحة</span>": " correct</span>", " خاطئة</span>": " wrong</span>", " مميّزة</span></div>": " flagged</span></div>", " لم تُحل</span>": " not solved</span>", "اختيار من متعدد": "Multiple choice", "اختيار متعدد (اختر ": "Multiple select (choose ", "قائمة منسدلة — ملء فراغات": "Dropdown — fill in the blanks", "سحب وإفلات": "Drag & drop", "توصيل بالسحب": "Match by dragging", "نقر على الشكل": "Click the figure", "<div class=\"ea-counter\"><span>السؤال ": "<div class=\"ea-counter\"><span>Question ", " من ": " of ", "<span class=\"ea-jump\">اذهب للسؤال: <input type=\"number\" id=\"ea-go\" min=\"1\" max=\"": "<span class=\"ea-jump\">Go to question: <input type=\"number\" id=\"ea-go\" min=\"1\" max=\"", "</span><span class=\"ea-chip task\">المهمة ": "</span><span class=\"ea-chip task\">Task ", "</span><span class=\"ea-chip enb\">ممكّن ": "</span><span class=\"ea-chip enb\">Enabler ", "🚩 مميّز": "🚩 Flagged", "🏳️ تمييز": "🏳️ Flag", "<button class=\"ea-reportbtn\" id=\"ea-reportbtn\" title=\"إبلاغ عن مشكلة في السؤال\">⚠️ إبلاغ</button></div>": "<button class=\"ea-reportbtn\" id=\"ea-reportbtn\" title=\"Report a problem with this question\">⚠️ Report</button></div>", "\"><option value=\"\">— اختر —</option>": "\"><option value=\"\">— Select —</option>", ">→ السابق</button>": ">← Previous</button>", "<button class=\"ea-btn ea-primary\" id=\"ea-check\">تحقّق</button>": "<button class=\"ea-btn ea-primary\" id=\"ea-check\">Check</button>", ">التالي ←</button>": ">Next →</button>", "<div style=\"margin-top:14px;text-align:center\"><button class=\"ea-btn ea-ghost\" id=\"ea-results\">عرض التشخيص</button> <button class=\"ea-btn ea-mini\" id=\"ea-reset\">إعادة الضبط</button></div>": "<div style=\"margin-top:14px;text-align:center\"><button class=\"ea-btn ea-ghost\" id=\"ea-results\">Show diagnosis</button> <button class=\"ea-btn ea-mini\" id=\"ea-reset\">Reset</button></div>", "<div class=\"tray-label\">العناصر — اسحبها الى مواضعها:</div>": "<div class=\"tray-label\">Items — drag them to their places:</div>", "<div style=\"font-size:12.5px;color:var(--gray)\">— تم وضع كل العناصر —</div>": "<div style=\"font-size:12.5px;color:var(--gray)\">— All items placed —</div>", "افلت الموقف هنا": "Drop the item here", "إجابة صحيحة ✓": "Correct answer ✓", "إجابة غير صحيحة ✗": "Incorrect answer ✗", "<div style=\"margin-bottom:6px\">الإجابة الصحيحة: <b style=\"display:inline\">": "<div style=\"margin-bottom:6px\">Correct answer: <b style=\"display:inline\">", "<div class=\"sec\">↪ يلمس أيضا (لا يُحتسب): ": "<div class=\"sec\">↪ Also touches (not counted): ", "اختر اجابة اولا": "Select an answer first", "اختر ": "Choose ", " اجابات": " answers", "اكمل كل الفراغات": "Fill in all the blanks", "اسحب كل العناصر الى مواضعها": "Drag all items to their places", "انقر مقياسا اولا": "Click a tile first", "% صحيحة</span><span class=\"lbl2\">من ": "% correct</span><span class=\"lbl2\">of ", " محلولة · ": " solved · ", " سؤالا إجمالا</span></div></div>": " questions total</span></div></div>", "<div class=\"rep-sec\"><div class=\"plan\"><div class=\"h\">📌 خطة المذاكرة — ابدأ بالأضعف</div>": "<div class=\"rep-sec\"><div class=\"plan\"><div class=\"h\">📌 Study plan — start with the weakest</div>", "<div class=\"plan-go\">← راجع درس المهمة ": "<div class=\"plan-go\">Review the task lesson ", " ممكّن آخر دون 70% (معروضة في التفصيل أدناه).</div>": " other enabler(s) below 70% (shown in the breakdown below).</div>", "<div class=\"plan-ok\">✓ لا ممكّن دون 70% فيما حللت — أداء جيد. واصل لتغطية باقي الممكّنات.</div>": "<div class=\"plan-ok\">✓ No enabler below 70% in what you solved — good work. Keep going to cover the rest.</div>", " ممكّن لم تُجب عنه بعد — حلّه ليكتمل تشخيصك.</div>": " enabler(s) not yet answered — solve them to complete your diagnosis.</div>", "<div class=\"rep-sec\"><div class=\"h\">📊 التفصيل الكامل</div><div class=\"hint\">من العامّ (المجال) إلى الأدقّ (الممكّن). أحمر < 40% · برتقالي < 70% · أخضر ≥ 70%.</div>": "<div class=\"rep-sec\"><div class=\"h\">📊 Full breakdown</div><div class=\"hint\">From broad (domain) to specific (enabler). Red < 40% · Orange < 70% · Green ≥ 70%.</div>", "<div class=\"rep-card\"><div class=\"ct\">① حسب المجال</div>": "<div class=\"rep-card\"><div class=\"ct\">① By domain</div>", "<div class=\"rep-card\"><div class=\"ct\">② حسب المهمة</div>": "<div class=\"rep-card\"><div class=\"ct\">② By task</div>", "<div class=\"rep-card\"><div class=\"ct\">③ حسب الممكّن (الأدقّ)</div>": "<div class=\"rep-card\"><div class=\"ct\">③ By enabler (most specific)</div>", "<div class=\"rep-flag2\">🚩 أسئلة مميّزة للمراجعة: ": "<div class=\"rep-flag2\">🚩 Flagged questions for review: ", "<div class=\"rep-foot\">التشخيص بالممكّن يزداد موثوقيةً مع زيادة الأسئلة لكل ممكّن (الهدف ≈ 5).</div>": "<div class=\"rep-foot\">Enabler-level diagnosis grows more reliable as questions per enabler increase (target ≈ 5).</div>", "<div class=\"ea-actions\"><button class=\"ea-btn ea-primary\" id=\"ea-back\">العودة للأسئلة</button><div class=\"right\"><button class=\"ea-btn ea-mini\" id=\"ea-reset2\">إعادة الضبط</button></div></div>": "<div class=\"ea-actions\"><button class=\"ea-btn ea-primary\" id=\"ea-back\">Back to questions</button><div class=\"right\"><button class=\"ea-btn ea-mini\" id=\"ea-reset2\">Reset</button></div></div>", "هل تريد إعادة ضبط كل التقدّم والبدء من جديد؟": "Reset all progress and start over?", "جارٍ تحميل الأسئلة...": "Loading questions...", "تعذّر الاتصال بالخادم. تحقّق من اتصالك بالإنترنت.": "Could not reach the server. Check your internet connection.", "تعذّر تحميل المحتوى حاليا.": "Could not load content right now.", "لا توجد أسئلة متاحة لهذا الدرس بعد.": "No questions available for this lesson yet.", "كل الأسئلة — ": "All questions — ", " سؤالا": " questions", "المهمة ": "Task ", " أسئلة": " questions", "تعذّر تحديد هذا الدرس. إذا تكرّر، تأكّد أنّ عنوان الدرس يبدأ برقم المهمة (مثل: 2.1).": "Could not determine this lesson. If it recurs, make sure EA_TASK is set (e.g., 2.1).", "<span class=\"rev-badge flag\">🚩 مميّزة</span>": "<span class=\"rev-badge flag\">🚩 Flagged</span>", "<span class=\"rev-badge wrong\">✗ أخطأت سابقا</span>": "<span class=\"rev-badge wrong\">✗ Previously wrong</span>", "<span class=\"rev-badge unsolved\">○ لم تُحلّ</span>": "<span class=\"rev-badge unsolved\">○ Not solved</span>", "<div style=\"margin-top:14px;text-align:center\"><button class=\"ea-btn ea-ghost\" id=\"ea-results\">عرض التشخيص</button> <button class=\"ea-btn ea-mini\" id=\"ea-reset\" style=\"color:var(--navy);border-color:var(--navy)\">← مركز المراجعة</button></div>": "<div style=\"margin-top:14px;text-align:center\"><button class=\"ea-btn ea-ghost\" id=\"ea-results\">Show diagnosis</button> <button class=\"ea-btn ea-mini\" id=\"ea-reset\" style=\"color:var(--navy);border-color:var(--navy)\">← Review center</button></div>", "تعذّر التعرّف على حسابك. افتح الصفحة داخل حسابك في Teachable.": "Could not identify your account. Open the page inside your Teachable account.", "جارٍ تجهيز مراجعتك...": "Preparing your review...", "تعذّر الاتصال بالخادم. تحقّق من اتصالك.": "Could not reach the server. Check your connection.", "تعذّر تحميل بيانات الكورس حاليا.": "Could not load course data right now.", "اختر ما تريد مراجعته — من ": "Choose what to review — of ", " سؤالا في الكورس": " questions in the course", "المميّزة": "Flagged", "ما وضعت عليه علامة": "What you flagged", "أخطأت فيها": "Wrong", "ما أجبت عنه خطأ": "Answered wrong", "لم تُحلّ": "Not solved", "ما لم تُجب عنه بعد": "Not answered yet", "<div class=\"rev-intro\">اختر فئةً أو أكثر، ثم ابدأ. السؤال في أكثر من فئة يظهر مرّةً واحدة.</div>": "<div class=\"rev-intro\">Choose one or more categories, then start. A question in more than one category appears once.</div>", "<div class=\"rev-sum\" id=\"rev-sum\">المنتقى: <b>": "<div class=\"rev-sum\" id=\"rev-sum\">Selected: <b>", "</b> سؤالا</div>": "</b> questions</div>", ">ابدأ المراجعة (": ">Start review (", "<div class=\"rev-empty-hint\">✓ لا أخطاء ولا أسئلة مميّزة — تدرّب على المهمات أولا لتمتلئ المراجعة.</div>": "<div class=\"rev-empty-hint\">✓ No mistakes and no flagged questions — practice the tasks first to fill the review.</div>", "المنتقى: <b>": "Selected: <b>", "</b> سؤالا": "</b> questions", "ابدأ المراجعة (": "Start review (", "جارٍ جلب الأسئلة المنتقاة...": "Fetching the selected questions...", "<div class=\"ea-card\"><div class=\"ea-empty\" style=\"color:var(--gray)\">جارٍ التحميل...</div></div>": "<div class=\"ea-card\"><div class=\"ea-empty\" style=\"color:var(--gray)\">Loading...</div></div>", "تعذّر الاتصال بالخادم.": "Could not reach the server.", "تعذّر تحميل الأسئلة المنتقاة.": "Could not load the selected questions.", "المراجعة — ": "Review — ", "جارٍ تحديث مراجعتك...": "Updating your review...", "تدرّب": "Practice", "مركز المراجعة": "Review Center", "جارٍ التحميل…": "Loading…", "تقدّمك وتمييزك محفوظان في حسابك ويُستعادان عبر أجهزتك. التشخيص بالممكّن يزداد دقّةً مع توسّع البنك (الهدف ≈ 5 أسئلة لكل ممكّن).": "Your progress and flags are saved to your account and restored across your devices. Enabler-level diagnosis sharpens as the bank grows (target ≈ 5 questions per enabler).", "المراجعة تجمع أسئلتك من كل المهمات. إجاباتك هنا تُحدّث تقدّمك (الإجابة الصحيحة تُخرج السؤال من «أخطأت فيها»).": "Review gathers your questions from all tasks. Answering here updates your progress (a correct answer removes the question from “Wrong”)."};
  function t(s){ return (EA_COURSE==="en" && Object.prototype.hasOwnProperty.call(PAIRS,s)) ? PAIRS[s] : s; }
  var CSS = "\n@import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');\n#ea-root{\n  --navy:#1F3B63; --blue:#2E6DA4; --green:#2E7D32; --amber:#B26A00;\n  --red:#9C2A2A; --lblue:#EAF2FB; --gray:#6B7280; --lgray:#E5E7EB;\n  font-family:'Tajawal','Segoe UI',Tahoma,sans-serif;\n  max-width:760px; margin:0 auto; color:#1f2937; line-height:1.7;\n  background:#fff; padding:4px; box-sizing:border-box;\n  -webkit-user-select:none; -moz-user-select:none; user-select:none;\n}\n#ea-root *{box-sizing:border-box;}\n#ea-root .ea-card{border:1px solid var(--lgray); border-radius:14px; padding:22px; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,.05);}\n#ea-root .ea-head{background:linear-gradient(135deg,var(--navy),var(--blue)); color:#fff; border-radius:14px; padding:20px 22px; margin-bottom:14px;}\n#ea-root .ea-head h1{margin:0 0 4px; font-size:21px; font-weight:700;}\n#ea-root .ea-head p{margin:0; font-size:13px; opacity:.9;}\n#ea-root .ea-bar{height:8px; background:rgba(255,255,255,.25); border-radius:99px; margin-top:14px; overflow:hidden;}\n#ea-root .ea-bar > i{display:block; height:100%; background:#fff; border-radius:99px; width:0; transition:width .3s;}\n#ea-root .ea-pad{display:flex; gap:7px; flex-wrap:wrap; margin-bottom:14px; align-items:center;}\n#ea-root .ea-pad .num{width:38px; height:38px; border-radius:9px; border:1.5px solid var(--lgray); background:#fff; cursor:pointer; font-family:inherit; font-weight:700; font-size:14px; color:var(--navy); position:relative; transition:.12s;}\n#ea-root .ea-pad .num:hover{border-color:var(--blue);}\n#ea-root .ea-pad .num.cur{background:var(--navy); color:#fff; border-color:var(--navy);}\n#ea-root .ea-pad .num.ok{background:#EAF7EC; border-color:var(--green); color:var(--green);}\n#ea-root .ea-pad .num.bad{background:#FBEAEA; border-color:var(--red); color:var(--red);}\n#ea-root .ea-pad .num.ok.cur, #ea-root .ea-pad .num.bad.cur{background:var(--navy); color:#fff; border-color:var(--navy);}\n#ea-root .ea-pad .num .fl{position:absolute; top:-6px; left:-6px; font-size:12px;}\n#ea-root .ea-pad .legend{font-size:11.5px; color:var(--gray); margin-right:auto; display:flex; gap:10px;}\n#ea-root .ea-stats{display:flex; gap:14px; flex-wrap:wrap; align-items:center; margin-bottom:10px; font-size:13px; font-weight:700;}\n#ea-root .ea-stats span{display:inline-flex; align-items:center; gap:5px; padding:3px 10px; border-radius:20px;}\n#ea-root .ea-stats .st-ok{background:#EAF7EC; color:var(--green);}\n#ea-root .ea-stats .st-bad{background:#FBEAEA; color:var(--red);}\n#ea-root .ea-stats .st-flag{background:#FFF6E9; color:var(--amber);}\n#ea-root .ea-stats .st-none{background:#F3F4F6; color:var(--gray);}\n#ea-root .ea-jump{display:inline-flex; align-items:center; gap:6px; font-size:13px; color:var(--gray); font-weight:400;}\n#ea-root .ea-jump input{width:56px; padding:5px 8px; border:1.5px solid var(--lgray); border-radius:8px; font-family:inherit; font-size:13px; text-align:center; color:var(--navy); font-weight:700;}\n#ea-root .ea-jump input:focus{border-color:var(--blue); outline:none;}\n#ea-root .ea-meta{display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; align-items:center;}\n#ea-root .ea-chip{font-size:12px; padding:4px 11px; border-radius:99px; font-weight:500;}\n#ea-root .ea-chip.dom{background:var(--lblue); color:var(--navy);}\n#ea-root .ea-chip.task{background:#F3F4F6; color:var(--gray);}\n#ea-root .ea-chip.enb{background:#EFE7FB; color:#5B3FA8;}\n#ea-root .ea-chip.type{background:var(--navy); color:#fff;}\n#ea-root .ea-chip.lvl{background:var(--amber); color:#fff;}\n#ea-root .ea-flag{margin-right:auto; cursor:pointer; border:1.5px solid var(--lgray); background:#fff; border-radius:9px; padding:6px 12px; font-family:inherit; font-size:13px; color:var(--gray); transition:.12s; font-weight:500;}\n#ea-root .ea-flag:hover{border-color:var(--amber);}\n#ea-root .ea-flag.on{background:#FFF6E9; border-color:var(--amber); color:var(--amber);}\n#ea-root .ea-reportbtn{cursor:pointer; border:1.5px solid var(--lgray); background:#fff; border-radius:9px; padding:6px 12px; font-family:inherit; font-size:13px; color:var(--gray); transition:.12s; font-weight:500; margin-right:8px;}\n#ea-root .ea-reportbtn:hover{border-color:var(--red); color:var(--red);}\n#ea-root .ea-modal-bg{position:fixed; inset:0; background:rgba(31,59,99,.45); display:flex; align-items:center; justify-content:center; z-index:9999;}\n#ea-root .ea-modal{background:#fff; border-radius:14px; padding:22px; width:90%; max-width:440px; box-shadow:0 12px 40px rgba(0,0,0,.25); text-align:right;}\n#ea-root .ea-modal h3{margin:0 0 4px; color:var(--navy); font-size:18px;}\n#ea-root .ea-modal .sub{color:var(--gray); font-size:13px; margin-bottom:16px;}\n#ea-root .ea-modal .opt{display:block; width:100%; text-align:right; border:1.5px solid var(--lgray); background:#fff; border-radius:9px; padding:11px 14px; margin-bottom:8px; cursor:pointer; font-family:inherit; font-size:14px; color:var(--navy); transition:.12s;}\n#ea-root .ea-modal .opt:hover{border-color:var(--blue); background:var(--lblue);}\n#ea-root .ea-modal .opt.sel{border-color:var(--blue); background:var(--lblue); font-weight:700;}\n#ea-root .ea-modal textarea{width:100%; box-sizing:border-box; border:1.5px solid var(--lgray); border-radius:9px; padding:10px; font-family:inherit; font-size:13.5px; margin-top:6px; resize:vertical; min-height:64px;}\n#ea-root .ea-modal .req{color:var(--red); font-size:12px; margin-top:4px; display:none;}\n#ea-root .ea-modal .row{display:flex; gap:10px; margin-top:16px;}\n#ea-root .ea-modal .row button{flex:1; border-radius:9px; padding:11px; font-family:inherit; font-size:14px; font-weight:700; cursor:pointer; border:none;}\n#ea-root .ea-modal .send{background:var(--green); color:#fff;}\n#ea-root .ea-modal .send:disabled{background:var(--lgray); cursor:not-allowed;}\n#ea-root .ea-modal .cancel{background:#fff; border:1.5px solid var(--lgray); color:var(--gray);}\n#ea-root .ea-modal .ok-msg{text-align:center; color:var(--green); font-size:15px; font-weight:700; padding:14px 0;}\n#ea-root .ea-case{background:#F6F8FB; border:1px solid var(--lgray); border-right:4px solid var(--blue); border-radius:10px; padding:14px 16px; margin-bottom:16px; font-size:14px; color:#374151;}\n#ea-root .ea-case b{color:var(--navy);}\n#ea-root .ea-case .case-bar{display:flex; justify-content:space-between; align-items:center; gap:10px;}\n#ea-root .ea-case .case-toggle{font-family:inherit; font-size:12.5px; font-weight:700; color:var(--blue); background:#fff; border:1.5px solid var(--blue); border-radius:8px; padding:5px 12px; cursor:pointer; white-space:nowrap;}\n#ea-root .ea-case .case-toggle:hover{background:var(--lblue);}\n#ea-root .ea-identity{margin-bottom:12px; border-radius:10px; padding:10px 14px; font-size:13px; line-height:1.6;}\n#ea-root .ea-identity.ok{background:#EAF7EC; border:1px solid var(--green); color:#1f5128;}\n#ea-root .ea-identity.warn{background:#FFF6E9; border:1px solid var(--amber); color:#7a4a00;}\n#ea-root .ea-identity .who{font-weight:700;}\n#ea-root .ea-q{font-size:17px; font-weight:500; margin:0 0 18px; color:#111827;}\n#ea-root .ea-opt{display:flex; align-items:flex-start; gap:10px; border:1.5px solid var(--lgray); border-radius:10px; padding:12px 14px; margin-bottom:10px; cursor:pointer; transition:.15s; background:#fff;}\n#ea-root .ea-opt:hover{border-color:var(--blue); background:var(--lblue);}\n#ea-root .ea-opt.sel{border-color:var(--blue); background:var(--lblue);}\n#ea-root .ea-opt.correct{border-color:var(--green); background:#EAF7EC;}\n#ea-root .ea-opt.wrong{border-color:var(--red); background:#FBEAEA;}\n#ea-root .ea-opt .k{flex:0 0 26px; height:26px; border-radius:50%; background:#F3F4F6; color:var(--navy); font-weight:700; font-size:13px; display:flex; align-items:center; justify-content:center;}\n#ea-root .ea-opt.sel .k{background:var(--blue); color:#fff;}\n#ea-root .ea-opt.correct .k{background:var(--green); color:#fff;}\n#ea-root .ea-opt.wrong .k{background:var(--red); color:#fff;}\n#ea-root .ea-opt .t{flex:1; padding-top:2px;}\n/* فراغات فعلية */\n#ea-root .fill{border-bottom:2.5px solid var(--blue); padding:0 10px; color:var(--blue); font-weight:700; min-width:120px; display:inline-block; text-align:center;}\n#ea-root .fill.empty{color:#9CA3AF; border-bottom-color:var(--lgray); letter-spacing:1px;}\n#ea-root .ea-blank{display:flex; align-items:center; gap:10px; margin:10px 0; flex-wrap:wrap;}\n#ea-root .ea-blank .bl-lbl{font-weight:700; color:var(--navy); min-width:64px;}\n#ea-root select.ea-sel{font-family:inherit; font-size:15px; padding:9px 12px; border:1.5px solid var(--lgray); border-radius:9px; background:#fff; min-width:150px; color:#111827;}\n/* سحب وإفلات */\n#ea-root .dnd-tray{display:flex; flex-wrap:wrap; gap:10px; margin:14px 0; padding:12px; background:#F6F8FB; border:1.5px dashed var(--lgray); border-radius:11px; min-height:56px;}\n#ea-root .dnd-tray .tray-label{width:100%; font-size:12.5px; color:var(--gray); margin-bottom:2px;}\n#ea-root .chip{background:#fff; border:1.5px solid var(--blue); color:var(--navy); border-radius:9px; padding:9px 13px; font-size:14px; font-weight:500; cursor:grab; touch-action:none; user-select:none; box-shadow:0 1px 2px rgba(0,0,0,.06); max-width:100%; line-height:1.5;}\n#ea-root .chip:active{cursor:grabbing;}\n#ea-root .chip.placed{cursor:default; box-shadow:none;}\n#ea-root .dragging-ghost{box-shadow:0 8px 20px rgba(0,0,0,.25)!important; cursor:grabbing; border-color:var(--navy)!important;}\n#ea-root .drop-zone{min-height:50px; border:2px dashed var(--lgray); border-radius:9px; padding:7px; display:flex; align-items:center; justify-content:center; transition:.12s; background:#fff; text-align:center;}\n#ea-root .drop-zone.over{border-color:var(--blue); background:var(--lblue);}\n#ea-root .drop-zone.filled{border-style:solid; border-color:var(--blue);}\n#ea-root .drop-zone.correct{border-color:var(--green); background:#EAF7EC; border-style:solid;}\n#ea-root .drop-zone.wrong{border-color:var(--red); background:#FBEAEA; border-style:solid;}\n#ea-root .drop-zone .zhint{color:#9CA3AF; font-size:13px;}\n#ea-root .dnd-rows .zone-row{display:flex; align-items:stretch; gap:10px; margin-bottom:10px;}\n#ea-root .dnd-rows .zone-key{flex:0 0 140px; background:var(--lblue); color:var(--navy); border-radius:9px; padding:11px 12px; font-weight:600; font-size:13.5px; display:flex; align-items:center;}\n#ea-root .dnd-rows .drop-zone{flex:1;}\n#ea-root .wbs{display:flex; flex-direction:column; align-items:center; margin:6px 0;}\n#ea-root .wbs .wrow{display:flex; align-items:center; gap:10px; width:100%; justify-content:center;}\n#ea-root .wbs .wnum{flex:0 0 34px; height:34px; border-radius:8px; background:var(--navy); color:#fff; font-weight:700; font-size:16px; display:flex; align-items:center; justify-content:center;}\n#ea-root .wbs .drop-zone{flex:1; max-width:280px;}\n#ea-root .wbs .pline{width:2px; height:16px; background:var(--gray);}\n#ea-root .ea-fb{border-radius:10px; padding:14px 16px; margin-top:14px; font-size:14.5px; display:none;}\n#ea-root .ea-fb.ok{background:#EAF7EC; border:1px solid var(--green);}\n#ea-root .ea-fb.no{background:#FBEAEA; border:1px solid var(--red);}\n#ea-root .ea-fb b{display:block; margin-bottom:6px; font-size:15px;}\n#ea-root .ea-fb.ok b{color:var(--green);} #ea-root .ea-fb.no b{color:var(--red);}\n#ea-root .ea-fb .sec{margin-top:8px; font-size:13px; color:#5B3FA8; background:#F4F0FC; border-radius:7px; padding:7px 10px;}\n#ea-root .ea-tiles{display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-bottom:6px;}\n#ea-root .tile{border-radius:10px; padding:16px 8px; text-align:center; cursor:pointer; font-weight:600; font-size:14px; border:2.5px solid transparent; transition:.12s;}\n#ea-root .tile.g{background:#EAF7EC; color:var(--green);}\n#ea-root .tile.y{background:#FFF6E9; color:var(--amber);}\n#ea-root .tile.r{background:#FBEAEA; color:var(--red);}\n#ea-root .tile.sel{border-color:var(--navy);}\n#ea-root .tile.correct{border-color:var(--green); box-shadow:0 0 0 2px #EAF7EC;}\n#ea-root .tile.wrong{border-color:var(--red);}\n#ea-root .tile .dot{display:inline-block; width:10px; height:10px; border-radius:50%; margin-left:6px; vertical-align:middle;}\n#ea-root .tile.g .dot{background:var(--green);} #ea-root .tile.y .dot{background:var(--amber);} #ea-root .tile.r .dot{background:var(--red);}\n#ea-root .ea-actions{display:flex; gap:10px; justify-content:space-between; margin-top:18px; flex-wrap:wrap;}\n#ea-root .ea-actions .right{display:flex; gap:10px;}\n#ea-root button.ea-btn{font-family:inherit; font-size:15px; font-weight:700; padding:11px 22px; border-radius:10px; border:none; cursor:pointer; transition:.15s;}\n#ea-root button.ea-primary{background:var(--navy); color:#fff;}\n#ea-root button.ea-primary:hover{background:var(--blue);}\n#ea-root button.ea-ghost{background:#fff; color:var(--navy); border:1.5px solid var(--navy);}\n#ea-root button.ea-ghost:disabled{color:#c7ccd1; border-color:var(--lgray); cursor:not-allowed;}\n#ea-root button.ea-mini{background:#fff; color:var(--red); border:1.5px solid var(--lgray); font-size:13px; padding:8px 14px;}\n#ea-root button.ea-mini:hover{border-color:var(--red);}\n#ea-root .ea-counter{font-size:13px; color:var(--gray); margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;}\n#ea-root .ea-score{text-align:center; padding:10px 0 18px;}\n#ea-root .ea-score .num{font-size:46px; font-weight:700; color:var(--navy);}\n#ea-root .ea-score .lbl{font-size:14px; color:var(--gray);}\n#ea-root .ea-diag h3{font-size:15px; color:var(--navy); margin:20px 0 6px; border-bottom:2px solid var(--lblue); padding-bottom:6px;}\n#ea-root .ea-diag .sub{font-size:12px; color:var(--gray); margin:0 0 10px;}\n#ea-root .ea-drow{margin-bottom:11px;}\n#ea-root .ea-drow .top{display:flex; justify-content:space-between; font-size:13.5px; margin-bottom:5px; gap:10px;}\n#ea-root .ea-drow .top .nm{font-weight:500;}\n#ea-root .ea-drow.enb .top .nm{font-weight:400; font-size:13px;}\n#ea-root .ea-drow.enb .code{color:#5B3FA8; font-weight:700;}\n#ea-root .ea-track{height:9px; background:var(--lgray); border-radius:99px; overflow:hidden;}\n#ea-root .ea-track > i{display:block; height:100%; border-radius:99px;}\n#ea-root .ea-weak{background:#FFF6E9; border:1px solid var(--amber); color:#7a4a00; font-size:12.5px; border-radius:7px; padding:4px 9px; display:inline-block; margin-top:3px;}\n#ea-root .ea-flaglist{font-size:13px;color:var(--amber);margin-top:14px;}\n#ea-root .ea-note{font-size:12.5px; color:var(--gray); text-align:center; margin-top:16px; padding:10px; background:#F9FAFB; border-radius:8px;}\n#ea-root .ea-empty{text-align:center;color:#9C2A2A;padding:30px;font-weight:500;}\n#ea-root .ea-err{text-align:center;padding:28px 20px;}\n#ea-root .ea-err .ee-ic{font-size:34px;margin-bottom:10px;}\n#ea-root .ea-err .ee-msg{font-size:15px;font-weight:600;color:#374151;margin-bottom:14px;line-height:1.7;}\n#ea-root .ea-err .ee-sub{font-size:12.5px;color:#6B7280;margin-bottom:6px;}\n#ea-root .ea-err .ee-code{display:inline-block;font-family:'Courier New',monospace;font-weight:700;font-size:15px;letter-spacing:.5px;color:#1F3B63;background:#EAF2FB;border:1px solid #BBD3EE;border-radius:8px;padding:6px 16px;direction:ltr;}\n/* ===== تقرير التشخيص (معاد تصميمه) ===== */\n#ea-root .rep-top{background:linear-gradient(135deg,var(--navy),var(--blue));color:#fff;border-radius:14px;padding:20px 22px;margin-bottom:18px;display:flex;align-items:center;gap:20px;flex-wrap:wrap;}\n#ea-root .rep-top .big{font-size:38px;font-weight:700;line-height:1;white-space:nowrap;}\n#ea-root .rep-top .col{display:flex;flex-direction:column;gap:5px;}\n#ea-root .rep-top .pct{font-size:18px;font-weight:700;padding:3px 13px;border-radius:99px;background:rgba(255,255,255,.2);display:inline-block;width:fit-content;}\n#ea-root .rep-top .lbl2{font-size:12.5px;opacity:.92;}\n#ea-root .rep-sec{margin-bottom:20px;}\n#ea-root .rep-sec > .h{font-size:15.5px;font-weight:700;color:var(--navy);margin:0 0 3px;}\n#ea-root .rep-sec > .hint{font-size:12px;color:var(--gray);margin:0 0 12px;}\n#ea-root .plan{border:1px solid var(--amber);background:#FFFBF4;border-radius:12px;padding:6px 16px 14px;}\n#ea-root .plan > .h{color:#9a5a00;font-size:15px;font-weight:700;margin:14px 0 6px;}\n#ea-root .plan-item{display:flex;gap:13px;align-items:center;padding:11px 0;border-top:1px dashed #EAD9BD;}\n#ea-root .plan-item.first{border-top:none;}\n#ea-root .plan-pct{flex:0 0 50px;height:50px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14.5px;color:#fff;}\n#ea-root .plan-body{flex:1;min-width:0;}\n#ea-root .plan-enb{font-weight:600;font-size:14px;color:#111827;margin-bottom:3px;}\n#ea-root .plan-enb .code{color:#5B3FA8;font-weight:700;}\n#ea-root .plan-go{font-size:13px;color:var(--blue);font-weight:500;}\n#ea-root .plan-ok{color:#1f5128;font-weight:600;font-size:14px;padding:10px 0;}\n#ea-root .plan-more{font-size:12.5px;color:var(--gray);margin-top:10px;}\n#ea-root .rep-card{border:1px solid var(--lgray);border-radius:11px;padding:14px 16px;margin-bottom:10px;}\n#ea-root .rep-card .ct{font-size:13px;font-weight:700;color:var(--gray);margin-bottom:11px;}\n#ea-root .rep-card .code{color:#5B3FA8;font-weight:700;}\n#ea-root .rep-flag2{background:#FFF6E9;border:1px solid var(--amber);color:#7a4a00;border-radius:10px;padding:10px 14px;font-size:13px;margin-bottom:16px;line-height:1.8;}\n#ea-root .rep-foot{font-size:12px;color:var(--gray);text-align:center;margin-bottom:16px;}\n\n/* ===== مركز المراجعة — شاشة الاختيار ===== */\n#ea-root .rev-intro{font-size:13.5px;color:var(--gray);margin-bottom:16px;text-align:center;line-height:1.7;}\n#ea-root .rev-cats{display:flex;flex-direction:column;gap:11px;margin-bottom:18px;}\n#ea-root .rev-cat{display:flex;align-items:center;gap:13px;border:2px solid var(--lgray);border-radius:12px;padding:14px 16px;cursor:pointer;transition:.15s;background:#fff;}\n#ea-root .rev-cat:hover{border-color:var(--blue);}\n#ea-root .rev-cat.on{border-color:var(--blue);background:var(--lblue);}\n#ea-root .rev-cat.dis{opacity:.5;cursor:not-allowed;background:#FAFAFA;}\n#ea-root .rev-cat input{width:20px;height:20px;accent-color:var(--blue);cursor:inherit;flex:0 0 auto;}\n#ea-root .rev-ic{font-size:22px;font-weight:700;flex:0 0 26px;text-align:center;}\n#ea-root .rev-body{flex:1;display:flex;flex-direction:column;gap:2px;min-width:0;}\n#ea-root .rev-name{font-weight:700;font-size:15px;color:#111827;}\n#ea-root .rev-desc{font-size:12.5px;color:var(--gray);}\n#ea-root .rev-n{flex:0 0 auto;color:#fff;font-weight:700;font-size:14px;min-width:34px;height:30px;border-radius:99px;display:flex;align-items:center;justify-content:center;padding:0 10px;}\n#ea-root .rev-sum{text-align:center;font-size:15px;color:var(--navy);margin-bottom:14px;}\n#ea-root .rev-sum b{font-size:18px;}\n#ea-root button.rev-start{width:100%;font-size:16px;padding:14px;}\n#ea-root button.rev-start:disabled{background:var(--lgray);color:#9CA3AF;cursor:not-allowed;}\n#ea-root .rev-empty-hint{text-align:center;font-size:13px;color:#1f5128;background:#EAF7EC;border:1px solid var(--green);border-radius:9px;padding:10px;margin-top:14px;}\n#ea-root .rev-badges{display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap;}\n#ea-root .rev-badge{font-size:11.5px;font-weight:700;padding:3px 10px;border-radius:99px;}\n#ea-root .rev-badge.flag{background:#FFF6E9;color:var(--amber);}\n#ea-root .rev-badge.wrong{background:#FBEAEA;color:var(--red);}\n#ea-root .rev-badge.unsolved{background:#F3F4F6;color:var(--gray);}\n#ea-root[dir=\"ltr\"]{text-align:left;}\n#ea-root[dir=\"ltr\"] .ea-modal{text-align:left;}\n#ea-root[dir=\"ltr\"] .ea-modal .opt{text-align:left;}";
  var styleEl=document.createElement("style"); styleEl.textContent=CSS; document.head.appendChild(styleEl);
  var root=document.getElementById("ea-root");
  if(!root){ console.error("[ExamAce] no ea-root element"); return; }
  root.setAttribute("dir", RTL?"rtl":"ltr");
  var H1=(MODE==="review")?("📋 "+t("مركز المراجعة")):("ExamAce — "+t("تدرّب"));
  var BAR=(MODE==="review")?'<div class="ea-bar" id="ea-barwrap" style="display:none"><i id="ea-prog"></i></div>':'<div class="ea-bar"><i id="ea-prog"></i></div>';
  var NOTE=(MODE==="review")?t("المراجعة تجمع أسئلتك من كل المهمات. إجاباتك هنا تُحدّث تقدّمك (الإجابة الصحيحة تُخرج السؤال من «أخطأت فيها»)."):t("تقدّمك وتمييزك محفوظان في حسابك ويُستعادان عبر أجهزتك. التشخيص بالممكّن يزداد دقّةً مع توسّع البنك (الهدف ≈ 5 أسئلة لكل ممكّن).");
  root.innerHTML='<div class="ea-head"><h1>'+H1+'</h1><p id="ea-sub">'+t("جارٍ التحميل…")+'</p>'+BAR+'</div><div id="ea-identity"></div><div id="ea-stage"></div><div class="ea-note">'+NOTE+'</div>';
  if(MODE==="practice"){
/* ===== محرّك التدرّب ===== */

(function(){
  // المهمة: تجاوزٌ يدويٌّ إن وُجد EA_TASK، وإلا تُشتقّ من عنوان الدرس (document.title)
  function deriveTask(){
    if(typeof EA_TASK!=="undefined" && EA_TASK) return String(EA_TASK);
    try{
      var m=String(document.title||'').match(/(\d{1,2})\.(\d{1,2})/);
      if(m) return m[1]+"."+m[2];
    }catch(e){}
    return null; // فشل الاشتقاق
  }
  var TASK = deriveTask();

  var CASES = {};   // تُجلب من Supabase (جدول cases)
  var FIGURES = {}; // تُجلب من Supabase (جدول figures)

  var ALLDATA = []; // تُجلب من Supabase (جدول questions)

  var DATA = [];
  var caseFirst = {};
  function isFirstOfCase(idx){ var d=DATA[idx]; return !!(d.caseId && caseFirst[d.caseId]===idx); }
  function caseBox(d,st,isFirst){
    if(!d.caseId) return '';
    var text=esc(CASES[d.caseId]||'');
    if(isFirst){
      return t('<div class="ea-case"><div class="case-bar"><b>📋 دراسة الحالة</b><span style="font-size:12px;color:var(--gray)">تخدم عدة أسئلة</span></div><div style="margin-top:8px">')+text+'</div></div>';
    }
    var open=!!st.caseOpen;
    return t('<div class="ea-case"><div class="case-bar"><b>📋 دراسة الحالة</b><button class="case-toggle" id="case-toggle">')+(open?t('اخفِ ▲'):t('اعرض دراسة الحالة ▼'))+'</button></div><div class="case-body" id="case-body" style="display:'+(open?'block':'none')+';margin-top:8px">'+text+'</div></div>';
  }

  function figSVG(kind){ return FIGURES[kind] || ''; }

  var stage=document.getElementById('ea-stage');
  var prog=document.getElementById('ea-prog');
  var sub=document.getElementById('ea-sub');

  // ===== قراءة الهوية تلقائيا من Teachable (#fedora-data) =====
  function readIdentity(){
    try{
      var el=document.getElementById('fedora-data');
      if(el && el.getAttribute('data-id')){
        return { id:el.getAttribute('data-id'), email:el.getAttribute('data-email')||'', name:el.getAttribute('data-name')||'' };
      }
    }catch(e){}
    return null;
  }
  var EA_USER = readIdentity();

  // ===== ربط Supabase (تخزين التقدّم عبر REST) =====
  var SUPA_URL = "https://lwsrrvhskpzhzaokghdf.supabase.co";
  var SUPA_KEY = "sb_publishable_Kyoc9tDlTmsuBRkD9gZX2Q_O-HtkmpM";
  var GUARD = SUPA_URL + "/functions/v1/swift-responder"; // الحارس: يخدم المحتوى المحمي
  var COURSE   = (typeof EA_COURSE!=="undefined") ? EA_COURSE : "ar";
  var SYNC_ON  = !!(EA_USER && EA_USER.id);
  var _idBase  = "";

  function showIdentity(syncMsg){
    var box=document.getElementById('ea-identity');
    if(!box) return;
    if(EA_USER){
      box.className='ea-identity ok';
      _idBase=t('✓ تم التعرّف عليك تلقائيا: <span class="who">')+(EA_USER.name||'—')+'</span> · '+(EA_USER.email||'')+t(' · معرّف ')+EA_USER.id;
    } else {
      box.className='ea-identity warn';
      _idBase=t('تعذّر التعرّف على الهوية تلقائيا (خارج Teachable؟) — التخزين السحابي يعمل داخل Teachable فقط.');
    }
    box.innerHTML=_idBase + (syncMsg ? (' · '+syncMsg) : '');
  }
  showIdentity(SYNC_ON ? t('⏳ مزامنة التقدّم...') : '');

  function supaHeaders(extra){
    var h={ "apikey":SUPA_KEY, "Authorization":"Bearer "+SUPA_KEY, "Content-Type":"application/json" };
    if(extra){ for(var k in extra){ h[k]=extra[k]; } }
    return h;
  }
  function loadProgress(cb){
    if(!SYNC_ON){ cb(); return; }
    var url=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)
          +"&course=eq."+encodeURIComponent(COURSE)+"&select=question_id,answered,correct,flagged,choice";
    fetch(url,{ headers:supaHeaders() })
      .then(function(r){ return r.ok ? r.json() : []; })
      .then(function(rows){
        (rows||[]).forEach(function(row){
          var st=state[row.question_id];
          if(st){ st.answered=!!row.answered; st.correct=!!row.correct; st.flag=!!row.flagged; st.choice=(row.choice===undefined?null:row.choice); }
        });
        showIdentity(t('☁️ تقدّمك محفوظ سحابيا'));
        cb();
      })
      .catch(function(){ showIdentity(t('⚠️ تعذّرت المزامنة — وضع محلي')); cb(); });
  }
  function saveProgress(qid){
    if(!SYNC_ON) return;
    var st=state[qid];
    var body=[{ student_id:String(EA_USER.id), course:COURSE, question_id:qid,
      answered:!!st.answered, correct:!!st.correct, flagged:!!st.flag,
      choice:(st.choice===undefined?null:st.choice), updated_at:new Date().toISOString() }];
    fetch(SUPA_URL+"/rest/v1/progress",{ method:"POST", headers:supaHeaders({ "Prefer":"resolution=merge-duplicates" }), body:JSON.stringify(body) })
      .then(function(r){ if(!r.ok){ showIdentity(t('⚠️ تعذّر حفظ آخر تغيير')); } })
      .catch(function(){ showIdentity(t('⚠️ تعذّر حفظ آخر تغيير — تحقّق من الاتصال')); });
  }
  function clearProgress(cb){
    if(!SYNC_ON){ if(cb)cb(); return; }
    var url=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)+"&course=eq."+encodeURIComponent(COURSE);
    fetch(url,{ method:"DELETE", headers:supaHeaders() }).then(function(){ if(cb)cb(); }).catch(function(){ if(cb)cb(); });
  }

  // ===== الإبلاغ عن سؤال =====
  function openReport(qid){
    var KINDS=[
      ["wrong_answer",t("⚠️ الإجابة المعتمدة خاطئة")],
      ["typo",t("📝 خطأ لغويّ أو إملائيّ")],
      ["unclear",t("❓ السؤال أو الخيارات غير واضحة")],
      ["figure",t("🔢 مشكلة في الشكل أو الأرقام")],
      ["other",t("➕ أخرى")]
    ];
    var sel=null;
    var root=document.getElementById('ea-root');
    var bg=document.createElement('div'); bg.className='ea-modal-bg';
    var opts=KINDS.map(function(k){ return '<button class="opt" data-k="'+k[0]+'">'+k[1]+'</button>'; }).join('');
    bg.innerHTML='<div class="ea-modal">'+
      t('<h3>إبلاغ عن مشكلة</h3>')+
      t('<div class="sub">اختر نوع المشكلة في هذا السؤال:</div>')+
      opts+
      t('<textarea id="ea-rnote" placeholder="ملاحظة (اختيارية) — صف المشكلة بإيجاز..."></textarea>')+
      t('<div class="req" id="ea-rreq">يُرجى كتابة ملاحظة عند اختيار «أخرى».</div>')+
      t('<div class="row"><button class="cancel" id="ea-rcancel">إلغاء</button>')+
      t('<button class="send" id="ea-rsend" disabled>إرسال</button></div>');
    root.appendChild(bg);
    var sendBtn=bg.querySelector('#ea-rsend'), note=bg.querySelector('#ea-rnote'), req=bg.querySelector('#ea-rreq');
    function refresh(){
      var ok = sel && (sel!=='other' || note.value.trim().length>0);
      sendBtn.disabled=!ok;
      req.style.display = (sel==='other' && note.value.trim().length===0) ? 'block' : 'none';
    }
    bg.querySelectorAll('.opt').forEach(function(b){
      b.onclick=function(){
        bg.querySelectorAll('.opt').forEach(function(x){ x.classList.remove('sel'); });
        b.classList.add('sel'); sel=b.getAttribute('data-k'); refresh();
      };
    });
    note.oninput=refresh;
    bg.querySelector('#ea-rcancel').onclick=function(){ bg.remove(); };
    bg.onclick=function(e){ if(e.target===bg) bg.remove(); };
    sendBtn.onclick=function(){
      sendBtn.disabled=true; sendBtn.textContent=t('جارٍ الإرسال...');
      var sid=(EA_USER&&EA_USER.id)?String(EA_USER.id):'anon';
      var url=GUARD+'?type=report&course='+encodeURIComponent(COURSE)+'&sid='+encodeURIComponent(sid);
      fetch(url,{ method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ question_id:qid, kind:sel, note:note.value.trim() }) })
        .then(function(r){ if(!r.ok) throw new Error(r.status);
          bg.querySelector('.ea-modal').innerHTML=t('<div class="ok-msg">✅ شكرًا — وصل بلاغك.</div>');
          setTimeout(function(){ bg.remove(); }, 1400);
        })
        .catch(function(){ sendBtn.disabled=false; sendBtn.textContent=t('إرسال');
          req.textContent=t('تعذّر الإرسال — تحقّق من الاتصال وحاول ثانيةً.'); req.style.display='block'; });
    };
  }

  var state={};
  var i=0;
  var dndPlace={};
  function clone(o){ return JSON.parse(JSON.stringify(o)); }
  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  var _lastErr=null;
  function showError(code, userMsg, detail){
    try{ if(detail!==undefined) console.error('[ExamAce '+code+']', detail); }catch(e){}
    var safe=String(code||'ERR').replace(/[^A-Za-z0-9-]/g,'');
    if(typeof sub!=="undefined" && sub) sub.textContent=userMsg||t("حدث خطأ");
    stage.innerHTML='<div class="ea-card"><div class="ea-err"><div class="ee-ic">⚠️</div>'
      +'<div class="ee-msg">'+(userMsg||t("حدث خطأ غير متوقّع"))+'</div>'
      +t('<div class="ee-sub">إذا تكرّر، راسلنا بهذا الرمز:</div>')
      +'<div class="ee-code">'+safe+'</div></div></div>';
  }
  function answeredCount(){ return DATA.filter(function(d){return state[d.id].answered;}).length; }
  function findChip(d,id){ for(var k=0;k<d.chips.length;k++){if(d.chips[k][0]===id)return d.chips[k];} return null; }
  function findZone(d,key){ for(var k=0;k<d.zones.length;k++){if(d.zones[k][0]===key)return d.zones[k];} return null; }

  function pad(){
    var nc=0,nw=0,nf=0;
    DATA.forEach(function(d){ var s=state[d.id]; if(s.answered){ s.correct?nc++:nw++; } if(s.flag) nf++; });
    var nu=DATA.length-nc-nw;
    return '<div class="ea-stats"><span class="st-ok">✓ '+nc+t(' صحيحة</span>')+
           '<span class="st-bad">✗ '+nw+t(' خاطئة</span>')+
           '<span class="st-none">○ '+nu+t(' لم تُحل</span>')+
           '<span class="st-flag">🚩 '+nf+t(' مميّزة</span></div>');
  }

  function render(){
    var d=DATA[i], st=state[d.id];
    prog.style.width=(DATA.length?answeredCount()/DATA.length*100:0)+"%";
    var typeLabel;
    if(d.type==="single") typeLabel=t("اختيار من متعدد");
    else if(d.type==="multi") typeLabel=t("اختيار متعدد (اختر ")+d.ans.length+")";
    else if(d.type==="blanks") typeLabel=t("قائمة منسدلة — ملء فراغات");
    else if(d.type==="dnd") typeLabel=(d.dndLayout==="pyramid")?t("سحب وإفلات"):t("توصيل بالسحب");
    else if(d.type==="hotspot") typeLabel=t("نقر على الشكل");

    var h=pad();
    h+='<div class="ea-card">';
    h+=t('<div class="ea-counter"><span>السؤال ')+(i+1)+t(' من ')+DATA.length+(state[d.id].flag?' 🚩':'')+'</span>'+
      t('<span class="ea-jump">اذهب للسؤال: <input type="number" id="ea-go" min="1" max="')+DATA.length+'" value="'+(i+1)+'"></span></div>';
    h+='<div class="ea-meta"><span class="ea-chip dom">'+esc(d.dom)+t('</span><span class="ea-chip task">المهمة ')+esc(d.task)+t('</span><span class="ea-chip enb">ممكّن ')+esc(d.primary.code)+'</span><span class="ea-chip type">'+typeLabel+'</span><span class="ea-chip lvl">'+esc(d.lvl)+'</span>';
    h+='<button class="ea-flag'+(st.flag?' on':'')+'" id="ea-flagbtn">'+(st.flag?t('🚩 مميّز'):t('🏳️ تمييز'))+'</button>';
    h+=t('<button class="ea-reportbtn" id="ea-reportbtn" title="إبلاغ عن مشكلة في السؤال">⚠️ إبلاغ</button></div>');
    if(d.caseId){ h+=caseBox(d,st,isFirstOfCase(i)); }
    if(d.fig){ h+='<div style="border:1px solid var(--lgray);border-radius:10px;padding:14px;margin-bottom:16px;background:#FAFBFC;text-align:center">'+figSVG(d.fig)+'</div>'; }
    h+='<p class="ea-q">'+esc(d.q)+'</p>';

    if(d.type==="single"||d.type==="multi"){
      h+='<div id="ea-opts">';
      d.opts.forEach(function(o){ h+='<div class="ea-opt" data-k="'+esc(o[0])+'"><span class="k">'+esc(o[0])+'</span><span class="t">'+esc(o[1])+'</span></div>'; });
      h+='</div>';
    } else if(d.type==="blanks"){
      var sent=esc(d.sentence).replace(/\{(\d)\}/g, function(m,n){ return '<span class="fill empty" id="fill'+n+'">__________</span>'; });
      h+='<div style="font-size:16px;font-weight:500;margin-bottom:16px;line-height:2.3">'+sent+'</div>';
      d.blanks.forEach(function(b,bi){
        h+='<div class="ea-blank"><span class="bl-lbl">'+esc(b.label)+':</span><select class="ea-sel bl" data-b="'+bi+t('"><option value="">— اختر —</option>');
        b.opts.forEach(function(o){ h+='<option value="'+esc(o)+'">'+esc(o)+'</option>'; });
        h+='</select></div>';
      });
    } else if(d.type==="dnd"){
      h+='<div id="dnd-zones"></div><div id="dnd-tray" class="dnd-tray"></div>';
    } else if(d.type==="hotspot"){
      h+='<div class="ea-tiles">';
      d.tiles.forEach(function(t){ h+='<div class="tile '+t.color+'" data-name="'+esc(t.name)+'"><span class="dot"></span>'+esc(t.name)+'</div>'; });
      h+='</div>';
    }

    h+='<div class="ea-fb" id="ea-fb"></div>';
    h+='<div class="ea-actions">';
    h+='<button class="ea-btn ea-ghost" id="ea-prev"'+(i===0?' disabled':'')+t('>→ السابق</button>');
    h+='<div class="right">';
    if(!st.answered){ h+=t('<button class="ea-btn ea-primary" id="ea-check">تحقّق</button>'); }
    h+='<button class="ea-btn ea-ghost" id="ea-next"'+(i===DATA.length-1?' disabled':'')+t('>التالي ←</button>');
    h+='</div></div>';
    h+=t('<div style="margin-top:14px;text-align:center"><button class="ea-btn ea-ghost" id="ea-results">عرض التشخيص</button> <button class="ea-btn ea-mini" id="ea-reset">إعادة الضبط</button></div>');
    h+='</div>';
    stage.innerHTML=h;

    if(d.type==="dnd"){ dndPlace = st.answered ? clone(st.choice) : {}; layoutDnd(); }
    restoreView();
    bind();
  }

  // ===== سحب وإفلات =====
  function layoutDnd(){
    var d=DATA[i], st=state[d.id];
    var zonesEl=stage.querySelector('#dnd-zones'), trayEl=stage.querySelector('#dnd-tray');
    if(!zonesEl||!trayEl) return;
    var placed=[]; for(var k in dndPlace){ placed.push(dndPlace[k]); }
    var trayHtml=t('<div class="tray-label">العناصر — اسحبها الى مواضعها:</div>');
    var remaining=0;
    d.chips.forEach(function(c){ if(placed.indexOf(c[0])===-1){ trayHtml+='<div class="chip" data-chip="'+esc(c[0])+'">'+esc(c[1])+'</div>'; remaining++; } });
    if(remaining===0){ trayHtml+=t('<div style="font-size:12.5px;color:var(--gray)">— تم وضع كل العناصر —</div>'); }
    trayEl.innerHTML=trayHtml;

    var zHtml='';
    if(d.dndLayout==="pyramid"){
      zHtml+='<div class="wbs">';
      d.zones.forEach(function(z,zi){
        zHtml+='<div class="wrow"><div class="wnum">'+z[0]+'</div>'+zoneInner(d,z,st)+'</div>';
        if(zi<d.zones.length-1) zHtml+='<div class="pline"></div>';
      });
      zHtml+='</div>';
    } else {
      zHtml+='<div class="dnd-rows">';
      d.zones.forEach(function(z){ zHtml+='<div class="zone-row"><div class="zone-key">'+esc(z[1])+'</div>'+zoneInner(d,z,st)+'</div>'; });
      zHtml+='</div>';
    }
    zonesEl.innerHTML=zHtml;
    if(!st.answered) attachDnd();
  }

  function zoneInner(d,z,st){
    var chipId=dndPlace[z[0]], cls="drop-zone", inner;
    if(chipId){
      var c=findChip(d,chipId);
      if(st.answered){
        cls+= (chipId===d.ans[z[0]]) ? " correct" : " wrong";
        inner='<div class="chip placed">'+esc(c[1])+'</div>';
      } else {
        cls+=" filled";
        inner='<div class="chip" data-chip="'+esc(chipId)+'">'+esc(c[1])+'</div>';
      }
    } else {
      inner='<span class="zhint">'+(d.dndLayout==="pyramid"?esc(z[1]):t('افلت الموقف هنا'))+'</span>';
    }
    return '<div class="'+cls+'" data-zone="'+z[0]+'">'+inner+'</div>';
  }

  function attachDnd(){
    stage.querySelectorAll('.chip[data-chip]').forEach(function(chip){
      chip.addEventListener('pointerdown', startDrag);
    });
  }

  function zoneAt(x,y){
    var el=document.elementFromPoint(x,y);
    while(el){ if(el.classList && el.classList.contains('drop-zone')) return el; el=el.parentElement; }
    return null;
  }

  function startDrag(e){
    e.preventDefault();
    var chip=e.currentTarget, chipId=chip.getAttribute('data-chip');
    var rect=chip.getBoundingClientRect();
    var ghost=chip.cloneNode(true);
    ghost.classList.add('dragging-ghost');
    ghost.style.position='fixed'; ghost.style.margin='0';
    ghost.style.left=rect.left+'px'; ghost.style.top=rect.top+'px';
    ghost.style.width=rect.width+'px'; ghost.style.pointerEvents='none';
    ghost.style.zIndex='99999'; ghost.style.opacity='0.92';
    document.body.appendChild(ghost);
    chip.style.opacity='0.25';
    var ox=e.clientX-rect.left, oy=e.clientY-rect.top;
    function move(ev){
      ev.preventDefault();
      ghost.style.left=(ev.clientX-ox)+'px';
      ghost.style.top=(ev.clientY-oy)+'px';
      var z=zoneAt(ev.clientX,ev.clientY);
      stage.querySelectorAll('.drop-zone').forEach(function(dz){ dz.classList.toggle('over', dz===z); });
    }
    function up(ev){
      document.removeEventListener('pointermove',move,{passive:false});
      document.removeEventListener('pointerup',up);
      if(ghost.parentNode) ghost.remove();
      var z=zoneAt(ev.clientX,ev.clientY);
      for(var k in dndPlace){ if(dndPlace[k]===chipId) delete dndPlace[k]; }
      if(z){ dndPlace[z.getAttribute('data-zone')]=chipId; }
      layoutDnd();
    }
    document.addEventListener('pointermove',move,{passive:false});
    document.addEventListener('pointerup',up);
  }

  function restoreView(){
    var d=DATA[i], st=state[d.id];
    if(!st.answered) return;
    if(d.type==="single"||d.type==="multi"){
      stage.querySelectorAll('.ea-opt').forEach(function(el){
        var k=el.getAttribute('data-k');
        var isAns=(d.type==="single")?(k===d.ans):(d.ans.indexOf(k)>-1);
        var wasSel=(d.type==="single")?(k===st.choice):(st.choice&&st.choice.indexOf(k)>-1);
        if(isAns) el.classList.add('correct'); else if(wasSel) el.classList.add('wrong');
        el.style.cursor='default';
      });
    } else if(d.type==="blanks"){
      stage.querySelectorAll('.bl').forEach(function(s){
        var v=st.choice[s.getAttribute('data-b')]; s.value=v; s.disabled=true;
        var sp=document.getElementById('fill'+s.getAttribute('data-b'));
        if(sp){ sp.textContent=v||'__________'; if(v){sp.classList.remove('empty');} }
      });
    } else if(d.type==="hotspot"){
      stage.querySelectorAll('.tile').forEach(function(t){
        var nm=t.getAttribute('data-name');
        if(nm===d.ans) t.classList.add('correct');
        if(nm===st.choice && nm!==d.ans) t.classList.add('wrong');
        if(nm===st.choice) t.classList.add('sel');
        t.style.cursor='default';
      });
    }
    // dnd already laid out in render() via layoutDnd with answered state
    showFB(d,st.correct);
  }

  function ansText(d){
    if(d.type==="single") return d.ans;
    if(d.type==="multi") return d.ans.join("، ");
    if(d.type==="blanks") return d.blanks.map(function(b){return b.label+": "+b.ans;}).join("، ");
    if(d.type==="dnd") return d.zones.map(function(z){ var c=findChip(d,d.ans[z[0]]); return z[1]+" → "+(c?c[1]:''); }).join("؛ ");
    if(d.type==="hotspot") return d.ans;
    return "";
  }

  function showFB(d,correct){
    var fb=document.getElementById('ea-fb');
    if(!fb) return;
    fb.className='ea-fb '+(correct?'ok':'no');
    var h='<b>'+(correct?t("إجابة صحيحة ✓"):t("إجابة غير صحيحة ✗"))+'</b>';
    if(!correct){ h+=t('<div style="margin-bottom:6px">الإجابة الصحيحة: <b style="display:inline">')+esc(ansText(d))+'</b></div>'; }
    h+=esc(d.exp);
    if(d.secondary && d.secondary.length){ h+=t('<div class="sec">↪ يلمس أيضا (لا يُحتسب): ')+esc(d.secondary.join(" · "))+'</div>'; }
    fb.innerHTML=h; fb.style.display='block';
  }

  function bind(){
    var d=DATA[i], st=state[d.id];
    if((d.type==="single"||d.type==="multi") && !st.answered){
      var opts=stage.querySelectorAll('.ea-opt');
      opts.forEach(function(el){
        el.onclick=function(){
          if(d.type==="single"){ opts.forEach(function(x){x.classList.remove('sel');}); el.classList.add('sel'); }
          else { el.classList.toggle('sel'); }
        };
      });
    }
    if(d.type==="blanks" && !st.answered){
      stage.querySelectorAll('.bl').forEach(function(s){
        s.onchange=function(){
          var sp=document.getElementById('fill'+s.getAttribute('data-b'));
          sp.textContent=s.value||'__________';
          if(s.value){sp.classList.remove('empty');} else {sp.classList.add('empty');}
        };
      });
    }
    if(d.type==="hotspot" && !st.answered){
      var tiles=stage.querySelectorAll('.tile');
      tiles.forEach(function(t){ t.onclick=function(){ tiles.forEach(function(x){x.classList.remove('sel');}); t.classList.add('sel'); }; });
    }
    var chk=document.getElementById('ea-check'); if(chk) chk.onclick=check;
    document.getElementById('ea-prev').onclick=function(){ if(i>0){i--;render();} };
    document.getElementById('ea-next').onclick=function(){ if(i<DATA.length-1){i++;render();} };
    document.getElementById('ea-results').onclick=results;
    document.getElementById('ea-reset').onclick=reset;
    document.getElementById('ea-flagbtn').onclick=function(){ st.flag=!st.flag; saveProgress(d.id); render(); };
    var rb=document.getElementById('ea-reportbtn'); if(rb){ rb.onclick=function(){ openReport(d.id); }; }
    var ct=document.getElementById('case-toggle');
    if(ct){ ct.onclick=function(){ var body=document.getElementById('case-body'); var open=(body.style.display==='none'); body.style.display=open?'block':'none'; ct.textContent=open?t('اخفِ ▲'):t('اعرض دراسة الحالة ▼'); st.caseOpen=open; }; }
    var go=document.getElementById('ea-go');
    if(go){ go.onchange=function(){ var n=parseInt(go.value,10); if(n>=1 && n<=DATA.length){ i=n-1; render(); } else { go.value=i+1; } };
            go.onkeydown=function(e){ if(e.key==='Enter'){ e.preventDefault(); go.blur(); } }; }
  }

  function check(){
    var d=DATA[i], st=state[d.id], correct=false, choice;
    if(d.type==="single"){
      var c=stage.querySelector('.ea-opt.sel'); if(!c){alert(t("اختر اجابة اولا"));return;}
      choice=c.getAttribute('data-k'); correct=(choice===d.ans);
    } else if(d.type==="multi"){
      var cs=stage.querySelectorAll('.ea-opt.sel'); if(cs.length===0){alert(t("اختر ")+d.ans.length+t(" اجابات"));return;}
      choice=[]; cs.forEach(function(x){choice.push(x.getAttribute('data-k'));});
      correct=(choice.length===d.ans.length && d.ans.every(function(a){return choice.indexOf(a)>-1;}));
    } else if(d.type==="blanks"){
      var sels=stage.querySelectorAll('.bl'); choice={}; var any=true; correct=true;
      sels.forEach(function(s){ var idx=s.getAttribute('data-b'), v=s.value; choice[idx]=v; if(!v)any=false; if(d.blanks[idx].ans!==v)correct=false; });
      if(!any){alert(t("اكمل كل الفراغات"));return;}
    } else if(d.type==="dnd"){
      var allFilled=d.zones.every(function(z){return dndPlace[z[0]];});
      if(!allFilled){alert(t("اسحب كل العناصر الى مواضعها"));return;}
      correct=d.zones.every(function(z){return dndPlace[z[0]]===d.ans[z[0]];});
      choice=clone(dndPlace);
    } else if(d.type==="hotspot"){
      var sel=stage.querySelector('.tile.sel'); if(!sel){alert(t("انقر مقياسا اولا"));return;}
      choice=sel.getAttribute('data-name'); correct=(choice===d.ans);
    }
    st.answered=true; st.correct=correct; st.choice=choice;
    saveProgress(d.id);
    render();
  }

  function bar(label,s,extra){
    var p=s.t?Math.round(s.c/s.t*100):0, col=p>=70?"#2E7D32":p>=40?"#B26A00":"#9C2A2A";
    return '<div class="ea-drow'+(extra?' '+extra:'')+'"><div class="top"><span class="nm">'+label+'</span><span>'+s.c+'/'+s.t+'</span></div><div class="ea-track"><i style="width:'+p+'%;background:'+col+'"></i></div></div>';
  }

  function results(){
    var domStat={}, taskStat={}, enbList=[], enbMap={}, flagged=[];
    DATA.forEach(function(d){
      var st=state[d.id];
      if(!domStat[d.dom]) domStat[d.dom]={c:0,t:0};
      if(!taskStat[d.task]) taskStat[d.task]={c:0,t:0};
      if(!enbMap[d.primary.code]){ enbMap[d.primary.code]={c:0,t:0,title:d.primary.title,task:d.task}; enbList.push(d.primary.code); }
      if(st.answered){
        domStat[d.dom].t++; taskStat[d.task].t++; enbMap[d.primary.code].t++;
        if(st.correct){ domStat[d.dom].c++; taskStat[d.task].c++; enbMap[d.primary.code].c++; }
      }
      if(st.flag) flagged.push(d.id);
    });
    var ans=answeredCount();
    var score=DATA.filter(function(d){return state[d.id].correct;}).length;
    var pct=ans?Math.round(score/ans*100):0;

    // الممكّنات الضعيفة (<70% ومُجابة)، الأضعف أولا
    var weak=enbList.filter(function(c){ var s=enbMap[c]; return s.t>0 && (s.c/s.t*100)<70; })
      .sort(function(a,b){ return (enbMap[a].c/enbMap[a].t)-(enbMap[b].c/enbMap[b].t); });
    var unanswered=enbList.filter(function(c){ return enbMap[c].t===0; }).length;
    var SHOW=10; // أضعف 10 في الملخّص (المعيار النهائي)

    var h='<div class="ea-card">';
    // ── الملخّص ──
    h+='<div class="rep-top"><div class="big">'+score+' / '+ans+'</div><div class="col"><span class="pct">'+pct+t('% صحيحة</span><span class="lbl2">من ')+ans+t(' محلولة · ')+DATA.length+t(' سؤالا إجمالا</span></div></div>');

    // ── خطة المذاكرة (إجراء) ──
    h+=t('<div class="rep-sec"><div class="plan"><div class="h">📌 خطة المذاكرة — ابدأ بالأضعف</div>');
    if(weak.length){
      weak.slice(0,SHOW).forEach(function(c,ix){
        var s=enbMap[c], p=Math.round(s.c/s.t*100), col=(p>=40?'var(--amber)':'var(--red)');
        h+='<div class="plan-item'+(ix===0?' first':'')+'"><div class="plan-pct" style="background:'+col+'">'+p+'%</div>'
          +'<div class="plan-body"><div class="plan-enb"><span class="code">'+esc(c)+'</span> '+esc(s.title)+'</div>'
          +t('<div class="plan-go">← راجع درس المهمة ')+esc(s.task)+'</div></div></div>';
      });
      if(weak.length>SHOW){ h+='<div class="plan-more">+ '+(weak.length-SHOW)+t(' ممكّن آخر دون 70% (معروضة في التفصيل أدناه).</div>'); }
    } else {
      h+=t('<div class="plan-ok">✓ لا ممكّن دون 70% فيما حللت — أداء جيد. واصل لتغطية باقي الممكّنات.</div>');
    }
    if(unanswered>0){ h+='<div class="plan-more">• '+unanswered+t(' ممكّن لم تُجب عنه بعد — حلّه ليكتمل تشخيصك.</div>'); }
    h+='</div></div>';

    // ── التفصيل الكامل ──
    h+=t('<div class="rep-sec"><div class="h">📊 التفصيل الكامل</div><div class="hint">من العامّ (المجال) إلى الأدقّ (الممكّن). أحمر < 40% · برتقالي < 70% · أخضر ≥ 70%.</div>');
    h+=t('<div class="rep-card"><div class="ct">① حسب المجال</div>');
    Object.keys(domStat).forEach(function(dm){ h+=bar(esc(dm),domStat[dm]); });
    h+='</div>';
    h+=t('<div class="rep-card"><div class="ct">② حسب المهمة</div>');
    Object.keys(taskStat).forEach(function(tk){ h+=bar(esc(tk),taskStat[tk]); });
    h+='</div>';
    h+=t('<div class="rep-card"><div class="ct">③ حسب الممكّن (الأدقّ)</div>');
    enbList.forEach(function(c){ var s=enbMap[c]; h+=bar('<span class="code">'+esc(c)+'</span> '+esc(s.title), s, 'enb'); });
    h+='</div></div>';

    // ── المميّزة ──
    if(flagged.length){ h+=t('<div class="rep-flag2">🚩 أسئلة مميّزة للمراجعة: ')+esc(flagged.join("، "))+'</div>'; }

    h+=t('<div class="rep-foot">التشخيص بالممكّن يزداد موثوقيةً مع زيادة الأسئلة لكل ممكّن (الهدف ≈ 5).</div>');
    h+=t('<div class="ea-actions"><button class="ea-btn ea-primary" id="ea-back">العودة للأسئلة</button><div class="right"><button class="ea-btn ea-mini" id="ea-reset2">إعادة الضبط</button></div></div>');
    h+='</div>';
    stage.innerHTML=h;
    document.getElementById('ea-back').onclick=render;
    document.getElementById('ea-reset2').onclick=reset;
  }

  function reset(){
    if(!confirm(t("هل تريد إعادة ضبط كل التقدّم والبدء من جديد؟"))) return;
    DATA.forEach(function(d){ state[d.id]={answered:false,correct:false,choice:null,flag:false,caseOpen:false}; });
    i=0; dndPlace={};
    clearProgress(function(){ render(); });
  }

  var root=document.getElementById('ea-root');
  root.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  root.addEventListener('copy', function(e){ e.preventDefault(); });
  root.addEventListener('cut', function(e){ e.preventDefault(); });

  // ===== جلب الأسئلة + الحالات + الأشكال عبر الحارس =====
  function fetchQuestions(cb){
    sub.textContent=t("جارٍ تحميل الأسئلة...");
    var qUrl=GUARD+"?type=questions&course="+encodeURIComponent(COURSE);
    if(TASK!=="ALL"){ qUrl+="&task="+encodeURIComponent(TASK); }
    if(EA_USER && EA_USER.id) qUrl+="&sid="+encodeURIComponent(EA_USER.id);
    var cUrl=GUARD+"?type=cases&course="+encodeURIComponent(COURSE);
    var fUrl=GUARD+"?type=figures&course="+encodeURIComponent(COURSE);
    function getData(u){ return fetch(u).then(function(r){ if(!r.ok){ _lastErr={code:"ERR-GUARD", detail:"HTTP "+r.status}; return null; } return r.json(); }).then(function(j){ return j ? j.data : null; }).catch(function(e){ _lastErr={code:"ERR-NET", detail:String(e)}; return null; }); }
    function fail(){ var er=_lastErr||{code:"ERR-GUARD",detail:"no data"}; showError(er.code, (er.code==="ERR-NET"?t("تعذّر الاتصال بالخادم. تحقّق من اتصالك بالإنترنت."):t("تعذّر تحميل المحتوى حاليا.")), er.detail); }
    getData(qUrl).then(function(qdata){
      if(!qdata){ fail(); return; }
      ALLDATA = qdata; // الحارس يعيد كائنات الأسئلة مباشرة
      // الحالات والأشكال غير حرجة: تُحمّل بالتوازي، وإن غابت يكمل العمل
      return Promise.all([ getData(cUrl), getData(fUrl) ]).then(function(res){
        (res[0]||[]).forEach(function(c){ CASES[c.case_id]=c.text; });
        (res[1]||[]).forEach(function(f){ FIGURES[f.fig_id]=f.svg; });
        cb();
      });
    }).catch(function(){ fail(); });
  }

  function boot(){
    DATA = (TASK==="ALL") ? ALLDATA : ALLDATA.filter(function(d){ return d.taskCode===TASK; });
    caseFirst={};
    DATA.forEach(function(d,idx){ if(d.caseId && caseFirst[d.caseId]===undefined) caseFirst[d.caseId]=idx; });
    if(DATA.length===0){
      showError("ERR-EMPTY", t("لا توجد أسئلة متاحة لهذا الدرس بعد."), "task="+TASK+" course="+COURSE);
      return;
    }
    sub.textContent = (TASK==="ALL") ? (t("كل الأسئلة — ")+DATA.length+t(" سؤالا"))
      : (t("المهمة ")+DATA[0].task+" — "+DATA[0].dom+" · "+DATA.length+t(" أسئلة"));
    state={}; DATA.forEach(function(d){ state[d.id]={answered:false, correct:false, choice:null, flag:false, caseOpen:false}; });
    i=0; dndPlace={};
    loadProgress(function(){ render(); });
  }

  if(TASK===null){
    showError("ERR-TASK", t("تعذّر تحديد هذا الدرس. إذا تكرّر، تأكّد أنّ عنوان الدرس يبدأ برقم المهمة (مثل: 2.1)."), "document.title="+(document.title||""));
  } else {
    fetchQuestions(boot);
  }
})();

  } else {
/* ===== محرّك المراجعة ===== */

(function(){
  var TASK = "REVIEW"; // مركز المراجعة — ليس مهمّة واحدة

  // حالة المراجعة
  var PROGRESS = {};    // qid -> {answered,correct,flagged,choice}
  var COURSE_IDS = [];  // كل معرّفات أسئلة الكورس (خفيف)
  var CATS = { flag:[], wrong:[], unsolved:[] }; // التصنيف الثلاثي
  var SELECTED = { flag:true, wrong:true, unsolved:false }; // الاختيار الافتراضي

  var CASES = {};   // تُجلب من Supabase (جدول cases)
  var FIGURES = {}; // تُجلب من Supabase (جدول figures)

  var ALLDATA = []; // أسئلة المراجعة المنتقاة (تُجلب عند البدء)

  var DATA = [];
  var caseFirst = {};
  function isFirstOfCase(idx){ var d=DATA[idx]; return !!(d.caseId && caseFirst[d.caseId]===idx); }
  function caseBox(d,st,isFirst){
    if(!d.caseId) return '';
    var text=esc(CASES[d.caseId]||'');
    if(isFirst){
      return t('<div class="ea-case"><div class="case-bar"><b>📋 دراسة الحالة</b><span style="font-size:12px;color:var(--gray)">تخدم عدة أسئلة</span></div><div style="margin-top:8px">')+text+'</div></div>';
    }
    var open=!!st.caseOpen;
    return t('<div class="ea-case"><div class="case-bar"><b>📋 دراسة الحالة</b><button class="case-toggle" id="case-toggle">')+(open?t('اخفِ ▲'):t('اعرض دراسة الحالة ▼'))+'</button></div><div class="case-body" id="case-body" style="display:'+(open?'block':'none')+';margin-top:8px">'+text+'</div></div>';
  }

  function figSVG(kind){ return FIGURES[kind] || ''; }

  var stage=document.getElementById('ea-stage');
  var prog=document.getElementById('ea-prog');
  var sub=document.getElementById('ea-sub');

  // ===== قراءة الهوية تلقائيا من Teachable (#fedora-data) =====
  function readIdentity(){
    try{
      var el=document.getElementById('fedora-data');
      if(el && el.getAttribute('data-id')){
        return { id:el.getAttribute('data-id'), email:el.getAttribute('data-email')||'', name:el.getAttribute('data-name')||'' };
      }
    }catch(e){}
    return null;
  }
  var EA_USER = readIdentity();

  // ===== ربط Supabase (تخزين التقدّم عبر REST) =====
  var SUPA_URL = "https://lwsrrvhskpzhzaokghdf.supabase.co";
  var SUPA_KEY = "sb_publishable_Kyoc9tDlTmsuBRkD9gZX2Q_O-HtkmpM";
  var GUARD    = SUPA_URL + "/functions/v1/swift-responder"; // الحارس: المحتوى المحمي
  var COURSE   = (typeof EA_COURSE!=="undefined") ? EA_COURSE : "ar";
  var SYNC_ON  = !!(EA_USER && EA_USER.id);
  var _idBase  = "";

  function showIdentity(syncMsg){
    var box=document.getElementById('ea-identity');
    if(!box) return;
    if(EA_USER){
      box.className='ea-identity ok';
      _idBase=t('✓ تم التعرّف عليك تلقائيا: <span class="who">')+(EA_USER.name||'—')+'</span> · '+(EA_USER.email||'')+t(' · معرّف ')+EA_USER.id;
    } else {
      box.className='ea-identity warn';
      _idBase=t('تعذّر التعرّف على الهوية تلقائيا (خارج Teachable؟) — التخزين السحابي يعمل داخل Teachable فقط.');
    }
    box.innerHTML=_idBase + (syncMsg ? (' · '+syncMsg) : '');
  }
  showIdentity(SYNC_ON ? t('⏳ مزامنة التقدّم...') : '');

  function supaHeaders(extra){
    var h={ "apikey":SUPA_KEY, "Authorization":"Bearer "+SUPA_KEY, "Content-Type":"application/json" };
    if(extra){ for(var k in extra){ h[k]=extra[k]; } }
    return h;
  }
  function loadProgress(cb){
    if(!SYNC_ON){ cb(); return; }
    var url=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)
          +"&course=eq."+encodeURIComponent(COURSE)+"&select=question_id,answered,correct,flagged,choice";
    fetch(url,{ headers:supaHeaders() })
      .then(function(r){ return r.ok ? r.json() : []; })
      .then(function(rows){
        (rows||[]).forEach(function(row){
          var st=state[row.question_id];
          if(st){ st.answered=!!row.answered; st.correct=!!row.correct; st.flag=!!row.flagged; st.choice=(row.choice===undefined?null:row.choice); }
        });
        showIdentity(t('☁️ تقدّمك محفوظ سحابيا'));
        cb();
      })
      .catch(function(){ showIdentity(t('⚠️ تعذّرت المزامنة — وضع محلي')); cb(); });
  }
  function saveProgress(qid){
    if(!SYNC_ON) return;
    var st=state[qid];
    var body=[{ student_id:String(EA_USER.id), course:COURSE, question_id:qid,
      answered:!!st.answered, correct:!!st.correct, flagged:!!st.flag,
      choice:(st.choice===undefined?null:st.choice), updated_at:new Date().toISOString() }];
    fetch(SUPA_URL+"/rest/v1/progress",{ method:"POST", headers:supaHeaders({ "Prefer":"resolution=merge-duplicates" }), body:JSON.stringify(body) })
      .then(function(r){ if(!r.ok){ showIdentity(t('⚠️ تعذّر حفظ آخر تغيير')); } })
      .catch(function(){ showIdentity(t('⚠️ تعذّر حفظ آخر تغيير — تحقّق من الاتصال')); });
  }
  function clearProgress(cb){
    if(!SYNC_ON){ if(cb)cb(); return; }
    var url=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)+"&course=eq."+encodeURIComponent(COURSE);
    fetch(url,{ method:"DELETE", headers:supaHeaders() }).then(function(){ if(cb)cb(); }).catch(function(){ if(cb)cb(); });
  }

  var state={};
  var i=0;
  var dndPlace={};
  function clone(o){ return JSON.parse(JSON.stringify(o)); }
  function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  var _lastErr=null;
  function showError(code, userMsg, detail){
    try{ if(detail!==undefined) console.error('[ExamAce '+code+']', detail); }catch(e){}
    var safe=String(code||'ERR').replace(/[^A-Za-z0-9-]/g,'');
    if(typeof sub!=="undefined" && sub) sub.textContent=userMsg||t("حدث خطأ");
    stage.innerHTML='<div class="ea-card"><div class="ea-err"><div class="ee-ic">⚠️</div>'
      +'<div class="ee-msg">'+(userMsg||t("حدث خطأ غير متوقّع"))+'</div>'
      +t('<div class="ee-sub">إذا تكرّر، راسلنا بهذا الرمز:</div>')
      +'<div class="ee-code">'+safe+'</div></div></div>';
  }
  function answeredCount(){ return DATA.filter(function(d){return state[d.id].answered;}).length; }
  function findChip(d,id){ for(var k=0;k<d.chips.length;k++){if(d.chips[k][0]===id)return d.chips[k];} return null; }
  function findZone(d,key){ for(var k=0;k<d.zones.length;k++){if(d.zones[k][0]===key)return d.zones[k];} return null; }

  function pad(){
    var nc=0,nw=0,nf=0;
    DATA.forEach(function(d){ var s=state[d.id]; if(s.answered){ s.correct?nc++:nw++; } if(s.flag) nf++; });
    var nu=DATA.length-nc-nw;
    return '<div class="ea-stats"><span class="st-ok">✓ '+nc+t(' صحيحة</span>')+
           '<span class="st-bad">✗ '+nw+t(' خاطئة</span>')+
           '<span class="st-none">○ '+nu+t(' لم تُحل</span>')+
           '<span class="st-flag">🚩 '+nf+t(' مميّزة</span></div>');
  }

  // ===== الإبلاغ عن سؤال =====
  function openReport(qid){
    var KINDS=[
      ["wrong_answer",t("⚠️ الإجابة المعتمدة خاطئة")],
      ["typo",t("📝 خطأ لغويّ أو إملائيّ")],
      ["unclear",t("❓ السؤال أو الخيارات غير واضحة")],
      ["figure",t("🔢 مشكلة في الشكل أو الأرقام")],
      ["other",t("➕ أخرى")]
    ];
    var sel=null;
    var root=document.getElementById('ea-root');
    var bg=document.createElement('div'); bg.className='ea-modal-bg';
    var opts=KINDS.map(function(k){ return '<button class="opt" data-k="'+k[0]+'">'+k[1]+'</button>'; }).join('');
    bg.innerHTML='<div class="ea-modal">'+
      t('<h3>إبلاغ عن مشكلة</h3>')+
      t('<div class="sub">اختر نوع المشكلة في هذا السؤال:</div>')+
      opts+
      t('<textarea id="ea-rnote" placeholder="ملاحظة (اختيارية) — صف المشكلة بإيجاز..."></textarea>')+
      t('<div class="req" id="ea-rreq">يُرجى كتابة ملاحظة عند اختيار «أخرى».</div>')+
      t('<div class="row"><button class="cancel" id="ea-rcancel">إلغاء</button>')+
      t('<button class="send" id="ea-rsend" disabled>إرسال</button></div>');
    root.appendChild(bg);
    var sendBtn=bg.querySelector('#ea-rsend'), note=bg.querySelector('#ea-rnote'), req=bg.querySelector('#ea-rreq');
    function refresh(){
      var ok = sel && (sel!=='other' || note.value.trim().length>0);
      sendBtn.disabled=!ok;
      req.style.display = (sel==='other' && note.value.trim().length===0) ? 'block' : 'none';
    }
    bg.querySelectorAll('.opt').forEach(function(b){
      b.onclick=function(){
        bg.querySelectorAll('.opt').forEach(function(x){ x.classList.remove('sel'); });
        b.classList.add('sel'); sel=b.getAttribute('data-k'); refresh();
      };
    });
    note.oninput=refresh;
    bg.querySelector('#ea-rcancel').onclick=function(){ bg.remove(); };
    bg.onclick=function(e){ if(e.target===bg) bg.remove(); };
    sendBtn.onclick=function(){
      sendBtn.disabled=true; sendBtn.textContent=t('جارٍ الإرسال...');
      var sid=(EA_USER&&EA_USER.id)?String(EA_USER.id):'anon';
      var url=GUARD+'?type=report&course='+encodeURIComponent(COURSE)+'&sid='+encodeURIComponent(sid);
      fetch(url,{ method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ question_id:qid, kind:sel, note:note.value.trim() }) })
        .then(function(r){ if(!r.ok) throw new Error(r.status);
          bg.querySelector('.ea-modal').innerHTML=t('<div class="ok-msg">✅ شكرًا — وصل بلاغك.</div>');
          setTimeout(function(){ bg.remove(); }, 1400);
        })
        .catch(function(){ sendBtn.disabled=false; sendBtn.textContent=t('إرسال');
          req.textContent=t('تعذّر الإرسال — تحقّق من الاتصال وحاول ثانيةً.'); req.style.display='block'; });
    };
  }

  function render(){
    var d=DATA[i], st=state[d.id];
    var bw=document.getElementById('ea-barwrap'); if(bw) bw.style.display='block';
    prog.style.width=(DATA.length?answeredCount()/DATA.length*100:0)+"%";
    var typeLabel;
    if(d.type==="single") typeLabel=t("اختيار من متعدد");
    else if(d.type==="multi") typeLabel=t("اختيار متعدد (اختر ")+d.ans.length+")";
    else if(d.type==="blanks") typeLabel=t("قائمة منسدلة — ملء فراغات");
    else if(d.type==="dnd") typeLabel=(d.dndLayout==="pyramid")?t("سحب وإفلات"):t("توصيل بالسحب");
    else if(d.type==="hotspot") typeLabel=t("نقر على الشكل");

    var h=pad();
    h+='<div class="ea-card">';
    h+=t('<div class="ea-counter"><span>السؤال ')+(i+1)+t(' من ')+DATA.length+(state[d.id].flag?' 🚩':'')+'</span>'+
      t('<span class="ea-jump">اذهب للسؤال: <input type="number" id="ea-go" min="1" max="')+DATA.length+'" value="'+(i+1)+'"></span></div>';
    h+='<div class="ea-meta"><span class="ea-chip dom">'+esc(d.dom)+t('</span><span class="ea-chip task">المهمة ')+esc(d.task)+t('</span><span class="ea-chip enb">ممكّن ')+esc(d.primary.code)+'</span><span class="ea-chip type">'+typeLabel+'</span><span class="ea-chip lvl">'+esc(d.lvl)+'</span>';
    h+='<button class="ea-flag'+(st.flag?' on':'')+'" id="ea-flagbtn">'+(st.flag?t('🚩 مميّز'):t('🏳️ تمييز'))+'</button>';
    h+=t('<button class="ea-reportbtn" id="ea-reportbtn" title="إبلاغ عن مشكلة في السؤال">⚠️ إبلاغ</button></div>');
    if(d._badges){
      var bd='';
      if(d._badges.flag) bd+=t('<span class="rev-badge flag">🚩 مميّزة</span>');
      if(d._badges.wrong) bd+=t('<span class="rev-badge wrong">✗ أخطأت سابقا</span>');
      if(d._badges.unsolved) bd+=t('<span class="rev-badge unsolved">○ لم تُحلّ</span>');
      if(bd) h+='<div class="rev-badges">'+bd+'</div>';
    }
    if(d.caseId){ h+=caseBox(d,st,isFirstOfCase(i)); }
    if(d.fig){ h+='<div style="border:1px solid var(--lgray);border-radius:10px;padding:14px;margin-bottom:16px;background:#FAFBFC;text-align:center">'+figSVG(d.fig)+'</div>'; }
    h+='<p class="ea-q">'+esc(d.q)+'</p>';

    if(d.type==="single"||d.type==="multi"){
      h+='<div id="ea-opts">';
      d.opts.forEach(function(o){ h+='<div class="ea-opt" data-k="'+esc(o[0])+'"><span class="k">'+esc(o[0])+'</span><span class="t">'+esc(o[1])+'</span></div>'; });
      h+='</div>';
    } else if(d.type==="blanks"){
      var sent=esc(d.sentence).replace(/\{(\d)\}/g, function(m,n){ return '<span class="fill empty" id="fill'+n+'">__________</span>'; });
      h+='<div style="font-size:16px;font-weight:500;margin-bottom:16px;line-height:2.3">'+sent+'</div>';
      d.blanks.forEach(function(b,bi){
        h+='<div class="ea-blank"><span class="bl-lbl">'+esc(b.label)+':</span><select class="ea-sel bl" data-b="'+bi+t('"><option value="">— اختر —</option>');
        b.opts.forEach(function(o){ h+='<option value="'+esc(o)+'">'+esc(o)+'</option>'; });
        h+='</select></div>';
      });
    } else if(d.type==="dnd"){
      h+='<div id="dnd-zones"></div><div id="dnd-tray" class="dnd-tray"></div>';
    } else if(d.type==="hotspot"){
      h+='<div class="ea-tiles">';
      d.tiles.forEach(function(t){ h+='<div class="tile '+t.color+'" data-name="'+esc(t.name)+'"><span class="dot"></span>'+esc(t.name)+'</div>'; });
      h+='</div>';
    }

    h+='<div class="ea-fb" id="ea-fb"></div>';
    h+='<div class="ea-actions">';
    h+='<button class="ea-btn ea-ghost" id="ea-prev"'+(i===0?' disabled':'')+t('>→ السابق</button>');
    h+='<div class="right">';
    if(!st.answered){ h+=t('<button class="ea-btn ea-primary" id="ea-check">تحقّق</button>'); }
    h+='<button class="ea-btn ea-ghost" id="ea-next"'+(i===DATA.length-1?' disabled':'')+t('>التالي ←</button>');
    h+='</div></div>';
    h+=t('<div style="margin-top:14px;text-align:center"><button class="ea-btn ea-ghost" id="ea-results">عرض التشخيص</button> <button class="ea-btn ea-mini" id="ea-reset" style="color:var(--navy);border-color:var(--navy)">← مركز المراجعة</button></div>');
    h+='</div>';
    stage.innerHTML=h;

    if(d.type==="dnd"){ dndPlace = st.answered ? clone(st.choice) : {}; layoutDnd(); }
    restoreView();
    bind();
  }

  // ===== سحب وإفلات =====
  function layoutDnd(){
    var d=DATA[i], st=state[d.id];
    var zonesEl=stage.querySelector('#dnd-zones'), trayEl=stage.querySelector('#dnd-tray');
    if(!zonesEl||!trayEl) return;
    var placed=[]; for(var k in dndPlace){ placed.push(dndPlace[k]); }
    var trayHtml=t('<div class="tray-label">العناصر — اسحبها الى مواضعها:</div>');
    var remaining=0;
    d.chips.forEach(function(c){ if(placed.indexOf(c[0])===-1){ trayHtml+='<div class="chip" data-chip="'+esc(c[0])+'">'+esc(c[1])+'</div>'; remaining++; } });
    if(remaining===0){ trayHtml+=t('<div style="font-size:12.5px;color:var(--gray)">— تم وضع كل العناصر —</div>'); }
    trayEl.innerHTML=trayHtml;

    var zHtml='';
    if(d.dndLayout==="pyramid"){
      zHtml+='<div class="wbs">';
      d.zones.forEach(function(z,zi){
        zHtml+='<div class="wrow"><div class="wnum">'+z[0]+'</div>'+zoneInner(d,z,st)+'</div>';
        if(zi<d.zones.length-1) zHtml+='<div class="pline"></div>';
      });
      zHtml+='</div>';
    } else {
      zHtml+='<div class="dnd-rows">';
      d.zones.forEach(function(z){ zHtml+='<div class="zone-row"><div class="zone-key">'+esc(z[1])+'</div>'+zoneInner(d,z,st)+'</div>'; });
      zHtml+='</div>';
    }
    zonesEl.innerHTML=zHtml;
    if(!st.answered) attachDnd();
  }

  function zoneInner(d,z,st){
    var chipId=dndPlace[z[0]], cls="drop-zone", inner;
    if(chipId){
      var c=findChip(d,chipId);
      if(st.answered){
        cls+= (chipId===d.ans[z[0]]) ? " correct" : " wrong";
        inner='<div class="chip placed">'+esc(c[1])+'</div>';
      } else {
        cls+=" filled";
        inner='<div class="chip" data-chip="'+esc(chipId)+'">'+esc(c[1])+'</div>';
      }
    } else {
      inner='<span class="zhint">'+(d.dndLayout==="pyramid"?esc(z[1]):t('افلت الموقف هنا'))+'</span>';
    }
    return '<div class="'+cls+'" data-zone="'+z[0]+'">'+inner+'</div>';
  }

  function attachDnd(){
    stage.querySelectorAll('.chip[data-chip]').forEach(function(chip){
      chip.addEventListener('pointerdown', startDrag);
    });
  }

  function zoneAt(x,y){
    var el=document.elementFromPoint(x,y);
    while(el){ if(el.classList && el.classList.contains('drop-zone')) return el; el=el.parentElement; }
    return null;
  }

  function startDrag(e){
    e.preventDefault();
    var chip=e.currentTarget, chipId=chip.getAttribute('data-chip');
    var rect=chip.getBoundingClientRect();
    var ghost=chip.cloneNode(true);
    ghost.classList.add('dragging-ghost');
    ghost.style.position='fixed'; ghost.style.margin='0';
    ghost.style.left=rect.left+'px'; ghost.style.top=rect.top+'px';
    ghost.style.width=rect.width+'px'; ghost.style.pointerEvents='none';
    ghost.style.zIndex='99999'; ghost.style.opacity='0.92';
    document.body.appendChild(ghost);
    chip.style.opacity='0.25';
    var ox=e.clientX-rect.left, oy=e.clientY-rect.top;
    function move(ev){
      ev.preventDefault();
      ghost.style.left=(ev.clientX-ox)+'px';
      ghost.style.top=(ev.clientY-oy)+'px';
      var z=zoneAt(ev.clientX,ev.clientY);
      stage.querySelectorAll('.drop-zone').forEach(function(dz){ dz.classList.toggle('over', dz===z); });
    }
    function up(ev){
      document.removeEventListener('pointermove',move,{passive:false});
      document.removeEventListener('pointerup',up);
      if(ghost.parentNode) ghost.remove();
      var z=zoneAt(ev.clientX,ev.clientY);
      for(var k in dndPlace){ if(dndPlace[k]===chipId) delete dndPlace[k]; }
      if(z){ dndPlace[z.getAttribute('data-zone')]=chipId; }
      layoutDnd();
    }
    document.addEventListener('pointermove',move,{passive:false});
    document.addEventListener('pointerup',up);
  }

  function restoreView(){
    var d=DATA[i], st=state[d.id];
    if(!st.answered) return;
    if(d.type==="single"||d.type==="multi"){
      stage.querySelectorAll('.ea-opt').forEach(function(el){
        var k=el.getAttribute('data-k');
        var isAns=(d.type==="single")?(k===d.ans):(d.ans.indexOf(k)>-1);
        var wasSel=(d.type==="single")?(k===st.choice):(st.choice&&st.choice.indexOf(k)>-1);
        if(isAns) el.classList.add('correct'); else if(wasSel) el.classList.add('wrong');
        el.style.cursor='default';
      });
    } else if(d.type==="blanks"){
      stage.querySelectorAll('.bl').forEach(function(s){
        var v=st.choice[s.getAttribute('data-b')]; s.value=v; s.disabled=true;
        var sp=document.getElementById('fill'+s.getAttribute('data-b'));
        if(sp){ sp.textContent=v||'__________'; if(v){sp.classList.remove('empty');} }
      });
    } else if(d.type==="hotspot"){
      stage.querySelectorAll('.tile').forEach(function(t){
        var nm=t.getAttribute('data-name');
        if(nm===d.ans) t.classList.add('correct');
        if(nm===st.choice && nm!==d.ans) t.classList.add('wrong');
        if(nm===st.choice) t.classList.add('sel');
        t.style.cursor='default';
      });
    }
    // dnd already laid out in render() via layoutDnd with answered state
    showFB(d,st.correct);
  }

  function ansText(d){
    if(d.type==="single") return d.ans;
    if(d.type==="multi") return d.ans.join("، ");
    if(d.type==="blanks") return d.blanks.map(function(b){return b.label+": "+b.ans;}).join("، ");
    if(d.type==="dnd") return d.zones.map(function(z){ var c=findChip(d,d.ans[z[0]]); return z[1]+" → "+(c?c[1]:''); }).join("؛ ");
    if(d.type==="hotspot") return d.ans;
    return "";
  }

  function showFB(d,correct){
    var fb=document.getElementById('ea-fb');
    if(!fb) return;
    fb.className='ea-fb '+(correct?'ok':'no');
    var h='<b>'+(correct?t("إجابة صحيحة ✓"):t("إجابة غير صحيحة ✗"))+'</b>';
    if(!correct){ h+=t('<div style="margin-bottom:6px">الإجابة الصحيحة: <b style="display:inline">')+esc(ansText(d))+'</b></div>'; }
    h+=esc(d.exp);
    if(d.secondary && d.secondary.length){ h+=t('<div class="sec">↪ يلمس أيضا (لا يُحتسب): ')+esc(d.secondary.join(" · "))+'</div>'; }
    fb.innerHTML=h; fb.style.display='block';
  }

  function bind(){
    var d=DATA[i], st=state[d.id];
    if((d.type==="single"||d.type==="multi") && !st.answered){
      var opts=stage.querySelectorAll('.ea-opt');
      opts.forEach(function(el){
        el.onclick=function(){
          if(d.type==="single"){ opts.forEach(function(x){x.classList.remove('sel');}); el.classList.add('sel'); }
          else { el.classList.toggle('sel'); }
        };
      });
    }
    if(d.type==="blanks" && !st.answered){
      stage.querySelectorAll('.bl').forEach(function(s){
        s.onchange=function(){
          var sp=document.getElementById('fill'+s.getAttribute('data-b'));
          sp.textContent=s.value||'__________';
          if(s.value){sp.classList.remove('empty');} else {sp.classList.add('empty');}
        };
      });
    }
    if(d.type==="hotspot" && !st.answered){
      var tiles=stage.querySelectorAll('.tile');
      tiles.forEach(function(t){ t.onclick=function(){ tiles.forEach(function(x){x.classList.remove('sel');}); t.classList.add('sel'); }; });
    }
    var chk=document.getElementById('ea-check'); if(chk) chk.onclick=check;
    document.getElementById('ea-prev').onclick=function(){ if(i>0){i--;render();} };
    document.getElementById('ea-next').onclick=function(){ if(i<DATA.length-1){i++;render();} };
    document.getElementById('ea-results').onclick=results;
    document.getElementById('ea-reset').onclick=reset;
    document.getElementById('ea-flagbtn').onclick=function(){ st.flag=!st.flag; saveProgress(d.id); render(); };
    var rb=document.getElementById('ea-reportbtn'); if(rb){ rb.onclick=function(){ openReport(d.id); }; }
    var ct=document.getElementById('case-toggle');
    if(ct){ ct.onclick=function(){ var body=document.getElementById('case-body'); var open=(body.style.display==='none'); body.style.display=open?'block':'none'; ct.textContent=open?t('اخفِ ▲'):t('اعرض دراسة الحالة ▼'); st.caseOpen=open; }; }
    var go=document.getElementById('ea-go');
    if(go){ go.onchange=function(){ var n=parseInt(go.value,10); if(n>=1 && n<=DATA.length){ i=n-1; render(); } else { go.value=i+1; } };
            go.onkeydown=function(e){ if(e.key==='Enter'){ e.preventDefault(); go.blur(); } }; }
  }

  function check(){
    var d=DATA[i], st=state[d.id], correct=false, choice;
    if(d.type==="single"){
      var c=stage.querySelector('.ea-opt.sel'); if(!c){alert(t("اختر اجابة اولا"));return;}
      choice=c.getAttribute('data-k'); correct=(choice===d.ans);
    } else if(d.type==="multi"){
      var cs=stage.querySelectorAll('.ea-opt.sel'); if(cs.length===0){alert(t("اختر ")+d.ans.length+t(" اجابات"));return;}
      choice=[]; cs.forEach(function(x){choice.push(x.getAttribute('data-k'));});
      correct=(choice.length===d.ans.length && d.ans.every(function(a){return choice.indexOf(a)>-1;}));
    } else if(d.type==="blanks"){
      var sels=stage.querySelectorAll('.bl'); choice={}; var any=true; correct=true;
      sels.forEach(function(s){ var idx=s.getAttribute('data-b'), v=s.value; choice[idx]=v; if(!v)any=false; if(d.blanks[idx].ans!==v)correct=false; });
      if(!any){alert(t("اكمل كل الفراغات"));return;}
    } else if(d.type==="dnd"){
      var allFilled=d.zones.every(function(z){return dndPlace[z[0]];});
      if(!allFilled){alert(t("اسحب كل العناصر الى مواضعها"));return;}
      correct=d.zones.every(function(z){return dndPlace[z[0]]===d.ans[z[0]];});
      choice=clone(dndPlace);
    } else if(d.type==="hotspot"){
      var sel=stage.querySelector('.tile.sel'); if(!sel){alert(t("انقر مقياسا اولا"));return;}
      choice=sel.getAttribute('data-name'); correct=(choice===d.ans);
    }
    st.answered=true; st.correct=correct; st.choice=choice;
    saveProgress(d.id);
    render();
  }

  function bar(label,s,extra){
    var p=s.t?Math.round(s.c/s.t*100):0, col=p>=70?"#2E7D32":p>=40?"#B26A00":"#9C2A2A";
    return '<div class="ea-drow'+(extra?' '+extra:'')+'"><div class="top"><span class="nm">'+label+'</span><span>'+s.c+'/'+s.t+'</span></div><div class="ea-track"><i style="width:'+p+'%;background:'+col+'"></i></div></div>';
  }

  function results(){
    var domStat={}, taskStat={}, enbList=[], enbMap={}, flagged=[];
    DATA.forEach(function(d){
      var st=state[d.id];
      if(!domStat[d.dom]) domStat[d.dom]={c:0,t:0};
      if(!taskStat[d.task]) taskStat[d.task]={c:0,t:0};
      if(!enbMap[d.primary.code]){ enbMap[d.primary.code]={c:0,t:0,title:d.primary.title,task:d.task}; enbList.push(d.primary.code); }
      if(st.answered){
        domStat[d.dom].t++; taskStat[d.task].t++; enbMap[d.primary.code].t++;
        if(st.correct){ domStat[d.dom].c++; taskStat[d.task].c++; enbMap[d.primary.code].c++; }
      }
      if(st.flag) flagged.push(d.id);
    });
    var ans=answeredCount();
    var score=DATA.filter(function(d){return state[d.id].correct;}).length;
    var pct=ans?Math.round(score/ans*100):0;

    // الممكّنات الضعيفة (<70% ومُجابة)، الأضعف أولا
    var weak=enbList.filter(function(c){ var s=enbMap[c]; return s.t>0 && (s.c/s.t*100)<70; })
      .sort(function(a,b){ return (enbMap[a].c/enbMap[a].t)-(enbMap[b].c/enbMap[b].t); });
    var unanswered=enbList.filter(function(c){ return enbMap[c].t===0; }).length;
    var SHOW=10; // أضعف 10 في الملخّص (المعيار النهائي)

    var h='<div class="ea-card">';
    // ── الملخّص ──
    h+='<div class="rep-top"><div class="big">'+score+' / '+ans+'</div><div class="col"><span class="pct">'+pct+t('% صحيحة</span><span class="lbl2">من ')+ans+t(' محلولة · ')+DATA.length+t(' سؤالا إجمالا</span></div></div>');

    // ── خطة المذاكرة (إجراء) ──
    h+=t('<div class="rep-sec"><div class="plan"><div class="h">📌 خطة المذاكرة — ابدأ بالأضعف</div>');
    if(weak.length){
      weak.slice(0,SHOW).forEach(function(c,ix){
        var s=enbMap[c], p=Math.round(s.c/s.t*100), col=(p>=40?'var(--amber)':'var(--red)');
        h+='<div class="plan-item'+(ix===0?' first':'')+'"><div class="plan-pct" style="background:'+col+'">'+p+'%</div>'
          +'<div class="plan-body"><div class="plan-enb"><span class="code">'+esc(c)+'</span> '+esc(s.title)+'</div>'
          +t('<div class="plan-go">← راجع درس المهمة ')+esc(s.task)+'</div></div></div>';
      });
      if(weak.length>SHOW){ h+='<div class="plan-more">+ '+(weak.length-SHOW)+t(' ممكّن آخر دون 70% (معروضة في التفصيل أدناه).</div>'); }
    } else {
      h+=t('<div class="plan-ok">✓ لا ممكّن دون 70% فيما حللت — أداء جيد. واصل لتغطية باقي الممكّنات.</div>');
    }
    if(unanswered>0){ h+='<div class="plan-more">• '+unanswered+t(' ممكّن لم تُجب عنه بعد — حلّه ليكتمل تشخيصك.</div>'); }
    h+='</div></div>';

    // ── التفصيل الكامل ──
    h+=t('<div class="rep-sec"><div class="h">📊 التفصيل الكامل</div><div class="hint">من العامّ (المجال) إلى الأدقّ (الممكّن). أحمر < 40% · برتقالي < 70% · أخضر ≥ 70%.</div>');
    h+=t('<div class="rep-card"><div class="ct">① حسب المجال</div>');
    Object.keys(domStat).forEach(function(dm){ h+=bar(esc(dm),domStat[dm]); });
    h+='</div>';
    h+=t('<div class="rep-card"><div class="ct">② حسب المهمة</div>');
    Object.keys(taskStat).forEach(function(tk){ h+=bar(esc(tk),taskStat[tk]); });
    h+='</div>';
    h+=t('<div class="rep-card"><div class="ct">③ حسب الممكّن (الأدقّ)</div>');
    enbList.forEach(function(c){ var s=enbMap[c]; h+=bar('<span class="code">'+esc(c)+'</span> '+esc(s.title), s, 'enb'); });
    h+='</div></div>';

    // ── المميّزة ──
    if(flagged.length){ h+=t('<div class="rep-flag2">🚩 أسئلة مميّزة للمراجعة: ')+esc(flagged.join("، "))+'</div>'; }

    h+=t('<div class="rep-foot">التشخيص بالممكّن يزداد موثوقيةً مع زيادة الأسئلة لكل ممكّن (الهدف ≈ 5).</div>');
    h+=t('<div class="ea-actions"><button class="ea-btn ea-primary" id="ea-back">العودة للأسئلة</button><div class="right"><button class="ea-btn ea-mini" id="ea-reset2">إعادة الضبط</button></div></div>');
    h+='</div>';
    stage.innerHTML=h;
    document.getElementById('ea-back').onclick=render;
    document.getElementById('ea-reset2').onclick=reset;
  }

  // في المراجعة: زر «← مركز المراجعة» يعود للاختيار (لا يمسح التقدّم)
  function reset(){ backToHub(); }

  var root=document.getElementById('ea-root');
  root.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  root.addEventListener('copy', function(e){ e.preventDefault(); });
  root.addEventListener('cut', function(e){ e.preventDefault(); });

  // ============== منطق مركز المراجعة ==============
  function getJSON(u){ return fetch(u,{ headers:supaHeaders() }).then(function(r){ return r.ok ? r.json() : null; }).catch(function(){ return null; }); }
  function getGuard(u){ return fetch(u).then(function(r){ if(!r.ok){ _lastErr={code:"ERR-GUARD", detail:"HTTP "+r.status}; return null; } return r.json(); }).then(function(j){ return j ? j.data : null; }).catch(function(e){ _lastErr={code:"ERR-NET", detail:String(e)}; return null; }); }
  function sidParam(){ return (EA_USER && EA_USER.id) ? ("&sid="+encodeURIComponent(EA_USER.id)) : ""; }

  // (1) جلب تقدّم الطالب + كل معرّفات الكورس + الحالات/الأشكال، ثم التصنيف وعرض الاختيار
  function reviewInit(){
    if(!SYNC_ON){
      showError("ERR-AUTH", t("تعذّر التعرّف على حسابك. افتح الصفحة داخل حسابك في Teachable."), "no identity / #fedora-data");
      return;
    }
    sub.textContent=t("جارٍ تجهيز مراجعتك...");
    var pUrl=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)+"&course=eq."+encodeURIComponent(COURSE)+"&select=question_id,answered,correct,flagged,choice";
    var idUrl=GUARD+"?type=ids&course="+encodeURIComponent(COURSE)+sidParam();
    var cUrl=GUARD+"?type=cases&course="+encodeURIComponent(COURSE)+sidParam();
    var fUrl=GUARD+"?type=figures&course="+encodeURIComponent(COURSE)+sidParam();
    Promise.all([ getJSON(pUrl), getGuard(idUrl), getGuard(cUrl), getGuard(fUrl) ]).then(function(res){
      if(!res[1]){ var er=_lastErr||{code:"ERR-GUARD",detail:"course ids null"}; showError(er.code, (er.code==="ERR-NET"?t("تعذّر الاتصال بالخادم. تحقّق من اتصالك."):t("تعذّر تحميل بيانات الكورس حاليا.")), er.detail); return; }
      PROGRESS={};
      (res[0]||[]).forEach(function(r){ PROGRESS[r.question_id]={answered:!!r.answered, correct:!!r.correct, flagged:!!r.flagged, choice:(r.choice===undefined?null:r.choice)}; });
      COURSE_IDS=(res[1]||[]).map(function(r){ return r.id; });
      CASES={}; (res[2]||[]).forEach(function(c){ CASES[c.case_id]=c.text; });
      FIGURES={}; (res[3]||[]).forEach(function(f){ FIGURES[f.fig_id]=f.svg; });
      classify();
      showHub();
    });
  }

  // (2) التصنيف الثلاثي من التقدّم ومعرّفات الكورس
  function classify(){
    CATS={ flag:[], wrong:[], unsolved:[] };
    COURSE_IDS.forEach(function(qid){
      var p=PROGRESS[qid];
      if(p && p.flagged) CATS.flag.push(qid);
      if(p && p.answered && !p.correct) CATS.wrong.push(qid);
      if(!p || !p.answered) CATS.unsolved.push(qid);
    });
  }

  // اتّحاد الفئات المختارة بلا تكرار، مع وسم كل سؤال بفئاته
  function buildUnion(){
    var set={}, order=[];
    function addCat(key){ CATS[key].forEach(function(qid){ if(!set[qid]){ set[qid]={flag:false,wrong:false,unsolved:false}; order.push(qid); } set[qid][key]=true; }); }
    if(SELECTED.flag) addCat('flag');
    if(SELECTED.wrong) addCat('wrong');
    if(SELECTED.unsolved) addCat('unsolved');
    return { ids:order, badges:set };
  }

  // (3) شاشة الاختيار (الهب)
  function showHub(){
    var bw=document.getElementById('ea-barwrap'); if(bw) bw.style.display='none';
    showIdentity(SYNC_ON ? t('☁️ تقدّمك محفوظ سحابيا') : '');
    var total=COURSE_IDS.length;
    sub.textContent=t("اختر ما تريد مراجعته — من ")+total+t(" سؤالا في الكورس");
    var cats=[
      { key:'flag', icon:'🚩', name:t('المميّزة'), desc:t('ما وضعت عليه علامة'), n:CATS.flag.length, col:'var(--amber)' },
      { key:'wrong', icon:'✗', name:t('أخطأت فيها'), desc:t('ما أجبت عنه خطأ'), n:CATS.wrong.length, col:'var(--red)' },
      { key:'unsolved', icon:'○', name:t('لم تُحلّ'), desc:t('ما لم تُجب عنه بعد'), n:CATS.unsolved.length, col:'var(--gray)' }
    ];
    var u=buildUnion();
    var h='<div class="ea-card">';
    h+=t('<div class="rev-intro">اختر فئةً أو أكثر، ثم ابدأ. السؤال في أكثر من فئة يظهر مرّةً واحدة.</div>');
    h+='<div class="rev-cats">';
    cats.forEach(function(c){
      var on=SELECTED[c.key], disabled=(c.n===0);
      h+='<label class="rev-cat'+(on&&!disabled?' on':'')+(disabled?' dis':'')+'" data-key="'+c.key+'">'
        +'<input type="checkbox" '+(on&&!disabled?'checked':'')+(disabled?' disabled':'')+' data-cat="'+c.key+'">'
        +'<span class="rev-ic" style="color:'+c.col+'">'+c.icon+'</span>'
        +'<span class="rev-body"><span class="rev-name">'+c.name+'</span><span class="rev-desc">'+c.desc+'</span></span>'
        +'<span class="rev-n" style="background:'+(disabled?'#E5E7EB':c.col)+'">'+c.n+'</span></label>';
    });
    h+='</div>';
    h+=t('<div class="rev-sum" id="rev-sum">المنتقى: <b>')+u.ids.length+t('</b> سؤالا</div>');
    h+='<button class="ea-btn ea-primary rev-start" id="rev-start"'+(u.ids.length===0?' disabled':'')+t('>ابدأ المراجعة (')+u.ids.length+')</button>';
    if(total>0 && CATS.flag.length===0 && CATS.wrong.length===0){
      h+=t('<div class="rev-empty-hint">✓ لا أخطاء ولا أسئلة مميّزة — تدرّب على المهمات أولا لتمتلئ المراجعة.</div>');
    }
    h+='</div>';
    stage.innerHTML=h;

    // ربط المربّعات
    stage.querySelectorAll('input[data-cat]').forEach(function(cb){
      cb.onchange=function(){ SELECTED[cb.getAttribute('data-cat')]=cb.checked; refreshHub(); };
    });
    var sb=document.getElementById('rev-start');
    if(sb) sb.onclick=startReview;
  }
  function refreshHub(){
    var u=buildUnion();
    var sum=document.getElementById('rev-sum'); if(sum) sum.innerHTML=t('المنتقى: <b>')+u.ids.length+t('</b> سؤالا');
    var sb=document.getElementById('rev-start');
    if(sb){ sb.disabled=(u.ids.length===0); sb.textContent=t('ابدأ المراجعة (')+u.ids.length+')'; }
    stage.querySelectorAll('.rev-cat').forEach(function(el){
      var k=el.getAttribute('data-key'); if(el.classList.contains('dis')) return;
      el.classList.toggle('on', !!SELECTED[k]);
    });
  }

  // (4) بدء المراجعة: جلب نصوص الأسئلة المنتقاة فقط، ثم تشغيل المحرّك
  function startReview(){
    var u=buildUnion();
    if(u.ids.length===0) return;
    sub.textContent=t("جارٍ جلب الأسئلة المنتقاة...");
    stage.innerHTML=t('<div class="ea-card"><div class="ea-empty" style="color:var(--gray)">جارٍ التحميل...</div></div>');
    var idList=u.ids.map(function(x){ return encodeURIComponent(x); }).join(",");
    var qUrl=GUARD+"?type=questions&course="+encodeURIComponent(COURSE)+"&ids="+idList+sidParam();
    getGuard(qUrl).then(function(rows){
      if(!rows){ var er=_lastErr||{code:"ERR-GUARD",detail:"questions null"}; showError(er.code, (er.code==="ERR-NET"?t("تعذّر الاتصال بالخادم."):t("تعذّر تحميل الأسئلة المنتقاة.")), er.detail); return; }
      var byId={}; rows.forEach(function(q){ if(q && q.id) byId[q.id]=q; }); // الحارس يعيد كائنات الأسئلة مباشرة
      // رتّب حسب ترتيب الاتّحاد، وأرفق وسوم الفئات
      ALLDATA=[];
      u.ids.forEach(function(qid){ if(byId[qid]){ var q=byId[qid]; q._badges=u.badges[qid]; ALLDATA.push(q); } });
      DATA=ALLDATA;
      caseFirst={}; DATA.forEach(function(d,idx){ if(d.caseId && caseFirst[d.caseId]===undefined) caseFirst[d.caseId]=idx; });
      // حالة جديدة (محاولة جديدة)، مع إبقاء التمييز الحالي من التقدّم
      state={}; DATA.forEach(function(d){ var p=PROGRESS[d.id]; state[d.id]={answered:false, correct:false, choice:null, flag:!!(p&&p.flagged), caseOpen:false}; });
      i=0; dndPlace={};
      sub.textContent=t("المراجعة — ")+DATA.length+t(" سؤالا");
      render();
    });
  }

  // العودة للهب: نُعيد جلب التقدّم (قد تغيّر بالإجابات) ونحدّث التصنيف
  function backToHub(){
    sub.textContent=t("جارٍ تحديث مراجعتك...");
    var pUrl=SUPA_URL+"/rest/v1/progress?student_id=eq."+encodeURIComponent(EA_USER.id)+"&course=eq."+encodeURIComponent(COURSE)+"&select=question_id,answered,correct,flagged,choice";
    getJSON(pUrl).then(function(rows){
      PROGRESS={}; (rows||[]).forEach(function(r){ PROGRESS[r.question_id]={answered:!!r.answered, correct:!!r.correct, flagged:!!r.flagged, choice:(r.choice===undefined?null:r.choice)}; });
      classify();
      showHub();
    });
  }

  reviewInit();
})();

  }
})();
