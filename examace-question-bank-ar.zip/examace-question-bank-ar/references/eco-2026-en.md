# Official ECO 2026 — English task & enabler names (authoritative)

> Verbatim from the **official PMI ECO 2026 (English)**. Use these for `task` (EN)
> and `primary.title` (EN). Enabler codes `X.Y.Z` mirror `eco-2026-structure.md` (AR).
> Author docx EN wording ≈ official; **prefer official ECO, flag author divergences**.
> Verified 2026-06-14 against PMI's English ECO PDF. Domains: People 33% · Process 41% · Business 26%.

---

## DOMAIN I — PEOPLE (33%) · `domainKey: people`

**1.1 Develop a common vision**
- 1.1.1 Help ensure a shared vision with key stakeholders
- 1.1.2 Promote the shared vision
- 1.1.3 Keep the vision current
- 1.1.4 Break down situations to identify the root cause of a misunderstanding of the vision

**1.2 Manage conflicts**
- 1.2.1 Identify conflict sources
- 1.2.2 Analyze the context for the conflict
- 1.2.3 Implement an agreed-on resolution strategy
- 1.2.4 Communicate conflict management principles with the team and external stakeholders
- 1.2.5 Establish an environment that fosters adherence to common ground rules
- 1.2.6 Manage and rectify ground rule violations

**1.3 Lead the project team**
- 1.3.1 Establish expectations at the team level
- 1.3.2 Empower the team
- 1.3.3 Solve problems
- 1.3.4 Represent the voice of the team
- 1.3.5 Support the team's varied experiences, skills, and perspectives
- 1.3.6 Determine an appropriate leadership style
- 1.3.7 Establish clear roles and responsibilities within the team

**1.4 Engage stakeholders**
- 1.4.1 Identify stakeholders
- 1.4.2 Analyze stakeholders
- 1.4.3 Analyze and tailor communication to stakeholder needs
- 1.4.4 Execute the stakeholder engagement plan
- 1.4.5 Optimize alignment among stakeholder needs, expectations, and project objectives
- 1.4.6 Build trust and influence stakeholders to accomplish project objectives

**1.5 Align stakeholder expectations**
- 1.5.1 Categorize stakeholders
- 1.5.2 Identify stakeholder expectations
- 1.5.3 Facilitate discussions to align expectations
- 1.5.4 Organize and act on mentoring opportunities

**1.6 Manage stakeholder expectations**
- 1.6.1 Identify internal and external customer expectations
- 1.6.2 Align and maintain outcomes to internal and external customer expectations
- 1.6.3 Monitor internal and external customer satisfaction/expectations and respond as needed

**1.7 Help ensure knowledge transfer**
- 1.7.1 Identify knowledge critical to the project
- 1.7.2 Gather knowledge
- 1.7.3 Foster an environment for knowledge transfer

**1.8 Plan and manage communication**
- 1.8.1 Define a communication strategy
- 1.8.2 Promote transparency and collaboration
- 1.8.3 Establish a feedback loop
- 1.8.4 Understand reporting requirements
- 1.8.5 Create reports aligned with sponsors and stakeholder expectations
- 1.8.6 Support reporting and governance processes

---

## DOMAIN II — PROCESS (41%) · `domainKey: process`

**2.1 Develop an integrated project management plan and plan delivery**
- 2.1.1 Assess project needs, complexity, and magnitude
- 2.1.2 Recommend a project management development approach (i.e., predictive, adaptive/agile, or hybrid management)
- 2.1.3 Determine critical information requirements (e.g., sustainability)
- 2.1.4 Recommend a project execution strategy
- 2.1.5 Create an integrated project management plan
- 2.1.6 Estimate work effort and resource requirements
- 2.1.7 Assess consolidated project plans for dependencies, gaps, and continued business value
- 2.1.8 Maintain the integrated project management plan
- 2.1.9 Collect and analyze data to make informed project decisions

**2.2 Develop and manage project scope**
- 2.2.1 Define scope
- 2.2.2 Obtain stakeholder agreement on project scope
- 2.2.3 Break down scope

**2.3 Help ensure value-based delivery**
- 2.3.1 Identify value components with key stakeholders
- 2.3.2 Prioritize work based on value and stakeholder feedback
- 2.3.3 Assess opportunities to deliver value incrementally
- 2.3.4 Examine the business value throughout the project
- 2.3.5 Verify a measurement system is in place to track benefits
- 2.3.6 Evaluate delivery options to demonstrate value

**2.4 Plan and manage resources**
- 2.4.1 Define and plan resources based on requirements
- 2.4.2 Manage and optimize resource needs and availability

**2.5 Plan and manage procurement**
- 2.5.1 Plan procurement
- 2.5.2 Execute a procurement management plan
- 2.5.3 Select preferred contract types
- 2.5.4 Evaluate vendor performance
- 2.5.5 Verify objectives of the procurement agreement are met
- 2.5.6 Participate in agreement negotiations
- 2.5.7 Determine a negotiation strategy
- 2.5.8 Manage suppliers and contracts
- 2.5.9 Plan and manage the procurement strategy
- 2.5.10 Develop a delivery solution

**2.6 Plan and manage finance**
- 2.6.1 Analyze project financial needs
- 2.6.2 Quantify risk and contingency financial allocations
- 2.6.3 Plan spend tracking throughout the project life cycle
- 2.6.4 Plan financial reporting
- 2.6.5 Anticipate future finance challenges
- 2.6.6 Monitor financial variations and work with the governance process
- 2.6.7 Manage financial reserves

**2.7 Plan and optimize quality of products/deliverables**
- 2.7.1 Gather quality requirements for project deliverables
- 2.7.2 Plan quality processes and tools
- 2.7.3 Execute a quality management plan
- 2.7.4 Help ensure regulatory compliance
- 2.7.5 Manage cost of quality (CoQ) and sustainability
- 2.7.6 Conduct ongoing quality reviews
- 2.7.7 Implement continuous improvement

**2.8 Plan and manage schedule**
- 2.8.1 Prepare a schedule based on the selected development approach
- 2.8.2 Coordinate with other projects and operations
- 2.8.3 Estimate project tasks (milestones, dependencies, story points)
- 2.8.4 Utilize benchmarks and historical data
- 2.8.5 Create a project schedule
- 2.8.6 Baseline a project schedule
- 2.8.7 Execute a schedule management plan
- 2.8.8 Analyze schedule variation

**2.9 Evaluate project status**
- 2.9.1 Develop project metrics, analysis, and reconciliation
- 2.9.2 Identify and tailor needed artifacts
- 2.9.3 Help ensure artifacts are created, reviewed, updated, and documented
- 2.9.4 Help ensure accessibility of artifacts
- 2.9.5 Assess current progress
- 2.9.6 Measure, analyze, and update project metrics
- 2.9.7 Communicate project status
- 2.9.8 Continually assess the effectiveness of artifact management

**2.10 Manage project closure**
- 2.10.1 Obtain project stakeholder approval of project completion
- 2.10.2 Determine criteria to successfully close the project or phase
- 2.10.3 Validate readiness for transition (e.g., to operations team or next phase)
- 2.10.4 Conclude activities to close the project or phase (e.g., final lessons learned, retrospectives, procurement, financials, resources)

---

## DOMAIN III — BUSINESS ENVIRONMENT (26%) · `domainKey: business`

**3.1 Define and establish project governance**
- 3.1.1 Describe and establish the structure, rules, procedures, reporting, ethics, and policies through the use of organizational process assets (OPAs)
- 3.1.2 Define success metrics
- 3.1.3 Outline governance escalation paths and thresholds

**3.2 Plan and manage project compliance**
- 3.2.1 Confirm project compliance requirements (e.g., security, health and safety, sustainability, regulatory compliance)
- 3.2.2 Classify compliance categories
- 3.2.3 Determine potential threats to compliance
- 3.2.4 Use methods to support compliance
- 3.2.5 Analyze the consequences of noncompliance
- 3.2.6 Determine the necessary approach and action(s) to address compliance needs
- 3.2.7 Measure the extent to which the project is in compliance

**3.3 Manage and control changes**
- 3.3.1 Execute the change control process
- 3.3.2 Communicate the status of proposed changes
- 3.3.3 Implement approved changes to the project
- 3.3.4 Update project documentation to reflect changes

**3.4 Remove impediments and manage issues**
- 3.4.1 Evaluate the impact of impediments
- 3.4.2 Prioritize and highlight impediments
- 3.4.3 Determine and apply an intervention strategy to remove/minimize impediments
- 3.4.4 Reassess continually to help ensure impediments, obstacles, and blockers for the team are being addressed
- 3.4.5 Recognize when a risk becomes an issue
- 3.4.6 Collaborate with relevant stakeholders on an approach to resolve the issues

**3.5 Plan and manage risk**
- 3.5.1 Identify risks
- 3.5.2 Analyze risks
- 3.5.3 Monitor and control risks
- 3.5.4 Develop a risk management plan
- 3.5.5 Maintain a risk register (e.g., poor IT security)
- 3.5.6 Execute a risk management plan (e.g., risk response for security and managing sustainability risks)
- 3.5.7 Communicate the status of a risk impact on the project

**3.6 Continuous improvement**
- 3.6.1 Utilize lessons learned
- 3.6.2 Help ensure continuous improvement processes are updated
- 3.6.3 Update organizational process assets (OPAs)

**3.7 Support organizational change**
- 3.7.1 Assess organizational culture
- 3.7.2 Evaluate the impact of organizational change on the project and determine required actions

**3.8 Evaluate external business environment changes**
- 3.8.1 Survey changes to the external business environment (e.g., regulations, technology, geopolitical, market)
- 3.8.2 Assess and prioritize the impact on project scope/backlog based on changes in the external business environment
- 3.8.3 Continually review the external business environment for impacts on project scope/backlog

---

## Exam structure (for the future simulation feature)
- 180 questions = **170 scored + 10 pretest** (unscored); **240 minutes**; two 10-min breaks
  (first after the case-study section; second ~midway through the independent questions).
- **~40% predictive / ~60% adaptive-agile + hybrid**, spread across all three domains.
- **8 question types** (confirmed): Case/Scenario · Enhanced Matching · Graphic-Based ·
  Multiple-Choice Single · Multiple-Response · Point-and-Click (hotspot) · Matching (dnd) · Pull-down List.
