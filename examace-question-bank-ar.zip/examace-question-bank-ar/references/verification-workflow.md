# سير التحقّق (المرجع التشغيليّ)

> **مبدأ ثابت:** تحقّق قبل أن تؤكّد — live grep / live probe / browser render / DB query.
> لا تفترض حالة القاعدة من الذاكرة؛ استعلمها. ولا ترفع دفعةً دون فحصٍ قبليٍّ وبعديّ.

---

## ٠. استعلام بداية الجلسة (شغّله أوّلاً — «أين توقّفت؟»)
أمرٌ واحدٌ يُرجِع الخريطة الكاملة: المعرّف الحرّ التالي + توزيع المهمات + الحالات + الأشكال.
```sql
select 'next_free_id' k, (max((substring(id from 4))::int)+1)::text v from public.questions
union all select 'max_id', max(id) from public.questions
union all select 'pairs_total', count(distinct pair_id)::text from public.questions
union all select 'by_task', string_agg(t, '  ' order by t) from (
  select task_code||'='||count(distinct pair_id) t
  from public.questions group by task_code) z
union all select 'cases_next', 'CASE-'||lpad((max((substring(replace(replace(case_id,'AR-',''),'EN-',''') from 6))::int)+1)::text,3,'0')
  from public.cases
union all select 'figures', (select count(distinct fig_id)::text from public.figures)
union all select 'figure_ids', (select string_agg(distinct fig_id, ', ' order by fig_id) from public.figures);
```
طابِق النتيجة بـ`project-state.md §٢`؛ إن اختلفا، **القاعدة هي المرجع** (حدّث فهمك، ونبّه رشيد إن لزم).

---

## ١. استعلامات ما قبل الرفع (شغّلها، راجعها، ثمّ ارفع)

```sql
-- (1) الحالة العامّة: العدد وأصغر/أكبر معرّف لكلّ لغة
--     أكبر معرّف = مؤشّر تقدّم الرفع
select course, count(*) as n_rows, min(id) as min_id, max(id) as max_id
from public.questions group by course order by course;

-- (2) التوزيع حسب المهمة (ما رُفع فعلاً)
select course, task_code, count(*) as n, count(distinct pair_id) as pairs
from public.questions group by course, task_code order by course, task_code;

-- (3) ★ تصادم المعرّفات: المعرّفات المستهدفة للدفعة الجديدة (المتوقّع: 0 صفّ)
select id, course, task_code, pair_id from public.questions
where id in ('AR-Q0XXX','EN-Q0XXX', ...) order by id;

-- (4) ★ الأشكال: تأكيد القديم سليم + الجديد غائب (لا استبدال)
select fig_id, course, length(svg) as svg_len from public.figures
where fig_id in ('<قديم>','<جديد1>','<جديد2>') order by fig_id, course;

-- (5) عدّ الممكّنات المعنيّة قبل الإضافة
select data->'primary'->>'code' as enabler, course, count(*) as n
from public.questions where data->'primary'->>'code' in ('X.Y.Z',...)
group by enabler, course order by enabler, course;

-- (6) دراسات الحالة الحاليّة
select course, count(*) as n_cases,
       string_agg(case_id, ', ' order by case_id) as case_ids
from public.cases group by course order by course;
```

## ٢. استعلامات ما بعد الرفع (طابق المتوقّع)

نفس الاستعلامات أعلاه + **بوّابة سلامة ربط الأشكال** (الأهمّ):
```sql
-- كلّ سؤالٍ ذي fig يجب أن يجد شكله (المتوقّع: 0 صفّ مفقود)
select q.id, q.course, q.data->>'fig' as fig_ref
from public.questions q
where q.data->>'fig' is not null
  and not exists (select 1 from public.figures f
                  where f.fig_id = q.data->>'fig' and f.course = q.course)
order by q.id;
```
احسب الأرقام المتوقّعة سلفًا (عدد الصفوف، أقصى معرّف، عدّ كلّ مهمّة/ممكّن، عدد الأشكال
والحالات) وطابِقها مع النتيجة. صفّ مفقودٌ واحدٌ في بوّابة الأشكال = خطأ ربط.

> ملاحظة أسلوب: ميّز بين استعلام **مُرشَّح** (where fig_id in ...) واستعلامٍ يسرد
> **البنك كاملًا** (لا where) — توقّع الأرقام بناءً على ذلك (خطأ سابق: توقّعتُ «3 أشكال»
> من استعلامٍ غير مُرشَّح يسرد ١٣ شكلًا).

### ٢.١ أمر التحقّق الواحد (PASS/FAIL) — مفضَّلٌ لرشيد بعد الرفع
بدل عدّة استعلامات، أمرٌ واحدٌ (`with … select`) يُرجِع صفًّا لكلّ فحصٍ بحالة PASS/FAIL،
**منطاقُه `task_code='<المهمّة>'`** (لا يتداخل مع دفعاتٍ سابقة). الفحوص النموذجيّة (انظر
المثال المُسلَّم `verify_2_1_single.sql`): TOTAL_ROWS · AR/EN_PAIRS · ID_RANGE · CONTIGUOUS
(لا فجوات/تكرار) · ENABLERS (كلّ ممكّنٍ N صفًّا) · EN/AR_TASK_NAME · DOMAINKEY · DOM ·
FIGURES · CASES · ORPHAN_FIG · ORPHAN_CASE. تحقّق من السلامة قبل التسليم: فاصلةٌ منقوطةٌ
واحدة، توازن الأقواس. المتوقّع: كلّ الصفوف PASS. (الرفع upsert فأعادة تنفيذه آمنة.)

---

## ٣. harness اختبار المتصفّح (playwright + المحرّك الحيّ)

يحمّل أسئلةً فعليّةً في `examace.js` عبر stub لـ`fetch`، ويؤكّد التصيير:

```python
import re, json, pathlib
from playwright.sync_api import sync_playwright
# جهّز td = {"questions":[...], "cases":[...], "figures":[{"fig_id","svg"},...]}
engine=open('engine/examace.js',encoding='utf-8').read()  # لقطة المهارة (انظر engine/README.md)
html=('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">'
 '<style>@import url("https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap");'
 'body{font-family:Tajawal,sans-serif;margin:12px}</style></head><body><div id="ea-root"></div>'
 '<script>window.EA_COURSE="ar";window.EA_TASK="1.3";window.EA_USER=null;'
 'var TESTDATA='+json.dumps(td,ensure_ascii=False)+';'
 'window.fetch=function(u){u=String(u);function r(o){return Promise.resolve('
 '{ok:true,status:200,json:function(){return Promise.resolve(o);}});}'
 'if(u.indexOf("type=questions")>=0)return r({data:TESTDATA.questions.filter('
 'function(q){return q.taskCode===window.EA_TASK;})});'  # المحرّك يُرشّح بالمهمة
 'if(u.indexOf("type=cases")>=0)return r({data:TESTDATA.cases});'
 'if(u.indexOf("type=figures")>=0)return r({data:TESTDATA.figures});'
 'return r({data:[]});};</script><script>'+engine+'</script></body></html>')
open('/tmp/harness.html','w',encoding='utf-8').write(html)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":820,"height":1000},device_scale_factor=2)
    errs=[]; pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto('file://'+str(pathlib.Path('/tmp/harness.html'))); pg.wait_for_timeout(1200)
    print("شكل ظاهر=", pg.query_selector("#ea-root svg") is not None)
    print("أخطاء=", errs[:3] or "لا")
    pg.screenshot(path="/tmp/render.png"); b.close()
```

نقاط مهمّة:
- المحرّك **يُرشّح بالمهمة**؛ لاختبار سؤالٍ بمهمّةٍ معيّنة اضبط `EA_TASK` لمهمّته (أو
  رشّح الـstub بـ`taskCode`). سؤالٌ واحدٌ في المهمة → `#ea-next` معطّل (طبيعيّ).
- وضع الضيف (EA_USER=null) يُظهر لافتة الهوية — أثرُ اختبارٍ غير ضارّ.
- اختبر **تعدّد دراسات الحالة** (caseIds مختلفة) للتأكّد من عدم التداخل.
- **متعدّد الأشكال:** كرّر **كلّ** أسئلة الأشكال (`figqs`) لا الأوّل فقط؛ أكّد ظهور svg لكلٍّ.
- جاهز: `tools/harness.py` (انسخه، عدّل CONFIG: `BUILT, ENGINE, EA_TASK, FIGURES`). يتجاهل أخطاء
  console من نوع 403/«Failed to load resource» (تحميل خطّ Tajawal المحجوب) — غير ضارّة.

---

## ٤. نزاهةٌ مستمرّة
- صحّح تصريحاتك المتجاوزة علنًا. (في الجلسات: التُقطت آثار harness/parse مرّتين —
  «تسريب» نصّ حالة، ومطابقة جدول المقدّمة في كشف المدرب — كلاهما خطأ في أداة الاختبار
  لا في الـSQL.)
- صدّق نتائج القاعدة حتى المفاجئة، لكن دقّق عند التضارب أو النقص.
- نبّه رشيد حين يغيّر قرارًا سابقًا له.

---

## ٥. تدقيق مفاتيح dnd (درسٌ ذهبيٌّ من تدقيق الطبقة ٣)

### (أ) dnd الهجين — مطابقة سطر المفتاح بالتعليل (إلزاميٌّ قبل الرفع)
**الخطأ التأليفيّ الوحيد المتكرّر، وغير مرئيٍّ آليًّا.** في docx الـdnd الهجين، يكتب المؤلّف سطر
«Correct answer» **وسطر التعليل**؛ وقد يُكتَب سطر المفتاح **معكوسًا فيناقض التعليل** الذي كتبه في الملفّ نفسه.
- **المحوّل سليمٌ** — ينقل سطر المفتاح كما كُتب. **الخطأ تأليفيٌّ لا محوّليّ.**
- **القاعدة:** قبل رفع أيّ dnd هجين، **طابِق سطر المفتاح بتعليله حرفيًّا**. مثال محسوم (Q2230): سطر المفتاح
  «1→C · 2→A · 3→D · 4→B» بينما منطق التعليل يعطي 1→B و4→C.
- **لماذا يختبئ:** المطابقة المعروضة تبدو «معقولة» دائمًا. الكشف **فقط** بالمطابقة الحرفيّة بالتعليل.
- **شاهدٌ مؤكِّد:** أسئلة single في البنك نفسه تربط المفاهيم صحيحًا (المؤلّف يعرف الصواب؛ السهو في سطر المفتاح وحده).
- **سجلّ:** تدقيق الطبقة ٣ وجد 8 مفاتيح هجينةً معكوسة (Q2137–2256)، كلّها صُحّحت. كلّ زوجٍ بدّل طرفين (q1↔q4 أو q3↔q4) وq2/q3 صحيحان.

### (ب) dnd الرشيق — لا مطابقةٌ تسلسليّة (عيبٌ تصميميّ)
المحرّك **لا يخلط البطاقات (chips)**. فإن كانت مطابقة الـdnd تسلسليّة (q_i→c_i) صار السؤال يُحَلّ بالترتيب لا بالفهم.
- **القاعدة:** أعِد ترتيب البطاقات بـ**derangement عشوائيٍّ للفهارس** (المفتاح ثابتٌ، القيمة التشخيصيّة مستعادة).
- **سجلّ:** صُحّح 24 سؤال dnd رشيق تسلسليّ بهذه الطريقة في تدقيق الطبقة ٣.

> **تنبيهٌ على تدقيقَين متمايزَين للطبقة ٣ (لا تخلطهما):**
> - **تدقيق المؤلّف الحديث (496 زوجًا Q1761+):** مصدر القاعدتين أعلاه (8 مفاتيح هجينةٍ معكوسة + 24 رشيقًا تسلسليًّا) · 98% سليمٌ فور التأليف. تقريره في **مخرجات الجلسة** (`layer3_audit_summary.md`)، لا في ملفّات المشروع.
> - **تدقيق دفعة Model (180 سؤال PMI · Q1491–Q1670):** تدقيقٌ آخرُ منفصل، نتيجته 180/180 سليمة (مفتاح PMI فيصلٌ أعلى). تقريره `examace_model_layer3_audit.md` (ملفّات المشروع) — **لا يخصّ القاعدتين أعلاه**.
