# معماريّة ExamAce التشغيليّة (المرجع الكامل)

> هذا الملف يصف **كيف يعمل المنتج فعلاً** — الطبقات الثلاث المُدارة، ومشروع Supabase
> بتفاصيله، وسلوك المحرّك، وقصاصة الدرس. لا يُذكر شيءٌ من هذا للطالب.

---

## ١. الطبقات الثلاث

```
1) Teachable (المنصّة)  ── علامة ExamAce · خطّة Builder
   ├─ كورس عربي  (اشتراك مستقل · RTL)   — لكلّ درس مهمّة قصاصةٌ من ٣ أسطر
   └─ كورس إنجليزي (اشتراك مستقل · LTR)  — نفس المحرّك، محتوى/أشكال/واجهة مترجمة
                                            مرتبطان بـ pairId

2) قصاصة مضمَّنة (٣ أسطر/درس)  ── تشير إلى examace.js المستضاف خارجيًّا

3) Supabase (Pro · فرانكفورت · مؤسّسة "Muzn")
   ── تقدّم الطالب + بنك الأسئلة + الحالات + الأشكال + التقارير + ملفّ examace.js الثابت
```

- **محرّكٌ واحدٌ مشترك** للّغتين (`examace.js`). نفس الكود؛ النصوص تختلف عبر أزواج i18n
  عربي→إنجليزي ودالّة `t()`. غلافٌ خارجيٌّ (IIFE) يقرأ `window.EA_COURSE / EA_TASK / EA_USER`.
- معظم الكورسات **غير منشورة** (آمنةٌ للتعديل).

---

## ٢. مشروع Supabase (مؤسّسة "Muzn")

| المفتاح | القيمة |
|---|---|
| **Project URL** | `https://lwsrrvhskpzhzaokghdf.supabase.co` |
| **Publishable (anon) key** | `sb_publishable_Kyoc9tDlTmsuBRkD9gZX2Q_O-HtkmpM` |
| **Edge Function (الحارس)** | `https://lwsrrvhskpzhzaokghdf.supabase.co/functions/v1/swift-responder` (Verify JWT = **OFF**) |
| **examace.js العامّ** | `https://lwsrrvhskpzhzaokghdf.supabase.co/storage/v1/object/public/examace/examace.js` (دلو عامّ "examace") |
| Teachable | examace.teachable.com · course id 2990054 · school id 2725663 |

- Smart CDN يُبطل التخزين تلقائيًّا عند الكتابة فوق الملف (~٦٠ ثانية).
- **معلّق:** تفعيل MFA على admin@muzn.ai · إزالة العضو القديم rashidalhajri88@gmail.com من فريق Muzn.

### الجداول (SQL الإعداد في outputs)
| الجدول | الأعمدة | RLS / القراءة |
|---|---|---|
| **questions** | `id, course, task_code, domain_key, type, pair_id, data jsonb` · PK(course,id) | RLS؛ قراءة anon **مقفلة** (الحارس وحده يقرأ) |
| **cases** | `case_id, course, text, updated_at` · PK(course,case_id) | RLS؛ قراءة anon = true |
| **figures** | `fig_id, course, svg, updated_at` · PK(course,fig_id) | RLS؛ قراءة anon = true |
| **progress** | `student_id, course, question_id, answered, correct, flagged, choice jsonb` · PK(student_id,course,question_id) | RLS |
| **exam_attempts** | سجلّ محاولات الاختبار المُخصَّص (الدرجة + الفلاتر + التفصيل) — **بياناتٌ لا ملفّات؛ الـPDF يُبنى عند الطلب** | RLS (عبر الحارس) |
| **contact_submissions** | حقول نموذج الاتصال + `email_sent` (نجاح Resend) + `website` (honeypot) | RLS مفعّل · **بلا سياسةٍ عامّة** (دالّة `contact` تكتب عبر service role) |
| **reports** | إدراج فقط (anon insert) | — |
| **questions_backup_approach** (+`_old`) | نسخةٌ احتياطيّةٌ من قبل كتابة حقل `approach` (تحقّقٌ ثلاثيٌّ قبل أيّ تغييرٍ مخطّطيّ) | — |

### أشكال استجابة الحارس (swift-responder)
النقاط الكاملة: `questions · ids · meta · cases · figures · report · attempt · attempts`.
- `?type=questions&course=X&task=Y` → `{data:[كائنات الأسئلة]}` (يدعم أيضًا `&id=in.(...)` و`?type=ids`)
- `?type=cases&course=X` → `{data:[{case_id,text},...]}`
- `?type=figures&course=X` → `{data:[{fig_id,svg},...]}`
- `?type=meta&course=X` → بياناتٌ وصفيّةٌ للاختبار المُخصَّص (المتاح: مجالات/مهام/ممكّنات/أنماط/صعوبة).
- `?type=report` (POST) → إدراجٌ في `reports`. `?type=attempt` (POST) → حفظ محاولةٍ في `exam_attempts`؛ `?type=attempts` (GET) → قراءة محاولات الطالب السابقة.

> **التقدّم لا يمرّ بالحارس:** المحرّك يقرأ/يكتب `progress` عبر **Supabase REST مباشرةً** (`/rest/v1/progress?student_id=eq.…`) بمفتاح anon + RLS بالـ`student_id`. الحارس مخصّصٌ للأسئلة/الحالات/الأشكال (قراءة anon مقفلة) فقط.

> **دالّةٌ ثانيةٌ منفصلة على Supabase:** `contact` (نماذج الموقع → `contact_submissions` + Resend) — تفصيلها في `infrastructure.md §3`. لا تخلطها بالحارس.

> **مهمّ:** بيانات السؤال تُخزَّن في عمود `data` (jsonb) **كاملةً** (كلّ حقول المخطّط)،
> بينما الأعمدة العليا (`task_code, domain_key, type, pair_id`) مُستخرَجةٌ للفلترة فقط.

---

## ٣. المحرّك examace.js (مصدر الحقيقة للسلوك)

ملفٌّ واحدٌ مستضافٌ خارجيًّا (IIFE، **~2448 سطرًا**). **هو مصدر الحقيقة للمحرّك.**
- **البناء:** يُجمَّع بـ`assemble.py` من `examace_live.js` (الأساس الحيّ ~1288 سطرًا: practice + review)
  + `custom_hub.js` (~575 سطرًا: كتلة الاختبار المُخصَّص). خطّ البناء: `fixes.py` → تعديلات `custom_hub.js`
  → `assemble.py` → `node -c` → اختبارات jsdom → تصيير PDF بـChromium.
- **التحديث الحيّ:** عدّله ثمّ ارفعه إلى Storage bucket `examace` (الكتابة فوقه تُبطل CDN خلال ~٦٠ث).
  **الآليّة الآمنة:** Supabase → Storage → `examace` → نزّل النسخة الحاليّة احتياطيًّا → ارفع الجديدة (Overwrite) → Hard refresh.
- **التضمينات في المحرّك:** `ECO_NAMES` (138 ممكّن ar/en) · `CX_LOGO` (شعار base64) · `CX_PDF_BRAND` (CSS العلامة للـPDF).

سلوكٌ مُتحقَّقٌ منه عمليًّا:
- **الفلترة بالمهمة:** المحرّك يُرشّح الأسئلة **حسب `task_code` المطابق لـ `EA_TASK`**.
  فدرس المهمة (مثلًا `EA_TASK="1.3"`) يعرض أسئلة تلك المهمة عبر كلّ ممكّناتها فقط.
  (هذا ما يجعل سؤال شكلٍ بـ `taskCode=1.4` لا يظهر في درس 1.3.)
- **دراسات الحالة:** يجلبها عبر `?type=cases` (متوازيًا، غير حرج) → `CASES[case_id]=text`.
  `caseFirst[caseId]` يتتبّع أول ظهور → `caseBox` يعرض الحالة **كاملةً** في أول سؤالٍ لها
  («📋 دراسة الحالة — تخدم عدة أسئلة» + النص)، و**مطويّةً بزرّ** في البقية
  («اعرض دراسة الحالة» / case-toggle). تعدّد caseIds في مهمّةٍ واحدة يُعرض بلا تداخل.
  **شرط:** `caseId` في السؤال يطابق `case_id` في cases تمامًا لنفس الكورس.
- **الأشكال:** `FIGURES[fig_id]=svg`؛ حقل `fig` في السؤال → يُحقَن SVG عبر innerHTML.
  المحرّك يعرض **شكلًا واحدًا للسؤال** (شكل حقل `fig`)؛ الشرح **نصّيٌّ فقط** (لا شكل كشف جواب منفصل).
- أزرار التنقّل: `#ea-next` · `#ea-prev` (next معطّلٌ عند سؤالٍ واحد فقط).
- `loadProgress` يتخطّى إن كان SYNC_ON=false (وضع الضيف، EA_USER=null → لافتة
  «تعذّر التعرّف على الهوية... Teachable فقط» — أثرُ اختبارٍ غير ضارّ).
- التقرير يجمع حسب `d.task` (نصًّا).
- RTL = (course !== "en").
- **ثلاثة أوضاع (`MODE`):** `EA_TASK==="REVIEW"` → review (مركز المراجعة) · `EA_TASK==="CUSTOM"` → custom
  (الاختبار المُخصَّص) · غير ذلك → practice (درسٌ عاديّ).

### الوضع الثالث: الاختبار المُخصَّص (custom)
وضعٌ ثالثٌ داخل `examace.js` (شقيقٌ لـpractice/review، لا ملفٌّ منفصل) — بُني بنسخ machinery المراجعة
(readIdentity/loadProgress/render/check/classify…) ثمّ تبديل `TASK="CUSTOM"` واستبدال هَب المراجعة بكتلة الإعداد.
- **شاشة الإعداد:** مصادر (لم تُحلّ/مميّزة/أخطأت فيها/كلّ البنك) · شريط حجم · مفتاح وضع العرض (افتراضيّ OFF = وضع امتحان)
  · نطاقٌ متقدّم (مجال/نهج/نوع/صعوبة + مهمّة/ممكّن) · أوزانٌ + تطبيع PMP (33/41/26) · سجلّ المحاولات.
- **وضع الامتحان:** بلا تغذيةٍ راجعةٍ لكلّ سؤال؛ تسجيلٌ فوريٌّ بالنقر (مفرد/شكل) أو عند الانتقال (متعدّد/فراغات/سحب) → تسليمٌ → تشخيص.
- **محرّك الاختيار:** دراسة الحالة **وحدةٌ ذرّيّة** (لا بترَ سؤال) · سقف 180 صارمٌ بالاستبعاد الكامل · أوزان المجالات الموجودة فقط.
- **التقرير (PDF):** هويّة العلامة (كحليّ #0E1F33، شعار crosshair base64، «Exam» أبيض/«Ace» أخضر #16B5A3)؛
  `@page{margin:0}` يكبت ترويسة الطباعة (about:blank)؛ توصياتٌ مجمَّعةٌ بالمهمّة + خطّة مراجعة. **المرجع المذكور: PMBOK 8 (ECO ليس مرجعَ دراسة).**

---

## ٤. قصاصة الدرس (٣ أسطر، تُلصق في درس Teachable)

```html
<div id="ea-root"></div>
<script>var EA_COURSE="ar"; var EA_TASK="1.1";</script>
<script src="https://lwsrrvhskpzhzaokghdf.supabase.co/storage/v1/object/public/examace/examace.js"></script>
```

- `EA_COURSE` = `"ar"` | `"en"`
- `EA_TASK` = رمز المهمة (مثل `"1.2"`) | `"REVIEW"` | `"CUSTOM"` | `"ALL"` (الافتراضيّ عند الغياب = `"ALL"`)
- **خطوة يدويّة:** رشيد يضبط `EA_TASK` لكلّ درسٍ بنفسه. **احتياطيّا:** إن لم يُضبَط `EA_TASK`، يشتقّ المحرّك المهمّة من **عنوان الدرس** (`document.title`) إن بدأ برقم المهمّة (مثل «2.1 …»). فالأأمن ضبط `EA_TASK` صراحةً.

---

## ٥. سير الرفع والتحقّق (الطريقة المُثبَتة)

1. **قبل الرفع:** شغّل استعلامات تحقّق ما قبل الرفع (`references/verification-workflow.md`)
   — أكبر معرّف (تقدّم الرفع)، تصادم المعرّفات (صفر)، سلامة الأشكال (لا استبدال).
2. **الرفع:** الصق SQL في محرّر Supabase SQL. رتّب الدفعات بحيث **لا فجوات** وبحيث
   تُرفع دفعة الممكّن **قبل** أيّ ملحقٍ يُثريه.
3. **بعد الرفع:** شغّل استعلامات ما بعد الرفع وطابق الأرقام المتوقّعة + بوّابة سلامة
   ربط الأشكال (صفر مفقود).
4. **اختبار المتصفّح:** حمِّل الأسئلة في المحرّك عبر harness (playwright) للتأكّد من
   التصيير قبل الاعتماد — خاصّةً الأشكال ودراسات الحالة.
