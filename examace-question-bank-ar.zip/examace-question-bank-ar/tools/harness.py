# -*- coding: utf-8 -*-
# ============================================================================
# harness.py — اختبار المتصفّح: يحمّل أسئلة الدفعة فعليّاً في examace.js (stub fetch)
#   ويؤكّد التصيير لكلّ لغة: عدّاد محمّل · كلّ أسئلة الأشكال (svg ظاهر) · dnd · multi · الحالات.
#
# الاستعمال: انسخ، عدّل CONFIG، ضع لقطة المحرّك examace.js في مجلّد العمل، ثمّ:
#   python3 harness.py
# المحرّك يُرشّح بالمهمّة (taskCode===EA_TASK). اقرأ references/verification-workflow.md §٣.
# ============================================================================

# ----------------------------- CONFIG (عدّل هنا) -----------------------------
TAG     = "2_2"
BUILT   = "built_2_2.json"
ENGINE  = "examace.js"             # انسخ engine/examace.js من المهارة إلى مجلّد العمل
EA_TASK = "2.2"
# الأشكال: معرّف → {لغة: ملفّ svg}. {} إن لا أشكال في الدفعة.
FIGURES = {}                       # {"approach-selection":{"ar":"appsel_ar.svg","en":"appsel_en.svg"}, ...}
# ----------------------------------------------------------------------------

import re, json, pathlib
from playwright.sync_api import sync_playwright

D = json.load(open(BUILT, encoding="utf-8"))
svg = {fid: {c: open(p, encoding="utf-8").read() for c, p in langs.items()}
       for fid, langs in FIGURES.items()}
engine = open(ENGINE, encoding="utf-8").read()
FIG_IDS = list(FIGURES.keys())

def cdata(course):
    qs = [q for q in D["questions"] if q["lang"] == course]
    cs = [{"case_id": c["case_id"], "text": c["text"]} for c in D["cases"] if c["course"] == course]
    fs = [{"fig_id": fid, "svg": svg[fid][course]} for fid in FIG_IDS]
    figqs = [(i + 1, q["fig"]) for i, q in enumerate(qs) if q.get("fig")]
    dnd   = next((i for i, q in enumerate(qs) if q["type"] == "dnd"), None)
    multi = next((i for i, q in enumerate(qs) if q["type"] == "multi"), None)
    seen = set(); firsts = []
    for i, q in enumerate(qs):
        c = q.get("caseId")
        if c and c not in seen: seen.add(c); firsts.append(i + 1)
    return qs, cs, fs, figqs, (dnd + 1 if dnd is not None else None), (multi + 1 if multi is not None else None), firsts

def html(course, qs, cs, fs):
    td = {"questions": qs, "cases": cs, "figures": fs}; da = "rtl" if course == "ar" else "ltr"
    return ('<!doctype html><html lang="' + course + '" dir="' + da + '"><head><meta charset="utf-8">'
      '<style>@import url("https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap");'
      'body{font-family:Tajawal,sans-serif;margin:12px}</style></head><body><div id="ea-root"></div>'
      '<script>window.EA_COURSE="' + course + '";window.EA_TASK="' + EA_TASK + '";window.EA_USER=null;'
      'var TESTDATA=' + json.dumps(td, ensure_ascii=False) + ';'
      'window.fetch=function(u){u=String(u);function r(o){return Promise.resolve({ok:true,status:200,json:function(){return Promise.resolve(o);}});}'
      'if(u.indexOf("type=questions")>=0)return r({data:TESTDATA.questions.filter(function(q){return q.taskCode===window.EA_TASK;})});'
      'if(u.indexOf("type=cases")>=0)return r({data:TESTDATA.cases});'
      'if(u.indexOf("type=figures")>=0)return r({data:TESTDATA.figures});'
      'return r({data:[]});};</script><script>' + engine + '</script></body></html>')

def jump(pg, n):
    pg.evaluate("(n)=>{var g=document.getElementById('ea-go');if(g){g.value=n;g.dispatchEvent(new Event('change'));}}", n)
    pg.wait_for_timeout(450)

res = []
with sync_playwright() as p:
    b = p.chromium.launch()
    for course in ("ar", "en"):
        qs, cs, fs, figqs, dnd, multi, firsts = cdata(course)
        pathlib.Path(f"/tmp/h_{TAG}_{course}.html").write_text(html(course, qs, cs, fs), encoding="utf-8")
        pg = b.new_page(viewport={"width": 860, "height": 1150}, device_scale_factor=2)
        errs = []
        pg.on("pageerror", lambda e: errs.append("JS:" + str(e)))
        pg.on("console", lambda m: (errs.append("C:" + m.text)
              if m.type == "error" and "403" not in m.text and "Failed to load resource" not in m.text else None))
        pg.goto("file://" + f"/tmp/h_{TAG}_{course}.html"); pg.wait_for_timeout(1300)
        counter = (pg.query_selector(".ea-counter").inner_text() if pg.query_selector(".ea-counter") else "").split("\n")[0]
        loaded = pg.query_selector("#ea-root .ea-q") is not None
        figreps = []
        for (qn, fid) in figqs:        # ★ كرّر كلّ أسئلة الأشكال (لا الأوّل فقط)
            jump(pg, qn)
            figreps.append({"q": qn, "fig": fid,
                            "svg": pg.query_selector("#ea-root svg") is not None,
                            "opts": len(pg.query_selector_all("#ea-root .ea-opt"))})
            pg.screenshot(path=f"/tmp/figq_{TAG}_{course}_{fid}.png")
        dndrep = multirep = None
        if dnd: jump(pg, dnd); dndrep = (dnd, len(pg.query_selector_all("#ea-root .drop-zone")), len(pg.query_selector_all("#ea-root .chip")))
        if multi: jump(pg, multi); multirep = (multi, len(pg.query_selector_all("#ea-root .ea-opt")))
        creps = []
        for ci in firsts:
            jump(pg, ci); cb = pg.query_selector("#ea-root .ea-case"); tx = cb.inner_text() if cb else ""
            creps.append({"idx": ci, "ok": bool(cb) and len(tx) > 60})
        res.append(dict(course=course, errors=errs[:6], loaded=loaded, counter=counter,
                        figs=figreps, dnd=dndrep, multi=multirep,
                        ncases=len(creps), cases_ok=all(c["ok"] for c in creps)))
        pg.close()
    b.close()
print(json.dumps(res, ensure_ascii=False, indent=2))
