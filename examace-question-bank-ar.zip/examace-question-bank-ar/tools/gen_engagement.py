# -*- coding: utf-8 -*-
"""engagement-gap لـQ-F02: مصفوفة تقييم المشاركة، المسؤول التنظيمي مقاوم→داعم (أكبر فجوة)."""
NAVY="#1F3B63"; LBLUE="#EAF2FB"; GRAY="#5B6B7F"; LGRAY="#D9DEE6"; AMBER="#B26A00"
FONT="Tajawal,'Segoe UI',sans-serif"
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
# المعنيون: (الحالي, المنشود) كفهرس مستوى 0=غير مدرك..4=قائد
STAKE=[("المسؤول التنظيمي","Regulatory\nofficial",1,3),
       ("مدير العمليات","Operations\nmanager",3,3),
       ("ممثل المستخدمين","User\nrepresentative",2,3),
       ("المورد","Vendor",3,4)]
TX={"ar":{"title":"مصفوفة تقييم مشاركة المعنيين",
          "levels":["غير مدرك","مقاوم","محايد","داعم","قائد"],
          "legend_cur":"الحالي","legend_des":"المنشود","useIdx":0},
    "en":{"title":"Stakeholder Engagement Assessment Matrix",
          "levels":["Unaware","Resistant","Neutral","Supportive","Leading"],
          "legend_cur":"Current","legend_des":"Desired","useIdx":1}}
def T(x,y,s,size,color,w=400,anchor="middle",rtl=False):
    d=' direction="rtl"' if rtl else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="{anchor}"{d}>{esc(s)}</text>'
def Tml(x,y,lines,size,color,w,rtl,lh):
    d=' direction="rtl"' if rtl else ''
    out=[f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="middle"{d}>']
    for i,ln in enumerate(lines):
        out.append(f'<tspan x="{x}" dy="{0 if i==0 else lh}">{esc(ln)}</tspan>')
    out.append('</text>'); return "".join(out)
def filled(cx,cy): return f'<circle cx="{cx}" cy="{cy}" r="15" fill="{NAVY}"/>'
def diamond(cx,cy):
    r=16; return f'<path d="M {cx} {cy-r} L {cx+r} {cy} L {cx} {cy+r} L {cx-r} {cy} Z" fill="none" stroke="{AMBER}" stroke-width="3"/>'
def build(lang):
    rtl=(lang=="ar"); d=TX[lang]; W,H=980,580
    lblW=180; cw=148; ch=82; gy=98; nlev=5
    gridW=lblW+nlev*cw; x0=(W-gridW)/2
    def colx(c):  # c=0 تسمية, 1..5 مستويات (1=غير مدرك..5=قائد)
        if rtl: return x0+gridW-lblW if c==0 else x0+gridW-lblW-c*cw
        return x0 if c==0 else x0+lblW+(c-1)*cw
    s=[f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="{FONT}">',
       f'<rect width="{W}" height="{H}" fill="#fff"/><style>text{{font-family:{FONT};}}</style>',
       T(W/2,52,d["title"],24,NAVY,800,rtl=rtl)]
    # رأس المستويات
    s+=[f'<rect x="{colx(0)}" y="{gy}" width="{lblW}" height="{ch}" fill="{LBLUE}" stroke="{NAVY}" stroke-width="1.5"/>']
    for j,lv in enumerate(d["levels"]):
        cx=colx(j+1)
        s+=[f'<rect x="{cx}" y="{gy}" width="{cw}" height="{ch}" fill="{LBLUE}" stroke="{NAVY}" stroke-width="1.5"/>']
        s+=[T(cx+cw/2, gy+ch/2+6, lv,16,NAVY,700,rtl=rtl)]
    # صفوف المعنيين
    for r,(nar,nen,cur,des) in enumerate(STAKE):
        ry=gy+(r+1)*ch
        s+=[f'<rect x="{colx(0)}" y="{ry}" width="{lblW}" height="{ch}" fill="#fff" stroke="{NAVY}" stroke-width="1.5"/>']
        nm = nar if d["useIdx"]==0 else nen
        s+=[Tml(colx(0)+lblW/2, ry+ch/2-2 if "\n" in nm else ry+ch/2+6, nm.split("\n"),16,NAVY,700,rtl,20)]
        for j in range(nlev):
            cx=colx(j+1)
            s+=[f'<rect x="{cx}" y="{ry}" width="{cw}" height="{ch}" fill="#fff" stroke="{LGRAY}" stroke-width="1.2"/>']
            cy=ry+ch/2; both=(cur==j and des==j)
            if both:
                s+=[filled(cx+cw/2-16,cy), diamond(cx+cw/2+16,cy)]
            else:
                if cur==j: s+=[filled(cx+cw/2,cy)]
                if des==j: s+=[diamond(cx+cw/2,cy)]
    # وسيلة الإيضاح (رمز + كلمة، بفراغٍ واضح، بلا تداخل)
    ly=gy+(len(STAKE)+1)*ch+44; midx=W/2; gap=26
    if rtl:
        # الحالي يميناً ثمّ المنشود يساراً (رمزٌ يمين الكلمة)
        s+=[filled(midx+135,ly-6), T(midx+135-gap,ly-1,d["legend_cur"],15,GRAY,600,anchor="end")]
        s+=[diamond(midx-25,ly-6), T(midx-25-gap,ly-1,d["legend_des"],15,GRAY,600,anchor="end")]
    else:
        s+=[filled(midx-160,ly-6), T(midx-160+gap,ly-1,d["legend_cur"],15,GRAY,600,anchor="start")]
        s+=[diamond(midx+35,ly-6), T(midx+35+gap,ly-1,d["legend_des"],15,GRAY,600,anchor="start")]
    s.append("</svg>"); return "".join(s)
for lang in ["ar","en"]:
    open(f"/tmp/figs_appendix/engagement-gap_{lang}.svg","w",encoding="utf-8").write(build(lang))
print("✓ وُلّد engagement-gap (ar+en)")
