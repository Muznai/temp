-- ════════ استعلام (ب): الأسئلة حسب الممكّن (≈138 صفّاً) ════════
-- العرض في Supabase يُقصّ عند 100 صفّ — استعمل زرّ Download CSV (يصدّر الكل)،
-- أو أزل التعليق عن شرط مجالٍ واحد ليبقى تحت الحدّ:
--   People=39 · Process=64 · Business=35
select domain_key                as dom,
       data->'primary'->>'code'  as enabler,
       count(*)                  as n
from public.questions
where course = 'ar'
  -- and domain_key = 'process'
group by domain_key, data->'primary'->>'code'
order by domain_key, data->'primary'->>'code';
