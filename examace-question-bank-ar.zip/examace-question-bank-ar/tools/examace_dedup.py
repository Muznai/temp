#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ExamAce — كاشف الشبه-المتطابق في متون الأسئلة.
- يقارن المتن (q) فقط (الخيارات/الإجابات تتكرّر طبيعيًا).
- كامل البنك (عبر المهمات)، كل لغة على حدة.
- عتبة افتراضية 85% (قابلة للضبط).
- يُعفي أسئلة نفس caseId من المقارنة بينها (تشابهها مشروع).
- المخرج: تقرير مراجعة (لا حذف آليّ).
"""
import re, sys, json, unicodedata
from difflib import SequenceMatcher

# ── التطبيع العربي ──────────────────────────────────────────────
AR_DIACRITICS = re.compile(r'[\u0617-\u061A\u064B-\u0652\u0670\u0640]')  # تشكيل + تطويل
def normalize_ar(text):
    if not text:
        return ''
    t = unicodedata.normalize('NFKC', text)
    t = AR_DIACRITICS.sub('', t)                 # أزل التشكيل والتطويل (ـ)
    t = re.sub(r'[إأآا]', 'ا', t)                # توحيد الألف
    t = t.replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و')
    t = t.replace('ة', 'ه')                      # التاء المربوطة ← هاء
    t = re.sub(r'[^\w\s]', ' ', t, flags=re.UNICODE)  # أزل الترقيم
    t = re.sub(r'\s+', ' ', t).strip()           # وحّد المسافات
    return t

def normalize_en(text):
    if not text:
        return ''
    t = unicodedata.normalize('NFKC', text).lower()
    t = re.sub(r'[^\w\s]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t

def normalize(text, lang):
    return normalize_ar(text) if lang == 'ar' else normalize_en(text)

def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

def find_near_duplicates(questions, lang, threshold=0.85):
    """questions: list of dicts بها 'q' و (اختياري) 'caseId' و معرّف.
    يرجع أزواج التشابه فوق العتبة."""
    norm = [(q.get('id') or q.get('_local'), normalize(q.get('q', ''), lang),
             q.get('caseId'), q.get('q', '')) for q in questions]
    pairs = []
    for i in range(len(norm)):
        for j in range(i + 1, len(norm)):
            id_i, ni, case_i, raw_i = norm[i]
            id_j, nj, case_j, raw_j = norm[j]
            # إعفاء: نفس الحالة → تشابه مشروع، تجاوز
            if case_i and case_j and case_i == case_j:
                continue
            if not ni or not nj:
                continue
            sim = similarity(ni, nj)
            if sim >= threshold:
                pairs.append({'a': id_i, 'b': id_j, 'sim': round(sim, 3),
                              'text_a': raw_i, 'text_b': raw_j})
    return sorted(pairs, key=lambda p: -p['sim'])

def report(questions, lang, threshold=0.85, label=''):
    pairs = find_near_duplicates(questions, lang, threshold)
    print(f'── كشف التشابه [{label}] — لغة {lang} — عتبة {int(threshold*100)}% '
          f'— أسئلة {len(questions)} ──')
    if not pairs:
        print('  ✓ لا تشابه فوق العتبة.')
    else:
        print(f'  ⚠️ {len(pairs)} زوج للمراجعة:')
        for p in pairs:
            print(f"    {p['a']} ↔ {p['b']}  ({int(p['sim']*100)}%)")
            print(f"      [{p['a']}] {p['text_a'][:75]}")
            print(f"      [{p['b']}] {p['text_b'][:75]}")
    return pairs

if __name__ == '__main__':
    import examace_convert as C
    # اختبار على الدفعة
    for lang, fn in [('ar', 'PMP_1_1_1_AR.docx'), ('en', 'PMP_1_1_1_EN.docx')]:
        qs, _ = C.parse_doc(fn)
        report(qs, lang, 0.85, '1.1.1')
        print()
        # اختبار حسّاسية: جرّب عتبات أدنى لرؤية أقرب الأزواج
        pairs = find_near_duplicates(qs, lang, 0.60)
        if pairs:
            print(f'  (للمعايرة) أعلى تشابه عند عتبة 60%: '
                  f"{pairs[0]['a']}↔{pairs[0]['b']} = {int(pairs[0]['sim']*100)}%")
        print()
