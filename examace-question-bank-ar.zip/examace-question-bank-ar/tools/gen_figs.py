# -*- coding: utf-8 -*-
"""مولّد أشكال المهمة 1.2 — ٦ مفاهيم × (عربي RTL / إنجليزي LTR)."""
import os
NAVY="#1F3B63"; BLUE="#2E6DA4"; GREEN="#2E7D32"; AMBER="#B26A00"
RED="#9C2A2A"; LBLUE="#EAF2FB"; GRAY="#6B7280"; LGRAY="#E5E7EB"
FONT="Tajawal,'Segoe UI',sans-serif"

def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def T(x,y,s,size=16,color=NAVY,w=700,va="M",rtl=False,ls=None):
    # va = المحاذاة البصريّة: L يسار · M وسط · R يمين. نحسب text-anchor مع مراعاة قلب RTL.
    if va=="M": anchor="middle"
    elif rtl: anchor="start" if va=="R" else "end"
    else: anchor="end" if va=="R" else "start"
    d=' direction="rtl"' if rtl else ''
    extra=f' letter-spacing="{ls}"' if ls else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="{anchor}"{d}{extra}>{esc(s)}</text>'
def BOX(x,y,w,h,fill="#fff",stroke=LGRAY,sw=2,rx=12):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def LINE(x1,y1,x2,y2,color=GRAY,sw=2,dash=""):
    dd=f' stroke-dasharray="{dash}"' if dash else ''
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}"{dd}/>'
def head(W,H):
    return (f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="{FONT}">'
            f'<rect x="0" y="0" width="{W}" height="{H}" fill="#fff"/>'
            f'<style>text{{font-family:{FONT};}}</style>')
def mirror(x,w,W): return W-x-w  # لقلب الإحداثي أفقيًّا (RTL)

# نصوص كل شكل: (عنوان, [عناصر...]) بلغتين
TX={
 "sources":{
   "ar":("مصادر النزاع","النزاع",[("الموارد المحدودة","مورد لا يكفي إلا لطرف",BLUE),
         ("أولويات الجدولة","تنازع على ترتيب العمل",AMBER),
         ("أساليب العمل الشخصية","تباين نمط التواصل",GREEN)]),
   "en":("Conflict sources","Conflict",[("Limited resources","one resource, two claimants",BLUE),
         ("Scheduling priorities","clash over work order",AMBER),
         ("Personal work styles","differing communication",GREEN)]),
 },
 "context":{
   "ar":("تحليل سياق النزاع: مساران","النزاع",
         ("إيجابي","يزيد الإبداع ويحسّن القرار",GREEN),
         ("سلبي معطِّل","يوقف العمل ويستدعي تدخّلاً",RED)),
   "en":("Conflict context: two paths","Conflict",
         ("Positive","boosts creativity, better decisions",GREEN),
         ("Negative / disruptive","halts work, needs intervention",RED)),
 },
 "modes":{
   "ar":("أساليب حلّ النزاع الخمسة",[
        ("الانسحاب/التجنب","تراجع عن الموقف أو تأجيل البتّ",GRAY),
        ("التسوية/الاستيعاب","تأكيد الاتفاق والتنازل حفاظًا على العلاقة",GREEN),
        ("التسوية/المصالحة","رضًا جزئي لجميع الأطراف",AMBER),
        ("القوة/التوجيه","فرض وجهة النظر من موقع سلطة",RED),
        ("التعاون/حل المشكلات","دمج الرؤى بحوار مفتوح نحو الإجماع",BLUE)]),
   "en":("Five conflict-resolution modes",[
        ("Withdraw / Avoid","retreat from the issue or postpone",GRAY),
        ("Smooth / Accommodate","emphasize agreement, yield for harmony",GREEN),
        ("Compromise / Reconcile","partial satisfaction for all parties",AMBER),
        ("Force / Direct","impose one's view from a power position",RED),
        ("Collaborate / Problem-solve","integrate views, open dialogue to consensus",BLUE)]),
 },
 "charter":{
   "ar":("مكوّنات ميثاق الفريق","ميثاق الفريق",[
        "قيم الفريق","إرشادات التواصل","عمليات حل النزاعات",
        "معايير صنع القرار","إرشادات الاجتماعات"]),
   "en":("Team charter components","Team charter",[
        "Team values","Communication guidelines","Conflict-resolution processes",
        "Decision-making criteria","Meeting guidelines"]),
 },
 "commitment":{
   "ar":("تعزيز الالتزام بالقواعد المشتركة",[
        ("القواعد الأساسية","توقعات السلوك المقبول",NAVY),
        ("المعايير الجماعية","أنماط السلوك المشتركة",BLUE),
        ("اتفاقيات الفريق","ترتيبات العمل المتفق عليها",GREEN)],
        "بيئةٌ تعزّز الالتزام وتقلّل النزاع","الكلّ موثَّقٌ في ميثاق الفريق"),
   "en":("Fostering adherence to shared rules",[
        ("Ground rules","expected acceptable behavior",NAVY),
        ("Group norms","shared behavior patterns",BLUE),
        ("Team agreements","agreed working arrangements",GREEN)],
        "An environment fostering adherence, reducing conflict","All documented in the team charter"),
 },
 "violation":{
   "ar":("التعامل مع مخالفة القواعد: مستويات الاستجابة",[
        ("١","معالجة الفريق أولاً","الرجوع إلى القاعدة المتفق عليها",GREEN,"أوّل استجابة"),
        ("٢","تيسير المدير","جلسة خاصة بنهج تعاوني عند التصاعد",AMBER,""),
        ("٣","إجراءات رسمية/تأديبية","إن استمرّ السلوك المعطِّل",RED,"ملاذ أخير")],
        "تصعيدٌ عند عدم الحلّ"),
   "en":("Handling rule violations: response levels",[
        ("1","Team handles first","refer to the agreed rule",GREEN,"First response"),
        ("2","PM facilitates","private, collaborative session if it escalates",AMBER,""),
        ("3","Formal / disciplinary","if disruptive behavior persists",RED,"Last resort")],
        "Escalate if unresolved"),
 },
}

def fig_sources(lang):
    rtl=(lang=="ar"); W,H=880,400
    title,hub,items=TX["sources"][lang]
    s=[head(W,H), T(W/2,46,title,23,NAVY,800,rtl=rtl)]
    # hub في الوسط أعلى
    hw,hh=200,56; hx=(W-hw)/2; hy=80
    s+=[BOX(hx,hy,hw,hh,NAVY,NAVY,0,14), T(W/2,hy+36,hub,20,"#fff",700,rtl=rtl)]
    # ٣ صناديق أسفل
    bw,bh=236,104; gap=28; total=3*bw+2*gap; x0=(W-total)/2; by=240
    order=list(range(3))
    if rtl: order=order[::-1]
    for slot,idx in enumerate(order):
        name,desc,col=items[idx]
        bx=x0+slot*(bw+gap)
        s+=[LINE(W/2,hy+hh, bx+bw/2, by, col,2)]
        s+=[BOX(bx,by,bw,bh,"#fff",col,2,12)]
        s+=[f'<rect x="{bx}" y="{by}" width="{bw}" height="6" rx="3" fill="{col}"/>']
        s+=[T(bx+bw/2,by+46,name,17,col,700,rtl=rtl)]
        s+=[T(bx+bw/2,by+76,desc,12.5,GRAY,500,rtl=rtl)]
    s.append("</svg>"); return "".join(s)

def fig_context(lang):
    rtl=(lang=="ar"); W,H=880,400
    title,hub,pos,neg=TX["context"][lang]
    s=[head(W,H), T(W/2,46,title,23,NAVY,800,rtl=rtl)]
    hw,hh=180,56; hx=(W-hw)/2; hy=82
    s+=[BOX(hx,hy,hw,hh,NAVY,NAVY,0,14), T(W/2,hy+36,hub,20,"#fff",700,rtl=rtl)]
    bw,bh=300,118; by=232
    leftx=70; rightx=W-70-bw
    # إيجابي على جهة بدء القراءة
    posx = rightx if rtl else leftx
    negx = leftx if rtl else rightx
    for (name,desc,col),bx in [(pos,posx),(neg,negx)]:
        fill = "#EAF7EC" if col==GREEN else "#FBEAEA"
        s+=[LINE(W/2,hy+hh, bx+bw/2, by, col,2.5)]
        s+=[BOX(bx,by,bw,bh,fill,col,2.5,14)]
        s+=[T(bx+bw/2,by+48,name,19,col,800,rtl=rtl)]
        s+=[T(bx+bw/2,by+82,desc,13.5,"#374151",500,rtl=rtl)]
    s.append("</svg>"); return "".join(s)

def fig_modes(lang):
    rtl=(lang=="ar"); W,H=880,560
    title,items=TX["modes"][lang]
    s=[head(W,H), T(W/2,46,title,23,NAVY,800,rtl=rtl)]
    bw=760; bh=78; gap=14; x=(W-bw)/2; y0=84
    for i,(name,desc,col) in enumerate(items):
        y=y0+i*(bh+gap)
        s+=[BOX(x,y,bw,bh,LBLUE if col==BLUE else "#fff",col,2,12)]
        # شريط لون على جهة البدء
        if rtl:
            s+=[f'<rect x="{x+bw-8}" y="{y}" width="8" height="{bh}" rx="4" fill="{col}"/>']
            tx=x+bw-24; va="R"
        else:
            s+=[f'<rect x="{x}" y="{y}" width="8" height="{bh}" rx="4" fill="{col}"/>']
            tx=x+24; va="L"
        s+=[T(tx,y+34,name,18,col,700,va=va,rtl=rtl)]
        s+=[T(tx,y+60,desc,13.5,GRAY,500,va=va,rtl=rtl)]
    s.append("</svg>"); return "".join(s)

def fig_charter(lang):
    rtl=(lang=="ar"); W,H=880,470
    title,cname,comps=TX["charter"][lang]
    s=[head(W,H), T(W/2,42,title,23,NAVY,800,rtl=rtl)]
    # حاوية
    cx,cy,cw,ch=60,70,W-120,360
    s+=[BOX(cx,cy,cw,ch,"#F6F8FB",NAVY,2.5,16)]
    s+=[f'<rect x="{cx}" y="{cy}" width="{cw}" height="46" rx="16" fill="{NAVY}"/>',
        f'<rect x="{cx}" y="{cy+30}" width="{cw}" height="16" fill="{NAVY}"/>',
        T(W/2,cy+31,cname,19,"#fff",700,rtl=rtl)]
    # ٥ مكوّنات: صفّ علويّ ٣ + سفليّ ٢
    bw,bh=232,96; gx=22; gy=24
    row1y=cy+72; row2y=row1y+bh+gy
    idx=list(range(5))
    rows=[idx[:3], idx[3:]]
    for r,row in enumerate(rows):
        n=len(row); total=n*bw+(n-1)*gx; x0=cx+(cw-total)/2
        rr=row[::-1] if rtl else row
        yy=row1y if r==0 else row2y
        for slot,ci in enumerate(rr):
            bx=x0+slot*(bw+gx)
            s+=[BOX(bx,yy,bw,bh,"#fff",BLUE,2,11)]
            s+=[T(bx+bw/2,yy+bh/2+6,comps[ci],15.5,NAVY,700,rtl=rtl)]
    s.append("</svg>"); return "".join(s)

def fig_commitment(lang):
    rtl=(lang=="ar"); W,H=880,470
    title,items,outcome,note=TX["commitment"][lang]
    s=[head(W,H), T(W/2,44,title,22,NAVY,800,rtl=rtl)]
    bw,bh=240,100; gap=24; total=3*bw+2*gap; x0=(W-total)/2; by=78
    order=list(range(3))[::-1] if rtl else list(range(3))
    cxs=[]
    for slot,idx in enumerate(order):
        name,desc,col=items[idx]; bx=x0+slot*(bw+gap); cxs.append(bx+bw/2)
        s+=[BOX(bx,by,bw,bh,"#fff",col,2.5,12)]
        s+=[f'<rect x="{bx}" y="{by}" width="{bw}" height="6" rx="3" fill="{col}"/>']
        s+=[T(bx+bw/2,by+44,name,16.5,col,700,rtl=rtl)]
        s+=[T(bx+bw/2,by+72,desc,12.5,GRAY,500,rtl=rtl)]
    # سهام لأسفل نحو صندوق النتيجة
    oy=270; ow=440; ox=(W-ow)/2; oh=72
    for cx in cxs:
        s+=[LINE(cx,by+bh, W/2, oy, GRAY,2)]
    s+=[f'<defs><marker id="ar" markerWidth="10" markerHeight="10" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="{GRAY}"/></marker></defs>']
    s+=[BOX(ox,oy,ow,oh,"#EAF7EC",GREEN,2.5,14)]
    s+=[T(W/2,oy+44,outcome,17,GREEN,800,rtl=rtl)]
    # ملاحظة الميثاق أسفل
    ny=oy+oh+34
    s+=[BOX((W-560)/2,ny,560,46,"#F6F8FB",NAVY,2,12)]
    s+=[T(W/2,ny+30,"📋 "+note,15,NAVY,700,rtl=rtl)]
    s.append("</svg>"); return "".join(s)

def fig_violation(lang):
    rtl=(lang=="ar"); W,H=480+30,470
    W=900
    title,tiers,esc_lbl=TX["violation"][lang]
    s=[head(W,H), T(W/2,44,title,22,NAVY,800,rtl=rtl)]
    # سلّم ٣ درجات: الأدنى أوّلاً (أسفل) — عرض متدرّج
    widths=[560,470,380]  # من الأسفل للأعلى (الأعلى أضيق = ذروة السلّم)
    bh=86; gap=22; baseY=H-60
    cx=W/2
    ys=[]
    for i in range(3):  # i=0 أسفل
        y=baseY-(i+1)*bh-i*gap
        ys.append(y)
    # نرسم من الأسفل (tier0) للأعلى (tier2)
    for i,(num,name,desc,col,tag) in enumerate(tiers):
        w=widths[i]; x=cx-w/2; y=ys[i]
        fill={GREEN:"#EAF7EC",AMBER:"#FFF6E9",RED:"#FBEAEA"}[col]
        s+=[BOX(x,y,w,bh,fill,col,2.5,12)]
        # دائرة الرقم على جهة البدء
        if rtl: ncx=x+w-36
        else: ncx=x+36
        s+=[f'<circle cx="{ncx}" cy="{y+bh/2}" r="19" fill="{col}"/>',
            T(ncx,y+bh/2+7,num,17,"#fff",800,va="M")]
        # نصّ (يبدأ بعد الدائرة بمسافة كافية)
        if rtl: tx=x+w-72; va="R"
        else: tx=x+72; va="L"
        s+=[T(tx,y+34,name,17,col,700,va=va,rtl=rtl)]
        s+=[T(tx,y+60,desc,12.5,"#374151",500,va=va,rtl=rtl)]
        # وسم (أوّل/أخير) على الجهة المقابلة لجهة البدء
        if tag:
            if rtl: gx2=x+24; gva="L"
            else: gx2=x+w-24; gva="R"
            s+=[T(gx2,y+bh/2+5,"• "+tag,12.5,col,700,va=gva,rtl=rtl)]
    # سهم التصعيد على جهة
    arrx = (cx+widths[0]/2+34) if not rtl else (cx-widths[0]/2-34)
    topY=ys[2]+10; botY=ys[0]+bh-10
    s+=[f'<defs><marker id="up" markerWidth="12" markerHeight="12" refX="4" refY="2" orient="auto"><path d="M0,8 L4,0 L8,8 Z" fill="{NAVY}"/></marker></defs>']
    s+=[f'<line x1="{arrx}" y1="{botY}" x2="{arrx}" y2="{topY}" stroke="{NAVY}" stroke-width="2.5" marker-end="url(#up)"/>']
    # دوّر نصّ التصعيد عموديًّا
    s+=[f'<text x="{arrx+(18 if not rtl else -18)}" y="{(topY+botY)/2}" font-size="13" fill="{NAVY}" font-weight="700" text-anchor="middle" transform="rotate({90 if not rtl else -90} {arrx+(18 if not rtl else -18)} {(topY+botY)/2})"{" direction=\"rtl\"" if rtl else ""}>{esc(esc_lbl)}</text>']
    s.append("</svg>"); return "".join(s)

FIGS={"conflict-sources":fig_sources,"conflict-context":fig_context,
      "five-modes":fig_modes,"team-charter":fig_charter,
      "ground-rules-commitment":fig_commitment,"violation-response":fig_violation}
for fid,fn in FIGS.items():
    for lang in ["ar","en"]:
        svg=fn(lang)
        open(f"/tmp/figs/{fid}_{lang}.svg","w",encoding="utf-8").write(svg)
print("✓ وُلّدت", len(FIGS)*2, "صورة SVG:")
for f in sorted(os.listdir("/tmp/figs")): print("  ",f, os.path.getsize(f"/tmp/figs/{f}"),"بايت")
