#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ExamAce — محوّل docx → كائنات أسئلة JSON (ثنائي اللغة: عربي/إنجليزي).
أنواع مدعومة: single(1) · multi(2) · dnd/matching(3) · blanks(4) · figure(5) · single+fig(6,7=hotspot) · case(8).
لا يسند معرّفات نهائية — الترقيم العالميّ لاحقًا من القاعدة."""
import re, sys, json
from docx import Document
from docx.oxml.ns import qn

DOMAIN_KEY = {
    "الأشخاص": "people", "People": "people",
    "العملية": "process", "العمليات": "process", "Process": "process",
    "بيئة الأعمال": "business", "Business environment": "business",
    "Business Environment": "business", "Business": "business",
}
LETTER_CLASS = r'[أبجدهوABCDEF]'

def ptext(el):
    return ''.join(x.text or '' for x in el.findall('.//' + qn('w:t'))).strip()

def table_grid(tbl_el):
    rows = []
    for tr in tbl_el.findall('./' + qn('w:tr')):
        cells = []
        for tc in tr.findall('./' + qn('w:tc')):
            lines = [ptext(p) for p in tc.findall('./' + qn('w:p'))]
            cells.append([l for l in lines if l])
        rows.append(cells)
    return rows

def classify_table(grid):
    flat = ' '.join(' '.join(' '.join(c) for c in row) for row in grid)
    if any(k in flat for k in ['حقل المدرب', 'الإجابة الصحيحة', 'Trainer field', 'Correct answer']):
        return 'trainer'
    if any(k in flat for k in ['التطابق', 'العنصر', 'Matching', 'Item']):
        return 'match'
    if any(k in flat for k in ['تغطّي الممكّن', 'هذه الدفعة', 'covers enabler', 'This batch']):
        return 'intro'
    return 'other'

LABELS = {
    'ans':       [r'الإجابة الصحيحة', r'Correct answer'],
    'exp':       [r'التعليل', r'Rationale'],
    'primary':   [r'الممكن الأساسي', r'Primary enabler'],
    'secondary': [r'الممكن الثانوي', r'Secondary enabler'],
    'source':    [r'التأصيل', r'Grounding'],
}
AR_DIAC = re.compile(r'[\u064B-\u0652\u0670\u0640]')
def match_label(line, keys):
    norm = AR_DIAC.sub('', line)  # تجاهل التشكيل/التطويل عند المطابقة فقط
    for k in keys:
        kn = AR_DIAC.sub('', k)
        if re.match(r'^\s*' + kn, norm):
            return line.split(':', 1)[1].strip() if ':' in line else ''
    return None

def parse_trainer(grid):
    lines = []
    for row in grid:
        for cell in row:
            lines.extend(cell)
    d = {k: None for k in LABELS}
    for l in lines:
        for key, pats in LABELS.items():
            v = match_label(l, pats)
            if v is not None:
                d[key] = v
                break
    return d

def parse_primary(text):
    if not text:
        return None
    m = re.search(r'(\d+\.\d+\.\d+)\s*[—–-]\s*(.+)', text)
    return {'code': m.group(1).strip(), 'title': m.group(2).strip()} if m else None

def opt_letter(line):
    m = re.match(r'^(' + LETTER_CLASS + r')\)\s*(.+)', line)
    return (m.group(1), m.group(2).strip()) if m else None

def strip_prefix(text):
    return re.sub(r'^(' + LETTER_CLASS + r'|\d+)\)\s*', '', text).strip()

def parse_ans_multi(raw):
    toks = re.split(r'[+،,]', raw or '')
    return [t.strip() for t in toks if re.fullmatch(LETTER_CLASS, t.strip())]

def finalize_matching(q):
    grid = q.pop('_matchGrid', None)
    ans_raw = q.pop('_ansRaw', '') or ''
    if not grid:
        return
    # اكتشف العمود بمحتواه لا بموضعه (الأعمدة قد تنعكس بين اللغات):
    #   ما يبدأ بحرف = عبارة (chip) · ما يبدأ برقم = سؤال (zone)
    statements, ques = [], []   # statements=(letter,text) · ques=(num,text)
    for row in grid[1:]:
        for cell in row:
            txt = ' '.join(cell)
            ml = re.match(r'^(' + LETTER_CLASS + r')\)\s*(.+)', txt)
            mn = re.match(r'^(\d+)\)\s*(.+)', txt)
            if ml:
                statements.append((ml.group(1), ml.group(2).strip()))
            elif mn:
                ques.append((mn.group(1), mn.group(2).strip()))
    # zones = الأسئلة (رقم) · chips = العبارات (حرف)
    q['zones'] = [['q' + num, txt] for (num, txt) in ques]
    q['chips'] = [['c' + let, txt] for (let, txt) in statements]
    ans = {}
    for pair in re.split(r'[·,،]', ans_raw):
        m = re.search(r'(\d+)\s*[↔=→]\s*(' + LETTER_CLASS + r')', pair)
        if m:
            ans['q' + m.group(1)] = 'c' + m.group(2)
    q['ans'] = ans

def parse_doc(path):
    d = Document(path)
    body = d.element.body
    seq = []
    for ch in body.iterchildren():
        if ch.tag == qn('w:p'):
            seq.append(('P', ptext(ch), ch))
        elif ch.tag == qn('w:tbl'):
            g = table_grid(ch)
            seq.append(('T', classify_table(g), g))

    task_name = None
    for typ, t, _ in seq[:4]:
        if typ == 'P' and ('·' in t) and re.search(r'(المهمة|Task)\s+\d', t):
            parts = [p.strip() for p in t.split('·')]
            if len(parts) >= 3:
                task_name = parts[2]
            break

    questions = []
    case_counter = 0
    current_case = None
    case_texts = {}
    i, n = 0, len(seq)
    while i < n:
        typ, t, payload = seq[i]
        if typ == 'P' and re.match(r'^Q\d+', t):
            q = {'_local': re.match(r'^Q(\d+)', t).group(1)}
            parts = [p.strip() for p in t.split('·')]
            dom = parts[1] if len(parts) > 1 else ''
            q['dom'] = dom
            q['domainKey'] = DOMAIN_KEY.get(dom, '')
            mtask = re.search(r'(?:المهمة|Task)\s+(\d+\.\d+)', t)
            q['taskCode'] = mtask.group(1) if mtask else ''
            q['task'] = (q['taskCode'] + ' ' + task_name) if task_name else q['taskCode']
            i += 1
            t2 = seq[i][1]
            mtype = re.search(r'(?:النوع|Type)\s+(\d)', t2)
            mlvl = re.search(r'(L[123])', t2)
            file_type = int(mtype.group(1)) if mtype else 0
            q['lvl'] = mlvl.group(1) if mlvl else ''
            q['_fileType'] = file_type
            i += 1
            q['q'] = seq[i][1]
            opts, match_grid, trainer = [], None, None
            i += 1
            while i < n:
                etyp, eval_, epay = seq[i]
                if etyp == 'P' and re.match(r'^Q\d+', eval_):
                    break
                if etyp == 'P':
                    o = opt_letter(eval_)
                    if o:
                        opts.append([o[0], o[1]])
                elif etyp == 'T':
                    if eval_ == 'match':
                        match_grid = epay
                    elif eval_ == 'trainer':
                        trainer = epay
                        i += 1
                        break
                i += 1
            tr = parse_trainer(trainer) if trainer else {}
            q['exp'] = tr.get('exp')
            q['source'] = tr.get('source')
            q['primary'] = parse_primary(tr.get('primary'))
            sec = tr.get('secondary')
            if not sec or sec.strip() in ('—', '-', ''):
                q['secondary'] = []
            else:
                # مصفوفة نصوص (الأداة تنفّذ .join) — افصل عند · أو ؛ (لا عند — فهي فاصل الرمز/العنوان)
                q['secondary'] = [s.strip() for s in re.split(r'[·؛;،,]', sec)
                                  if s.strip() and s.strip() not in ('—', '-')]
            if file_type == 1:
                q['type'] = 'single'; q['opts'] = opts; q['ans'] = tr.get('ans')
            elif file_type == 2:
                q['type'] = 'multi'; q['opts'] = opts; q['ans'] = parse_ans_multi(tr.get('ans'))
            elif file_type == 4:
                # قائمة منسدلة / ملء فراغ → blanks (المحرّك يدعمه). q الأصليّة = تعليماتٌ + عبارةٌ
                # بين «» (عربيّ) أو ' ' (إنجليزيّ) فيها ______ ؛ نستخرجها ونستبدل الفراغ بـ{0}.
                raw = q['q']; ans_letter = tr.get('ans')
                m = re.search(r'«(.+)»', raw) or re.search(r"'(.+)'", raw)
                if m:
                    stmt = m.group(1); instr = raw[:m.start()].strip().rstrip(':').strip()
                    instr = (instr + ':') if instr else ''
                else:
                    stmt = raw; instr = ''
                opt_map = {o[0]: o[1] for o in opts}
                q['type'] = 'blanks'; q['q'] = instr
                q['sentence'] = re.sub(r'_{3,}', '{0}', stmt).strip()
                q['blanks'] = [{'label': '1', 'opts': [o[1] for o in opts],
                                'ans': opt_map.get(ans_letter, ans_letter)}]
                q['_converted'] = 'type4→blanks'
            elif file_type == 5:
                q['type'] = 'single'; q['opts'] = opts; q['ans'] = tr.get('ans')
                q['fig'] = 'FIG-' + q['_local']
            elif file_type == 6:
                # سحب تسميات على الشكل → single + fig (المحرّك لا يصيّر سحبًا على الشكل؛ المؤلّف
                # يؤلّفه خياراتِ ترتيبٍ نصّيّةً + شكلًا، فيُحتسب اختيارًا واحدًا على الشكل).
                q['type'] = 'single'; q['opts'] = opts; q['ans'] = tr.get('ans')
                q['fig'] = 'FIG-' + q['_local']; q['_converted'] = 'type6→single+fig'
            elif file_type == 3:
                q['type'] = 'dnd'; q['dndLayout'] = 'rows'
                q['_matchGrid'] = match_grid; q['_ansRaw'] = tr.get('ans')
                finalize_matching(q)
            elif file_type == 8:
                # دراسة حالة — اختيار من متعدد: single + caseId + نصّ الحالة
                q['type'] = 'single'; q['opts'] = opts; q['ans'] = tr.get('ans')
                if current_case:
                    q['caseId'] = current_case
                    q['_caseText'] = case_texts.get(current_case)
            elif file_type == 7:
                # hotspot → single + fig (المحرّك يحتاج tiles لا ينتجها المؤلّف؛ يُحوَّل
                # اختيارًا على الشكل مثل النوع 6). الشكل يعرض المناطق ① ② ③ والخيارات تصفها.
                q['type'] = 'single'; q['opts'] = opts; q['ans'] = tr.get('ans')
                q['fig'] = 'FIG-' + q['_local']; q['_converted'] = 'type7→single+fig'
            else:
                q['type'] = '?'; q['_fileTypeUnknown'] = file_type; q['opts'] = opts; q['ans'] = tr.get('ans')
            questions.append(q)
        else:
            # كشف دراسة الحالة: عنوان «دراسة حالة»/«Case study» يتبعه جدولُ النصّ
            if typ == 'P' and re.search(r'دراسة حالة|دراسة الحالة|Case study', AR_DIAC.sub('', t), re.I):
                if i + 1 < n and seq[i + 1][0] == 'T':
                    g = seq[i + 1][2]
                    narrative = ' '.join(line for row in g for cell in row for line in cell).strip()
                    if narrative:
                        case_counter += 1
                        current_case = 'CASE-%d' % case_counter
                        case_texts[current_case] = narrative
            i += 1
    return questions, task_name

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'PMP_1_1_1_AR.docx'
    qs, tname = parse_doc(path)
    print('task:', tname)
    print('count:', len(qs))
    for q in qs:
        print(json.dumps(q, ensure_ascii=False))
