# -*- coding: utf-8 -*-
# ============================================================================
# build_data.py — تحويل مخرَج المحوّل (converted_*.json) إلى نموذج بيانات الرفع
#   (questions + cases + figs_needed) بترتيب حقولٍ نظيفٍ ومعرّفاتٍ نهائيّة.
#
# الاستعمال: انسخ هذا الملفّ إلى مجلّد العمل، عدّل كتلة CONFIG فقط، ثمّ:
#   python3 build_data.py
# يُخرِج built_<TAG>.json. (المحوّل يضبط dom/domainKey أصلاً؛ هذا لا يلمسهما.)
# اقرأ references/conversion-pipeline.md §٣ للسياق.
# ============================================================================

# ----------------------------- CONFIG (عدّل هنا) -----------------------------
TAG          = "2_2"                       # لاحقة الملفّات (built_<TAG>.json)
CONVERTED    = "converted_2_2.json"        # مخرَج examace_convert.py
TASK_CODE    = "2.2"
BASE_ID      = 501                          # ← أعِد التحقّق من القاعدة: max(id)+1
CASE_START   = 39                           # ← أوّل رقم حالةٍ حرّ (CASE-039)
TASK = {"ar": "تطوير نطاق المشروع وإدارته",
        "en": "Develop and manage project scope"}
ENABLER_ORDER = ["2.2.1", "2.2.2", "2.2.3"]   # ترتيب الممكّنات كما في القاعدة/ECO
# primary.title: AR = ECO 2026 الرسميّ · EN = ECO 2026 الرسميّ (راجع eco-2026-en.md؛ نبّه على فروق المؤلّف)
PRIMARY_TITLE = {
 "2.2.1": {"ar": "تحديد النطاق", "en": "Define scope"},
 "2.2.2": {"ar": "الحصول على موافقة المعنيين على نطاق المشروع", "en": "Obtain stakeholder agreement on project scope"},
 "2.2.3": {"ar": "تقسيم النطاق", "en": "Break down scope"},
}
# تمييز معرّفات الأشكال: مفتاح (ممكّن, رمز الشكل في docx) → معرّف فريد في القاعدة.
#   مثال متعدّد الأشكال: {("2.1.2","FIG-003"):"approach-selection", ("2.1.3","FIG-003"):"sustainability-pyramid"}
FIG_REMAP = {}    # {} إن لم تكن في الدفعة أشكال
# ----------------------------------------------------------------------------

import json, copy, collections
allq = json.load(open(CONVERTED, encoding="utf-8"))
CASE_OF = {e: CASE_START + i for i, e in enumerate(ENABLER_ORDER)}
gid = lambda n: "Q%04d" % n

# ترقيم الأزواج: مرتّبٌ بالممكّن ثمّ بالرقم المحليّ في الـdocx (للاقتران فقط)
pair_for = {}; counter = BASE_ID
for enb in ENABLER_ORDER:
    for loc in sorted({q["_local"] for q in allq[enb]["ar"]}, key=lambda x: int(x)):
        pair_for[(enb, loc)] = gid(counter); counter += 1
MAX_ID = counter - 1

questions = []; cases = {}; figs = set()
# ترتيب حقول الحمولة الثابت (camelCase) — لا تغيّره
ORDER = ["id","lang","pairId","dom","domainKey","taskCode","task","primary","secondary",
         "type","dndLayout","lvl","caseId","fig","q","sentence","blanks","opts",
         "zones","chips","tiles","ans","exp","source"]
clean = lambda q: {k: q[k] for k in ORDER if k in q}

for enb in ENABLER_ORDER:
    for lang in ("ar", "en"):
        for src in sorted(allq[enb][lang], key=lambda x: int(x["_local"])):
            pid = pair_for[(enb, src["_local"])]; q = copy.deepcopy(src)
            for k in list(q):
                if k.startswith("_"): q.pop(k, None)
            q["id"] = ("AR-" if lang == "ar" else "EN-") + pid
            q["lang"] = lang; q["pairId"] = pid
            q["taskCode"] = TASK_CODE; q["task"] = TASK[lang]
            q["primary"] = {"code": enb, "title": PRIMARY_TITLE[enb][lang]}
            q["secondary"] = q.get("secondary", []) or []
            if src.get("caseId"):
                cid = ("AR-" if lang == "ar" else "EN-") + ("CASE-%03d" % CASE_OF[enb])
                q["caseId"] = cid; cases[(lang, cid)] = src.get("_caseText", "")
            else:
                q["caseId"] = q.get("caseId", None)
            if q.get("fig"):
                nf = FIG_REMAP.get((enb, q["fig"]), q["fig"]); q["fig"] = nf; figs.add(nf)
            else:
                q["fig"] = None
            questions.append(clean(q))

print("MAX_ID =", gid(MAX_ID), "| pairs =", len(pair_for), "| rows =", len(questions))
for enb in ENABLER_ORDER:
    locs = sorted({l for (e, l) in pair_for if e == enb}, key=lambda x: int(x))
    print(f"  {enb}: {pair_for[(enb, locs[0])]}..{pair_for[(enb, locs[-1])]}")
print("cases:", len(cases), sorted({c for _, c in cases}))
print("figs:", sorted(figs))
dk = collections.Counter(q["domainKey"] for q in questions)
dm = collections.Counter(q["dom"] for q in questions)
print("domainKey:", dict(dk), "| dom:", dict(dm))   # تحقّق: قيمةٌ واحدةٌ صحيحة لكلٍّ

json.dump({"questions": questions,
           "cases": [{"course": c, "case_id": cid, "text": t} for (c, cid), t in cases.items()],
           "figs_needed": sorted(figs)},
          open(f"built_{TAG}.json", "w"), ensure_ascii=False, indent=1)
print(f"saved built_{TAG}.json")
