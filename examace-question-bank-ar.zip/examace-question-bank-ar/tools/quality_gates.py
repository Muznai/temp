# -*- coding: utf-8 -*-
# ============================================================================
# quality_gates.py — بوّابات الجودة الصارمة قبل التسليم (تعمل على built_<TAG>.json).
#   تشمل: JSON صالح · تسلسل المعرّفات · تكافؤ AR↔EN · اسم المهمّة/المجال/الممكّن ·
#   source محفوظ · ans سليم · التشكيل (U+064B فقط) · ربط الحالات/الأشكال ·
#   منع الطبعة في المتن (مع تمييز «إصدار الوثيقة» الحميد) · طول الشرح · توزيع الإجابات.
#
# الاستعمال: انسخ، عدّل CONFIG، ثمّ: python3 quality_gates.py
# اقرأ references/content-rules.md (خصوصاً §٢ منع الطبعة) قبل ضبط CONFIG.
# ============================================================================

# ----------------------------- CONFIG (عدّل هنا) -----------------------------
BUILT         = "built_2_2.json"
TAG           = "2.2"
EXPECTED_BASE = 501                 # أصغر رقم معرّفٍ متوقّع (تحذيرٌ إن خالف)
TASK_CODE     = "2.2"
TASK_AR       = "تطوير نطاق المشروع وإدارته"
TASK_EN       = "Develop and manage project scope"
DOMAIN_KEY    = "process"           # people | process | business
DOM_AR        = "العملية"           # الأشخاص | العملية | بيئة الأعمال
DOM_EN        = "Process"           # People  | Process | Business
PRIMARY_CODES = {"2.2.1", "2.2.2", "2.2.3"}
# الأشكال: ملفّات SVG لتُدمَج وتُفحَص نصوصها + فهرس (course, fig_id) المتوقّع. [] إن لا أشكال.
FIG_AR_FILES  = []                  # ["appsel_ar.svg", "pyr_ar.svg"]
FIG_EN_FILES  = []                  # ["appsel_en.svg", "pyr_en.svg"]
FIG_INDEX     = set()               # {("ar","approach-selection"),("en","approach-selection"),...}
EXP_MIN, EXP_MAX = 35, 80           # طول الشرح: تحذيرٌ خارج النطاق (الهدف 40–70)
# ----------------------------------------------------------------------------

import json, re
from collections import defaultdict, Counter

d = json.load(open(BUILT, encoding="utf-8"))
Q = d["questions"]; CASES = d["cases"]
svg_ar = "".join(open(f, encoding="utf-8").read() for f in FIG_AR_FILES)
svg_en = "".join(open(f, encoding="utf-8").read() for f in FIG_EN_FILES)

errors = []; warns = []; info = []
def err(m): errors.append(m)
def warn(m): warns.append(m)

BANNED_DIAC = {'\u064C','\u064D','\u064E','\u064F','\u0650','\u0651','\u0652','\u0653','\u0670'}
# سلاسل ممنوعةٌ دائماً في المتن المعروض:
BANNED_VERSION = ['PMBOK', 'pmbok', 'النص الرسمي', 'النصّ الرسميّ']
# الطبعة (إصدار/طبعة + ترتيب/رقم) ممنوعةٌ في المتن — تُلتقط بـ regex منفصل.
#   «الإصدار/إصدار» المجرّدة (إصدار تقرير، نسخة تتقادم بين الإصدارات) = إصدار وثيقةٍ حميد
#   فلا تُمنَع تلقائيّاً، بل تُسرَد للمراجعة اليدويّة. (درس 1.8.4 / 2.1.8)
EDITION_RE = re.compile(
    r'(?:الإصدار|الطبعة|إصدار|طبعة)\s*(?:ال)?'
    r'(?:أول|ثاني|ثالث|رابع|خامس|سادس|سابع|ثامن|تاسع|عاشر|ثامنة|سابعة|سادسة)'
    r'|(?:الإصدار|الطبعة|إصدار|طبعة)\s*(?:رقم\s*)?[٠-٩0-9]')

def displayed_texts(q):
    t = [q.get('q',''), q.get('exp',''), q.get('dom',''), q.get('primary',{}).get('title','')]
    for o in q.get('opts',[]): t.append(o[1])
    for ti in q.get('tiles',[]): t.append(ti['name'])
    for z in q.get('zones',[]): t.append(z[1])
    for c in q.get('chips',[]): t.append(c[1])
    if 'sentence' in q: t.append(q['sentence'])
    for b in q.get('blanks',[]):
        t.append(b.get('label','')); t += b.get('opts',[])
    return [x for x in t if x]

def diac_hits(s): return sorted({f'U+{ord(ch):04X}' for ch in s if ch in BANNED_DIAC})

# 1) JSON + الحقول الأساسيّة
REQUIRED = ['id','lang','pairId','dom','domainKey','taskCode','task','primary',
            'secondary','type','lvl','caseId','fig','q','exp','source']
for q in Q:
    for f in REQUIRED:
        if f not in q: err(f"{q.get('id','?')}: حقل مفقود «{f}»")
    json.dumps(q, ensure_ascii=False)

# 2) تسلسل المعرّفات
ar = sorted(int(q['id'][4:]) for q in Q if q['lang']=='ar')
en = sorted(int(q['id'][4:]) for q in Q if q['lang']=='en')
def check_seq(nums, lang):
    if not nums: return err(f"لا أسئلة {lang}")
    if nums != list(range(nums[0], nums[0]+len(nums))): err(f"تسلسل {lang} منقطع: {nums}")
    if nums[0] != EXPECTED_BASE: warn(f"{lang} يبدأ من Q{nums[0]:04d} لا Q{EXPECTED_BASE:04d} (تحقّق من القاعدة)")
check_seq(ar,'ar'); check_seq(en,'en')
if ar != en: err("نطاقا AR/EN غير متطابقين رقميًّا")
info.append(f"AR: Q{ar[0]:04d}–Q{ar[-1]:04d} ({len(ar)}) · EN: Q{en[0]:04d}–Q{en[-1]:04d} ({len(en)})")

# 3) تكافؤ AR↔EN عبر pairId
pairs = defaultdict(dict)
for q in Q: pairs[q['pairId']][q['lang']] = q
for pid, p in pairs.items():
    if set(p) != {'ar','en'}: err(f"{pid}: لغة ناقصة {list(p)}"); continue
    a, e = p['ar'], p['en']
    if a['type'] != e['type']: err(f"{pid}: نوع غير متطابق {a['type']}/{e['type']}")
    if a['primary']['code'] != e['primary']['code']: err(f"{pid}: رمز ممكّن غير متطابق")
    if a['lvl'] != e['lvl']: warn(f"{pid}: مستوى غير متطابق {a['lvl']}/{e['lvl']}")
    if a['caseId'] and not e['caseId']: err(f"{pid}: caseId في AR فقط")
    if a['fig'] != e['fig']: err(f"{pid}: fig غير متطابق")
    if len(a.get('opts',[])) != len(e.get('opts',[])): err(f"{pid}: عدد opts مختلف")
    if len(a.get('tiles',[])) != len(e.get('tiles',[])): err(f"{pid}: عدد tiles مختلف")
info.append(f"عدد الأزواج: {len(pairs)}")

# 4) المهمّة/المجال/الممكّن
for q in Q:
    if q['taskCode'] != TASK_CODE: err(f"{q['id']}: taskCode={q['taskCode']} (متوقّع {TASK_CODE})")
    if q['lang']=='ar' and q['task'] != TASK_AR: err(f"{q['id']}: task AR=«{q['task']}»")
    if q['lang']=='en' and q['task'] != TASK_EN: err(f"{q['id']}: task EN=«{q['task']}»")
    if q['domainKey'] != DOMAIN_KEY: err(f"{q['id']}: domainKey={q['domainKey']}")
    if q['lang']=='ar' and q['dom'] != DOM_AR: err(f"{q['id']}: dom AR=«{q['dom']}»")
    if q['lang']=='en' and q['dom'] != DOM_EN: err(f"{q['id']}: dom EN=«{q['dom']}»")
    if q['primary']['code'] not in PRIMARY_CODES: err(f"{q['id']}: primary.code={q['primary']['code']}")

# 5) source محفوظ
for q in Q:
    s = q.get('source')
    if not isinstance(s,str) or s.strip().lower() in ('','undefined','none','null','—','-'):
        err(f"{q['id']}: source غير سليم: {repr(s)}")

# 6) ans سليم
for q in Q:
    t = q['type']; ans = q.get('ans')
    if t == 'single':
        if ans not in [o[0] for o in q['opts']]: err(f"{q['id']}: ans «{ans}» خارج الخيارات")
    elif t == 'multi':
        keys = [o[0] for o in q['opts']]
        if not isinstance(ans,list) or not ans: err(f"{q['id']}: ans متعدّد غير صالح")
        else:
            for a in ans:
                if a not in keys: err(f"{q['id']}: ans «{a}» خارج الخيارات")
    elif t == 'hotspot':
        names = [ti['name'] for ti in q['tiles']]
        if ans not in names: err(f"{q['id']}: ans hotspot خارج البلاطات")
        for ti in q['tiles']:
            if ti.get('color') not in ('g','y','r'): err(f"{q['id']}: لون بلاطة غير صالح {ti.get('color')}")
    elif t == 'dnd':
        zids = [z[0] for z in q['zones']]; cids = [c[0] for c in q['chips']]
        if not isinstance(ans,dict): err(f"{q['id']}: ans dnd ليس قاموساً")
        else:
            for k,v in ans.items():
                if k not in zids: err(f"{q['id']}: مفتاح ans «{k}» خارج zones")
                if v not in cids: err(f"{q['id']}: قيمة ans «{v}» خارج chips")
            if len(ans) != len(zids): warn(f"{q['id']}: عدد روابط ans ({len(ans)}) ≠ عدد المناطق ({len(zids)})")

# 7) الطبعة الممنوعة + سرد «إصدار الوثيقة» للمراجعة
issuance_hits = []
for q in Q:
    for txt in displayed_texts(q):
        for bad in BANNED_VERSION:
            if bad in txt:
                err(f"{q['id']}: سلسلة ممنوعة «{bad}»: …{txt[max(0,txt.find(bad)-12):txt.find(bad)+18]}…")
        m = EDITION_RE.search(txt)
        if m: err(f"{q['id']}: إشارة طبعةٍ ممنوعة «{m.group(0)}»: …{txt[max(0,m.start()-12):m.start()+22]}…")
        elif 'إصدار' in txt: issuance_hits.append((q['id'], txt[max(0,txt.find('إصدار')-8):txt.find('إصدار')+20]))
if issuance_hits:
    info.append(f"«إصدار» (وثيقة، حميدٌ غالباً — راجِع يدويّاً): {len(issuance_hits)} موضعاً")
    for qid, frag in issuance_hits[:8]: info.append(f"   · {qid}: …{frag}…")

# 8) التشكيل (U+064B فقط)
for q in Q:
    if q['lang'] != 'ar': continue
    for txt in displayed_texts(q):
        h = diac_hits(txt)
        if h: err(f"{q['id']}: حركات ممنوعة {h} في: …{txt[:40]}…")

# 9) ربط الحالات
case_index = {(c['course'], c['case_id']) for c in CASES}
for q in Q:
    cid = q.get('caseId')
    if cid and (q['lang'], cid) not in case_index:
        err(f"{q['id']}: caseId «{cid}» غير موجود في cases للّغة {q['lang']}")
used = {(q['lang'], q['caseId']) for q in Q if q.get('caseId')}
for c in CASES:
    if (c['course'], c['case_id']) not in used: warn(f"حالة بلا أسئلة: {c['case_id']}/{c['course']}")
for c in CASES:
    if c['course'] == 'ar':
        h = diac_hits(c['text'])
        if h: err(f"{c['case_id']}: حركات ممنوعة في نصّ الحالة {h}")
    for bad in BANNED_VERSION:
        if bad in c['text']: err(f"{c['case_id']}: سلسلة ممنوعة «{bad}» في نصّ الحالة")
    m = EDITION_RE.search(c['text'])
    if m: err(f"{c['case_id']}: إشارة طبعةٍ ممنوعة «{m.group(0)}» في نصّ الحالة")

# 10) ربط الأشكال
for q in Q:
    f = q.get('fig')
    if f and (q['lang'], f) not in FIG_INDEX:
        err(f"{q['id']}: fig «{f}» غير موجود في FIG_INDEX للّغة {q['lang']}")
for seg in re.findall(r'>([^<]+)<', svg_ar):
    h = diac_hits(seg)
    if h: err(f"الشكل ar: حركات ممنوعة {h} في «{seg.strip()}»")
for seg in re.findall(r'>([^<]+)<', svg_ar) + re.findall(r'>([^<]+)<', svg_en):
    for bad in BANNED_VERSION:
        if bad in seg: err(f"الشكل: سلسلة ممنوعة «{bad}»")

# 11) طول الشرح
for q in Q:
    wc = len(q['exp'].split())
    if not (EXP_MIN <= wc <= EXP_MAX): warn(f"{q['id']}: طول الشرح {wc} كلمة (الهدف 40–70)")

# 12) توزيع الإجابات (single)
for lang in ('ar','en'):
    dist = Counter(q['ans'] for q in Q if q['lang']==lang and q['type']=='single')
    info.append(f"توزيع إجابات single ({lang}): {dict(dist)}")

# التقرير
print("="*60); print(f"بوّابات الجودة — دفعة {TAG}"); print("="*60)
for i in info: print("  ℹ ", i)
print(f"\nالأخطاء: {len(errors)} · التنبيهات: {len(warns)}\n")
if errors:
    print("✗ أخطاء (تمنع التسليم):")
    for e in errors: print("   -", e)
else:
    print("✓ لا أخطاء.")
if warns:
    print("\n⚠ تنبيهات (للمراجعة):")
    for w in warns: print("   -", w)
print("\nالنتيجة:", "فشل" if errors else "نجاح")
