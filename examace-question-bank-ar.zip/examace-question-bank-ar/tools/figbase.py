# -*- coding: utf-8 -*-
import re
NAVY="#1F3B63"; BOXBLUE="#EDF3FB"; GRAY="#5B6B7F"; LGRAY="#C9D3E0"
AMBER="#B26A00"; RED="#9C2A2A"; PINK="#FBE9E9"; GREEN="#2E7D52"; LINE="#8794A6"
GREENBG="#E8F2EC"; BLUEDOT="#2E6DA4"
FONT="Tajawal,'Segoe UI',sans-serif"
def esc(s): return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def T(x,y,s,size,color,w=400,anchor="middle",rtl=False):
    d=' direction="rtl"' if rtl else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="{anchor}"{d}>{esc(s)}</text>'
def box(x,y,w,h,fill,stroke,sw=1.5,rx=8):
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def rect(x,y,w,h,fill,stroke="none",sw=0):
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def line(x1,y1,x2,y2,c=LINE,w=1.2): return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{c}" stroke-width="{w}"/>'
def head(W,H): return f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="{FONT}"><rect width="{W}" height="{H}" fill="#fff"/><style>text{{font-family:{FONT};}}</style>'
def responsive(svg):
    W=re.search(r'viewBox="0 0 (\d+)',svg).group(1)
    return svg.replace('<svg viewBox', f'<svg width="100%" style="max-width:{W}px;height:auto" viewBox',1)

def build_table(lang,title,subtitle,headers,rows,caption,label_w=290,val_w=168,widths=None):
    """headers: نصوص الأعمدة (المنطقيّة، التسمية أولاً). rows: [{'cells':[..], 'bg':لون|None,
       'navy':bool, 'shade_label':bool, 'cellbg':{ci:لون}, 'cellcolor':{ci:لون}}]. RTL يعكس ترتيب الأعمدة."""
    rtl=(lang=="ar"); n=len(headers); MARGIN=40
    widths=widths or ([label_w]+[val_w]*(n-1))
    Wtbl=sum(widths); W=Wtbl+2*MARGIN
    y0=70 + (26 if subtitle else 0)
    hh=58; rh=66; H=y0+hh+rh*len(rows)+ (46 if caption else 20)
    # ترتيب العرض: LTR كما هو، RTL معكوس
    order=list(range(n))[::-1] if rtl else list(range(n))
    # حساب حدود الأعمدة (يسار→يمين) بحسب ترتيب العرض
    xs=[MARGIN]; 
    for vi in order: xs.append(xs[-1]+widths[vi])
    def col_center(ci):  # مركز العمود المنطقيّ ci
        pos=order.index(ci); return (xs[pos]+xs[pos+1])/2
    def col_left(ci):
        pos=order.index(ci); return xs[pos]
    s=[head(W,H)]
    s+=[T(W/2,42,title,24,NAVY,800,rtl=rtl)]
    if subtitle: s+=[T(W/2,42+24,subtitle,14.5,GRAY,500,rtl=rtl)]
    # رأس navy
    s+=[rect(MARGIN,y0,Wtbl,hh,NAVY)]
    for ci,htxt in enumerate(headers):
        s+=[T(col_center(ci),y0+hh/2+6,htxt,15.5,"#fff",800,rtl=rtl)]
    # الصفوف
    y=y0+hh
    for r in rows:
        navy=r.get("navy"); 
        if navy: s+=[rect(MARGIN,y,Wtbl,rh,NAVY)]
        else:
            s+=[rect(MARGIN,y,Wtbl,rh,"#fff")]
            if r.get("bg"): s+=[rect(MARGIN,y,Wtbl,rh,r["bg"])]
            if r.get("shade_label"): s+=[rect(col_left(0) if not rtl else col_left(0),y,label_w,rh,BOXBLUE)]
        for ci,col in enumerate(r["cells"]):
            cb=r.get("cellbg",{}).get(ci)
            if cb: s+=[rect(col_left(ci),y,widths[ci],rh,cb)]
        for ci,col in enumerate(r["cells"]):
            isLabel=(ci==0)
            color=r.get("cellcolor",{}).get(ci, ("#fff" if navy else NAVY))
            weight=800 if (isLabel or navy) else 500
            size=15.5 if isLabel else 16
            s+=[T(col_center(ci),y+rh/2+6,col,size,color,weight,rtl=rtl)]
        y+=rh
    # شبكة
    for r_i in range(len(rows)+1):
        yy=y0+hh+r_i*rh; s+=[line(MARGIN,yy,MARGIN+Wtbl,yy,LGRAY,1)]
    for k in range(len(xs)): s+=[line(xs[k],y0,xs[k],y0+hh+rh*len(rows),LGRAY,1)]
    s+=[f'<rect x="{MARGIN}" y="{y0}" width="{Wtbl}" height="{hh+rh*len(rows)}" rx="2" fill="none" stroke="{NAVY}" stroke-width="1.4"/>']
    if caption: s+=[T(W/2,H-18,caption,13.5,GRAY,500,rtl=rtl)]
    s.append("</svg>"); return responsive("".join(s))


# ===== أرقامٌ دائريّة (دائرة + رقم) — لا تعتمد على محارف ①②③ =====
def circ(x,y,n,color=NAVY,r=13):
    return f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r}" fill="#fff" stroke="{color}" stroke-width="1.8"/>'+T(x,y+5,str(n),14,color,800)


# ===== جدولٌ مصغّرٌ داخل صندوق =====
def mini_table(x,y,headers,rows,cw,rh,rtl):
    n=len(headers); Wt=sum(cw)
    order=list(range(n))[::-1] if rtl else list(range(n))
    xs=[x]; 
    for vi in order: xs.append(xs[-1]+cw[vi])
    def cx(ci): p=order.index(ci); return (xs[p]+xs[p+1])/2
    def lx(ci): p=order.index(ci); return xs[p]
    s=[rect(x,y,Wt,rh,NAVY)]
    for ci,h in enumerate(headers): s+=[T(cx(ci),y+rh/2+5,h,13,"#fff",700,rtl=rtl)]
    yy=y+rh
    for ri,row in enumerate(rows):
        s+=[rect(x,yy,Wt,rh,"#fff" if ri%2==0 else BOXBLUE)]
        for ci,c in enumerate(row):
            s+=[T(cx(ci),yy+rh/2+5,c,13.5,NAVY,700 if ci==0 else 500,rtl=rtl)]
        yy+=rh
    for r_i in range(len(rows)+1): s+=[line(x,y+rh+r_i*rh,x+Wt,y+rh+r_i*rh,LGRAY,1)]
    for k in xs: s+=[line(k,y,k,y+rh*(len(rows)+1),LGRAY,1)]
    s+=[f'<rect x="{x}" y="{y}" width="{Wt}" height="{rh*(len(rows)+1)}" fill="none" stroke="{NAVY}" stroke-width="1.2"/>']
    return "".join(s)

# ===== 2.6.2 reserves-model (تخطيط ثابت للّغتين) =====


# ===== مخطّطٌ خطّيّ (خطوط/درجات + خطّ مرجعيّ + علامات مناطق) =====
# يعكس محور X في RTL · وسيلة الإيضاح RTL تستعمل anchor=start
def chart(lang,title,subtitle,xlabels,series,ymin,ymax,ystep,ref=None,markers=None,W=1300,H=620):
    ar=(lang=="ar"); PX1,PX2=170,1180; PYt,PYb=170,470
    n=len(xlabels)
    def xp(i): t=i/(n-1); return (PX2-t*(PX2-PX1)) if ar else (PX1+t*(PX2-PX1))
    def yp(v): return PYb-(v-ymin)/(ymax-ymin)*(PYb-PYt)
    s=[head(W,H), T(W/2,44,title,23,NAVY,800,rtl=ar)]
    if subtitle: s+=[T(W/2,72,subtitle,14.5,GRAY,500,rtl=ar)]
    # شبكة أفقيّة + محور Y (يمين)
    v=ymin
    while v<=ymax:
        y=yp(v); s+=[line(PX1,y,PX2,y,"#E8ECF1",1)]
        s+=[T(PX2+34,y+5,str(v),12.5,GRAY,500)]
        v+=ystep
    s+=[line(PX1,PYt-10,PX1,PYb,NAVY,1.6) if not ar else line(PX2,PYt-10,PX2,PYb,NAVY,1.6)]
    s+=[line(PX1,PYb,PX2,PYb,"#9AA7B6",1.6)]
    # خطّ مرجعيّ أفقيّ
    if ref:
        y=yp(ref["v"]); s+=[f'<line x1="{PX1}" y1="{y:.0f}" x2="{PX2}" y2="{y:.0f}" stroke="{ref["color"]}" stroke-width="2" stroke-dasharray="8 5"/>']
        lx=(PX1+90) if ar else (PX2-90)
        s+=[T(lx,y-9,ref["label"],13,ref["color"],700,rtl=ar)]
    # السلاسل
    for ser in series:
        d=ser["data"]; col=ser["color"]; dash=' stroke-dasharray="7 5"' if ser.get("dash") else ''
        pts=[(xp(i),yp(d[i])) for i in range(n)]
        if ser.get("step"):
            path=f'M {pts[0][0]:.0f} {pts[0][1]:.0f}'
            for i in range(1,n):
                path+=f' L {pts[i][0]:.0f} {pts[i-1][1]:.0f} L {pts[i][0]:.0f} {pts[i][1]:.0f}'
            s+=[f'<path d="{path}" fill="none" stroke="{col}" stroke-width="2.6"{dash}/>']
        else:
            path="M "+" L ".join(f"{x:.0f} {y:.0f}" for x,y in pts)
            s+=[f'<path d="{path}" fill="none" stroke="{col}" stroke-width="2.8"{dash}/>']
        for i,(x,y) in enumerate(pts):
            if ser.get("marker")=="square": s+=[rect(x-5,y-5,10,10,col)]
            else: s+=[f'<circle cx="{x:.0f}" cy="{y:.0f}" r="5.5" fill="{col}"/>']
            s+=[T(x,y-13,str(d[i]),12.5,col,700)]
    # تسميات X
    for i,lb in enumerate(xlabels):
        s+=[T(xp(i),PYb+30,lb,14,NAVY,700,rtl=ar)]
    # علامات المناطق على المحور (دوائر مرقّمة)
    if markers:
        for i,nlabel in markers:
            x=xp(i); s+=[f'<circle cx="{x:.0f}" cy="{PYb-150}" r="13" fill="#fff" stroke="{AMBER}" stroke-width="1.8"/>']
            s+=[T(x,PYb-145,str(nlabel),14,AMBER,800)]
    # وسيلة الإيضاح
    ly=120
    lx0=(PX1+30) if not ar else (PX2-30)
    for k,ser in enumerate(series):
        yy=ly+k*24
        if ar:
            s+=[f'<line x1="{PX2-30}" y1="{yy}" x2="{PX2-70}" y2="{yy}" stroke="{ser["color"]}" stroke-width="3"{" stroke-dasharray=\"6 4\"" if ser.get("dash") else ""}/>']
            s+=[T(PX2-82,yy+5,ser["name"],13.5,NAVY,600,anchor="start",rtl=True)]
        else:
            s+=[f'<line x1="{PX1+30}" y1="{yy}" x2="{PX1+70}" y2="{yy}" stroke="{ser["color"]}" stroke-width="3"{" stroke-dasharray=\"6 4\"" if ser.get("dash") else ""}/>']
            s+=[T(PX1+80,yy+5,ser["name"],13.5,NAVY,600,anchor="start")]
    s.append("</svg>"); return responsive("".join(s))
