-- جدول: الأسئلة حسب النهج × المجال (لكل سؤال منطقي = زوج، عبر course='ar')
select
  coalesce(domain_key,'TOTAL')                              as dom,
  count(*) filter (where data->>'approach'='predictive')    as predictive,
  count(*) filter (where data->>'approach'='agile_hybrid')  as agile_hybrid,
  count(*) filter (where data->>'approach'='unclassified')  as unclassified,
  count(*)                                                   as total
from public.questions
where course = 'ar'
group by rollup(domain_key)
order by (domain_key is null), domain_key;
