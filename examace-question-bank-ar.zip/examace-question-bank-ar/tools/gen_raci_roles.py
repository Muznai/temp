# -*- coding: utf-8 -*-
"""raci-roles لـQ-F01: مصفوفة RACI بأدوار مسمّاة، اختبار القبول بمحاسبَين."""
NAVY="#1F3B63"; LBLUE="#EAF2FB"; GRAY="#5B6B7F"; LGRAY="#D9DEE6"; AMBER="#B26A00"
FONT="Tajawal,'Segoe UI',sans-serif"
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
# المصفوفة (أدوار × تسليمات) — R/A/C/I داخليّاً
# ترتيب الأدوار: مدير المشروع، محلل الأعمال، المطور، الراعي
MATRIX=[["A","R","I","C"],  # وثيقة المتطلبات
        ["A","C","R","I"],  # تصميم النظام
        ["A","A","R","I"],  # اختبار القبول ← محاسبان
        ["R","I","C","A"]]  # خطة الإطلاق
TX={"ar":{"title":"مصفوفة تعيين المسؤوليات (RACI)",
          "roles":["مدير المشروع","محلل الأعمال","المطور","الراعي"],
          "delivs":["وثيقة المتطلبات","تصميم النظام","اختبار القبول","خطة الإطلاق"],
          "words":{"R":"مسؤول","A":"محاسب","C":"مستشار","I":"يطلع"},
          "legend":"مسؤول · محاسب · مستشار · يطلع عليه","useWords":True},
    "en":{"title":"Responsibility Assignment Matrix (RACI)",
          "roles":["Project\nManager","Business\nAnalyst","Developer","Sponsor"],
          "delivs":["Requirements\ndoc","System\ndesign","Acceptance\ntesting","Release plan"],
          "words":{"R":"R","A":"A","C":"C","I":"I"},
          "legend":"R = Responsible · A = Accountable · C = Consulted · I = Informed","useWords":False}}

def T(x,y,s,size,color,w=400,anchor="middle",rtl=False):
    d=' direction="rtl"' if rtl else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="{anchor}"{d}>{esc(s)}</text>'
def Tml(x,y,lines,size,color,w,rtl,lh):
    d=' direction="rtl"' if rtl else ''
    out=[f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="middle"{d}>']
    for i,ln in enumerate(lines):
        dy=0 if i==0 else lh
        out.append(f'<tspan x="{x}" dy="{dy}">{esc(ln)}</tspan>')
    out.append('</text>'); return "".join(out)

def build(lang):
    rtl=(lang=="ar"); d=TX[lang]; W,H=940,540
    lblW=176; cw=160; ch=78; gy=96; ncols=4
    gridW=lblW+ncols*cw; x0=(W-gridW)/2
    def colx(c):
        if rtl: return x0+gridW-lblW if c==0 else x0+gridW-lblW-c*cw
        return x0 if c==0 else x0+lblW+(c-1)*cw
    s=[f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="{FONT}">',
       f'<rect width="{W}" height="{H}" fill="#fff"/><style>text{{font-family:{FONT};}}</style>',
       T(W/2,52,d["title"],24,NAVY,800,rtl=rtl)]
    # رأس الأعمدة
    s+=[f'<rect x="{colx(0)}" y="{gy}" width="{lblW}" height="{ch}" fill="{LBLUE}" stroke="{NAVY}" stroke-width="1.5"/>']
    for j,role in enumerate(d["roles"]):
        cx=colx(j+1)
        s+=[f'<rect x="{cx}" y="{gy}" width="{cw}" height="{ch}" fill="{LBLUE}" stroke="{NAVY}" stroke-width="1.5"/>']
        s+=[Tml(cx+cw/2, gy+ch/2-2 if "\n" in role else gy+ch/2+6, role.split("\n"),16,NAVY,700,rtl,20)]
    # الصفوف
    for r,row in enumerate(MATRIX):
        ry=gy+(r+1)*ch
        s+=[f'<rect x="{colx(0)}" y="{ry}" width="{lblW}" height="{ch}" fill="#fff" stroke="{NAVY}" stroke-width="1.5"/>']
        dl=d["delivs"][r]
        s+=[Tml(colx(0)+lblW/2, ry+ch/2-2 if "\n" in dl else ry+ch/2+6, dl.split("\n"),16,NAVY,700,rtl,20)]
        for j,val in enumerate(row):
            cx=colx(j+1); lab=d["words"][val]
            bold = (val=="A")
            color = NAVY if bold else GRAY
            wt = 800 if bold else 500
            sz = (19 if d["useWords"] else 22) if bold else (17 if d["useWords"] else 20)
            s+=[f'<rect x="{cx}" y="{ry}" width="{cw}" height="{ch}" fill="#fff" stroke="{LGRAY}" stroke-width="1.2"/>']
            s+=[T(cx+cw/2, ry+ch/2+7, lab, sz, color, wt, rtl=rtl)]
    # وسيلة الإيضاح
    ly=gy+(len(MATRIX)+1)*ch+34
    s+=[T(W/2, ly, d["legend"], 15, GRAY, 600, rtl=rtl)]
    s.append("</svg>"); return "".join(s)

for lang in ["ar","en"]:
    open(f"/tmp/figs_appendix/raci-roles_{lang}.svg","w",encoding="utf-8").write(build(lang))
print("✓ وُلّد raci-roles (ar+en)")
