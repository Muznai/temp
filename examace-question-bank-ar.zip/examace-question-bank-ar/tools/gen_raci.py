# -*- coding: utf-8 -*-
"""شكل RACI لـ1.3.1 — مصفوفة فيها تسليمٌ بمحاسبَين (غموض المساءلة)."""
NAVY="#1F3B63"; BLUE="#2E6DA4"; GREEN="#2E7D32"; AMBER="#B26A00"
RED="#9C2A2A"; LBLUE="#EAF2FB"; GRAY="#6B7280"; LGRAY="#E5E7EB"
FONT="Tajawal,'Segoe UI',sans-serif"
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

# بيانات المصفوفة (متطابقة بين اللغتين)
# الصفوف=تسليمات · الأعمدة=أدوار · الخلايا R/A/C/I
MATRIX=[
  ["A","R","C","I"],  # تسليم 1 — محاسب واحد
  ["I","A","R","C"],  # تسليم 2 — محاسب واحد
  ["A","A","R","I"],  # تسليم 3 — محاسبان ← الغموض
  ["C","I","A","R"],  # تسليم 4 — محاسب واحد
]
CELLCOL={"A":NAVY,"R":GREEN,"C":AMBER,"I":GRAY}
CELLBG ={"A":"#E7EDF5","R":"#EAF7EC","C":"#FBF1E3","I":"#F3F4F6"}

TX={
 "ar":{"title":"مصفوفة تعيين المسؤوليات (RACI)",
       "roles":["قائد الفريق","عضو ١","عضو ٢","عضو ٣"],
       "delivs":["تسليم ١","تسليم ٢","تسليم ٣","تسليم ٤"],
       "legend":[("R","مسؤول"),("A","محاسب"),("C","مُستشار"),("I","مُطّلِع")]},
 "en":{"title":"Responsibility assignment matrix (RACI)",
       "roles":["Team lead","Member 1","Member 2","Member 3"],
       "delivs":["Deliverable 1","Deliverable 2","Deliverable 3","Deliverable 4"],
       "legend":[("R","Responsible"),("A","Accountable"),("C","Consulted"),("I","Informed")]},
}

def T(x,y,s,size,color,w=700,anchor="middle",rtl=False):
    d=' direction="rtl"' if rtl else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{w}" text-anchor="{anchor}"{d}>{esc(s)}</text>'

def build(lang):
    rtl=(lang=="ar"); d=TX[lang]
    W,H=880,500
    lblW=150   # عرض عمود التسميات (التسليمات)
    cw=140; ch=58   # خلية الأدوار
    gx=40; gy=92    # بداية الشبكة
    ncols=4
    s=[f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="{FONT}">',
       f'<rect width="{W}" height="{H}" fill="#fff"/>',
       f'<style>text{{font-family:{FONT};}}</style>',
       T(W/2,46,d["title"],22,NAVY,800,rtl=rtl)]
    # دالة الموضع الأفقيّ للعمود المنطقيّ: 0=تسميات، 1..4=أدوار
    gridW=lblW+ncols*cw
    x0=(W-gridW)/2
    def colx(c):  # c: 0 تسميات, 1..ncols أدوار
        if rtl:
            # 0 على اليمين
            if c==0: return x0+gridW-lblW
            return x0+gridW-lblW-c*cw
        else:
            if c==0: return x0
            return x0+lblW+(c-1)*cw
    def colw(c): return lblW if c==0 else cw
    # رأس الأعمدة (الأدوار)
    hy=gy
    # خلية الزاوية
    s+=[f'<rect x="{colx(0)}" y="{hy}" width="{lblW}" height="{ch}" fill="{LBLUE}" stroke="{LGRAY}" stroke-width="1.5"/>']
    for j,role in enumerate(d["roles"]):
        cx=colx(j+1)
        s+=[f'<rect x="{cx}" y="{hy}" width="{cw}" height="{ch}" fill="{NAVY}" stroke="#fff" stroke-width="1.5"/>']
        s+=[T(cx+cw/2,hy+ch/2+6,role,15,"#fff",700,rtl=rtl)]
    # الصفوف
    for r,row in enumerate(MATRIX):
        ry=gy+(r+1)*ch
        # تسمية التسليم
        s+=[f'<rect x="{colx(0)}" y="{ry}" width="{lblW}" height="{ch}" fill="{LBLUE}" stroke="{LGRAY}" stroke-width="1.5"/>']
        s+=[T(colx(0)+lblW/2,ry+ch/2+6,d["delivs"][r],14.5,NAVY,700,rtl=rtl)]
        # الخلايا
        for j,val in enumerate(row):
            cx=colx(j+1)
            s+=[f'<rect x="{cx}" y="{ry}" width="{cw}" height="{ch}" fill="{CELLBG[val]}" stroke="{LGRAY}" stroke-width="1.5"/>']
            # حرف RACI (دائرة ملوّنة للحرف A لإبرازه)
            if val=="A":
                s+=[f'<circle cx="{cx+cw/2}" cy="{ry+ch/2}" r="17" fill="{CELLCOL[val]}"/>']
                s+=[T(cx+cw/2,ry+ch/2+7,val,18,"#fff",800)]
            else:
                s+=[T(cx+cw/2,ry+ch/2+8,val,20,CELLCOL[val],800)]
    # وسيلة الإيضاح (legend)
    ly=gy+(len(MATRIX)+1)*ch+34
    lx=x0
    seg=gridW/4
    for k,(let,term) in enumerate(d["legend"]):
        bx=x0+(k*seg if not rtl else gridW-(k+1)*seg)
        s+=[f'<circle cx="{bx+18}" cy="{ly-6}" r="13" fill="{CELLCOL[let]}"/>',
            T(bx+18,ly-1,let,13,"#fff",800)]
        s+=[T(bx+38,ly-1,"= "+term,13.5,"#374151",600,anchor=("end" if rtl else "start"),rtl=rtl)]
        # عدّل موضع النصّ ليبدأ بعد الدائرة بحسب الاتجاه
    s.append("</svg>")
    return "".join(s)

import os
for lang in ["ar","en"]:
    open(f"/tmp/figs/raci-accountability_{lang}.svg","w",encoding="utf-8").write(build(lang))
print("✓ وُلّد شكل RACI (ar+en)")
