-- ========================================================================
-- ExamAce — فحص سلامة البنك v3 (واعٍ بالأنواع + المستوى) · قراءة فقط · استعلام واحد
-- يتحقّق من كل نوع بحقوله: single/multi(opts+ans) · blanks(blanks[]) · dnd(zones/chips/ans) · hotspot(ans+fig)
-- كل "problem" المتوقّع له 0/PASS.
-- ========================================================================
with chk as (
  -- بنيوية عامّة
  select 'PARITY_violations' as c, count(*) n, true p
  from (select pair_id from public.questions group by pair_id
        having count(*) filter (where course='ar')<>count(*) filter (where course='en')) z
  union all select 'DUP_pair_id_per_course', count(*), true
  from (select course,pair_id from public.questions group by course,pair_id having count(*)>1) z
  union all select 'ORPHAN_figures', count(*), true from public.questions q
  where q.data->>'fig' is not null and not exists (select 1 from public.figures f where f.fig_id=q.data->>'fig' and f.course=q.course)
  union all select 'ORPHAN_cases', count(*), true from public.questions q
  where q.data->>'caseId' is not null and not exists (select 1 from public.cases c where c.case_id=q.data->>'caseId' and c.course=q.course)
  union all select 'MISSING_question_text', count(*), true from public.questions where coalesce(data->>'q','')=''
  union all select 'MISSING_enabler_code', count(*), true from public.questions where data->'primary'->>'code' is null
  union all select 'MALFORMED_enabler_code', count(*), true from public.questions where coalesce(data->'primary'->>'code','') !~ '^[0-9]+\.[0-9]+\.[0-9]+$'
  union all select 'INVALID_type', count(*), true from public.questions where coalesce(data->>'type','') not in ('single','multi','dnd','blanks','hotspot')
  -- single / multi
  union all select 'SINGLEMULTI_missing_opts', count(*), true from public.questions q
  where data->>'type' in ('single','multi')
    and case when jsonb_typeof(q.data->'opts')='array' then jsonb_array_length(q.data->'opts')=0 else true end
  union all select 'SINGLE_ans_not_in_opts', count(*), true from public.questions q
  where data->>'type'='single' and data->>'ans' is not null
    and not exists (select 1 from jsonb_array_elements(q.data->'opts') o where o->>0=q.data->>'ans')
  union all select 'MULTI_ans_not_array_or_empty', count(*), true from public.questions q
  where data->>'type'='multi'
    and case when jsonb_typeof(q.data->'ans')='array' then jsonb_array_length(q.data->'ans')=0 else true end
  union all select 'MULTI_ans_key_not_in_opts', count(*), true from public.questions q
  where data->>'type'='multi' and jsonb_typeof(q.data->'ans')='array'
    and exists (select 1 from jsonb_array_elements_text(q.data->'ans') a
                where not exists (select 1 from jsonb_array_elements(q.data->'opts') o where o->>0=a))
  -- dnd
  union all select 'DND_missing_zones', count(*), true from public.questions q
  where data->>'type'='dnd'
    and case when jsonb_typeof(q.data->'zones')='array' then jsonb_array_length(q.data->'zones')=0 else true end
  union all select 'DND_missing_chips', count(*), true from public.questions q
  where data->>'type'='dnd'
    and case when jsonb_typeof(q.data->'chips')='array' then jsonb_array_length(q.data->'chips')=0 else true end
  union all select 'DND_ans_not_object_or_empty', count(*), true from public.questions q
  where data->>'type'='dnd'
    and case when jsonb_typeof(q.data->'ans')='object' then (select count(*) from jsonb_object_keys(q.data->'ans'))=0 else true end
  -- blanks
  union all select 'BLANKS_missing_blanks', count(*), true from public.questions q
  where data->>'type'='blanks'
    and case when jsonb_typeof(q.data->'blanks')='array' then jsonb_array_length(q.data->'blanks')=0 else true end
  union all select 'BLANKS_entry_missing_ans', count(*), true from public.questions q
  where data->>'type'='blanks' and jsonb_typeof(q.data->'blanks')='array'
    and exists (select 1 from jsonb_array_elements(q.data->'blanks') b where (b->>'ans') is null)
  -- hotspot
  union all select 'HOTSPOT_missing_ans_or_fig', count(*), true from public.questions
  where data->>'type'='hotspot' and (data->>'ans' is null or data->>'fig' is null)
  -- مستوى الصعوبة ضمن المسموح
  union all select 'INVALID_lvl', count(*), true from public.questions
  where coalesce(data->>'lvl','') not in ('L1','L2','L3','L4')
  -- ===== INFO =====
  union all select 'INFO_distinct_pairs', count(distinct pair_id), false from public.questions
  union all select 'INFO_total_rows', count(*), false from public.questions
  union all select 'INFO_type_single', count(*), false from public.questions where data->>'type'='single'
  union all select 'INFO_type_multi', count(*), false from public.questions where data->>'type'='multi'
  union all select 'INFO_type_dnd', count(*), false from public.questions where data->>'type'='dnd'
  union all select 'INFO_type_blanks', count(*), false from public.questions where data->>'type'='blanks'
  union all select 'INFO_type_hotspot', count(*), false from public.questions where data->>'type'='hotspot'
  union all select 'INFO_lvl_L1', count(*), false from public.questions where data->>'lvl'='L1'
  union all select 'INFO_lvl_L2', count(*), false from public.questions where data->>'lvl'='L2'
  union all select 'INFO_lvl_L3', count(*), false from public.questions where data->>'lvl'='L3'
  union all select 'INFO_lvl_L4', count(*), false from public.questions where data->>'lvl'='L4'
)
select c as check_name, n as count,
       case when not p then 'INFO' when n=0 then 'PASS' else 'FAIL' end as status
from chk order by p desc, c;
