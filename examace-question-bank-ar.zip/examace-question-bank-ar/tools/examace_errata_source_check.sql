-- ═══════ تدقيق حقل التأصيل (source) مقابل errata الطبعة الثانية ═══════
-- يبحث في data->>'source' عربيّةً وإنجليزيّة عن مفاهيم التصحيحات الخمسة (ص 40/46/157/170/185).
-- يلتقط أسئلةً مؤصَّلةً على موضعٍ مصحَّحٍ حتى لو لم يظهر المصطلح في نصّ السؤال.
-- ناتجٌ فارغٌ = البنك نظيفٌ تأصيلياً. ناتجٌ غير فارغ = راجِع كلّ صفٍّ يدويّاً (يُرجَّح تحديثُ تأصيلٍ لا مفتاح).
with q as (
  select pair_id, course,
         data->'primary'->>'code' as enabler,
         data->>'source'          as src
  from public.questions
  where data->>'source' is not null
)
select item, pair_id, course, enabler, left(src,180) as source_snippet
from (
  select '#2 scope-creep formula' item, pair_id, course, enabler, src from q
    where src ~* 'scope creep|زحف النطاق|تمدّد النطاق|تمدد النطاق|تسلّل النطاق|الزحف على النطاق'
  union all
  select '#2 requirements-stability formula', pair_id, course, enabler, src from q
    where src ~* 'requirements stability|stability of requirements|استقرار المتطلّبات|استقرار المتطلبات|ثبات المتطلّبات|ثبات المتطلبات'
  union all
  select '#3 start-to-finish (SF) definition', pair_id, course, enabler, src from q
    where src ~* 'start[- ]?to[- ]?finish|\mSF\M|البداية إلى النهاية|بداية[- ]?نهاية'
  union all
  select '#4 contingent-response definition', pair_id, course, enabler, src from q
    where src ~* 'contingent response|fallback plan|fallback strateg|استجابة طارئة|الاستجابة الطارئة|استراتيجيّات الطوارئ|خطة طوارئ|خطط الطوارئ|خطة بديلة|الخطة الاحتياطيّة|خطة احتياطيّة'
  union all
  select '#5 relative-size estimation', pair_id, course, enabler, src from q
    where src ~* 'relative size|الحجم النسبيّ|الحجم النسبي|التقدير النسبيّ|التقدير النسبي'
  union all
  select '#1 plan-scope-management outputs', pair_id, course, enabler, src from q
    where src ~* 'plan scope management|تخطيط إدارة النطاق'
) t
order by item, pair_id, course;
