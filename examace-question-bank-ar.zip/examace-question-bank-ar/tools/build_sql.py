# -*- coding: utf-8 -*-
# ============================================================================
# build_sql.py — توليد SQL رفعٍ idempotent (questions + cases + figures) من built_<TAG>.json
#   + تحقّقٌ ذاتيّ (jsonb صالح · صفر undefined · عدّ صفوف الأشكال).
#
# الاستعمال: انسخ، عدّل CONFIG (خصوصاً OUT — لا تتركه افتراضيّاً)، ثمّ:
#   python3 build_sql.py
# ⚠️ درسٌ سابق: اسم ملفّ المخرَج يجب ضبطه صراحةً (sed أغفله مرّة فاستبدل ملفّ 1.8).
# ============================================================================

# ----------------------------- CONFIG (عدّل هنا) -----------------------------
TAG   = "2_2"
BUILT = "built_2_2.json"
OUT   = "examace_2_2_task.sql"                 # ← اضبطه صراحةً لكلّ دفعة
HEAD  = "دفعة المهمة 2.2 (تطوير نطاق المشروع وإدارته): الممكّنات 2.2.1 .. 2.2.3"
# الأشكال: صفٌّ لكلّ (fig_id, course). {} إن لم تكن في الدفعة أشكال.
#   مثال: [("approach-selection","ar","appsel_ar.svg"), ("approach-selection","en","appsel_en.svg"), ...]
FIGURE_FILES = []   # قائمة (fig_id, course, svg_path)
# ----------------------------------------------------------------------------

import json, datetime, re
d = json.load(open(BUILT, encoding="utf-8"))
questions = d["questions"]; cases = d["cases"]
figures = [{"fig_id": fid, "course": crs, "svg": open(p, encoding="utf-8").read()}
           for (fid, crs, p) in FIGURE_FILES]

lit  = lambda s: "'" + s.replace("'", "''") + "'"
jlit = lambda o: lit(json.dumps(o, ensure_ascii=False, separators=(',', ':'))) + "::jsonb"
ts = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
ar = [q['id'] for q in questions if q['lang'] == 'ar']
en = [q['id'] for q in questions if q['lang'] == 'en']

out = [f"-- ExamAce — {HEAD}",
       f"-- وُلّد: {ts}",
       f"-- {len(questions)} صفّ سؤال ({len(questions)//2} زوج) · {len(cases)} صفّ حالة · {len(figures)} صفّ شكل",
       f"-- نطاق المعرّفات: {ar[0]}..{ar[-1]} · {en[0]}..{en[-1]} — تحقّق أنّ {ar[0][3:]} حرٌّ في القاعدة قبل التنفيذ",
       "-- آمنٌ لإعادة التنفيذ (idempotent): upsert عبر on conflict", "", "begin;", ""]

out.append("-- ===== 1) الأسئلة =====")
out.append("insert into public.questions (id, course, task_code, domain_key, type, pair_id, data) values")
out.append(",\n".join(
    f"({lit(q['id'])},{lit(q['lang'])},{lit(q['taskCode'])},{lit(q['domainKey'])},"
    f"{lit(q['type'])},{lit(q['pairId'])},{jlit(q)})" for q in questions))
out += ["on conflict (course, id) do update set",
        "  task_code=excluded.task_code, domain_key=excluded.domain_key,",
        "  type=excluded.type, pair_id=excluded.pair_id, data=excluded.data;", ""]

if cases:
    out.append("-- ===== 2) دراسات الحالة =====")
    out.append("insert into public.cases (case_id, course, text) values")
    out.append(",\n".join(f"({lit(c['case_id'])},{lit(c['course'])},{lit(c['text'])})" for c in cases))
    out += ["on conflict (course, case_id) do update set text=excluded.text;", ""]

if figures:
    out.append("-- ===== 3) الأشكال =====")
    out.append("insert into public.figures (fig_id, course, svg) values")
    out.append(",\n".join(f"({lit(f['fig_id'])},{lit(f['course'])},{lit(f['svg'])})" for f in figures))
    out += ["on conflict (course, fig_id) do update set svg=excluded.svg;", ""]

out += ["commit;", ""]
sql = "\n".join(out); open(OUT, "w", encoding="utf-8").write(sql)
print("SQL bytes:", len(sql), "| q:", len(questions), "cases:", len(cases), "figs:", len(figures), "->", OUT)

# تحقّق ذاتيّ
js = re.findall(r"'((?:[^']|'')*)'::jsonb", sql); bad = 0; ids = []
for j in js:
    try: ids.append(json.loads(j.replace("''", "'"))['id'])
    except Exception: bad += 1
# صفوف الأشكال الفعليّة = عدد وسوم <svg (كلّ صفّ شكلٍ يحوي واحداً) — لا عدٌّ مزدوج
figrows = sql.count('<svg')
# undefined الحقيقيّ = رمز JS undefined في موضع قيمةٍ (بعد : أو [ أو ,) — لا الكلمة الإنجليزيّة داخل نصّ
undef = len(re.findall(r'(?<=[:\[,])\s*undefined\b', sql))
print("jsonb valid:", len(js) - bad, "/", len(js),
      "| ids", ids[0] if ids else "-", "..", ids[-1] if ids else "-",
      "| undefined:", undef, "| figrows:", figrows)
