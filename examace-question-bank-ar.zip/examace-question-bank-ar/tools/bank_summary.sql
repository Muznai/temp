-- ════════ استعلام (أ): ملخّص شامل ════════
-- العدّ لكل سؤال منطقيّ (زوج) عبر course='ar'. أعِد التحقّق من المجموع الحاليّ من القاعدة (كان 1996 في 26 يونيو، ثمّ نما بالتوسعة).
with q as (
  select pair_id, type,
         data->>'approach'        as approach,
         data->'primary'->>'code' as enabler,
         data->>'caseId'          as case_id,
         domain_key
  from public.questions
  where course = 'ar'
)
select category, bucket, n from (
  select 'SCENARIOS'            category, '—' bucket, count(distinct case_id) n, 1 ord
    from q where case_id is not null
  union all
  select 'SCENARIO_QUESTIONS', '—', count(*), 2 from q where case_id is not null
  union all
  select 'STANDALONE_QUESTIONS','—', count(*), 3 from q where case_id is null
  union all
  select 'BY_TYPE',      type,                       count(*), 4 from q group by type
  union all
  select 'BY_APPROACH',  coalesce(approach,'(null)'),count(*), 5 from q group by approach
  union all
  select 'BY_DOMAIN',    domain_key,                 count(*), 6 from q group by domain_key
  union all
  select 'TOTAL_QUESTIONS','—', count(*), 7 from q
) t
order by ord, n desc, bucket;
